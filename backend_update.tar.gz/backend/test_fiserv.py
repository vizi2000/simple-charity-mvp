#!/usr/bin/env python3
"""Test script for Fiserv payment integration"""

import asyncio
import json
from app.utils.fiserv_client import fiserv_client

async def test_payment_link():
    """Test creating a payment link with Fiserv"""
    print("Testing Fiserv payment link creation...")
    print(f"API Key: {fiserv_client.api_key[:10]}...")
    print(f"Base URL: {fiserv_client.base_url}")
    print(f"Store ID: {fiserv_client.store_id}")
    
    try:
        # Create a test payment link
        result = await fiserv_client.create_payment_link(
            amount=100.00,
            currency="PLN",
            order_id="TEST-001",
            description="Test donation payment",
            payment_method="blik"
        )
        
        print("\nSuccess! Payment link created:")
        print(json.dumps(result, indent=2))
        
    except Exception as e:
        print(f"\nError creating payment link: {str(e)}")
        print(f"Error type: {type(e).__name__}")
        
        # If it's an HTTP error, try to get more details
        if hasattr(e, 'response'):
            print(f"Response status: {e.response.status_code}")
            print(f"Response body: {e.response.text}")
    
    finally:
        # Clean up the client
        await fiserv_client._client.aclose()

if __name__ == "__main__":
    asyncio.run(test_payment_link())