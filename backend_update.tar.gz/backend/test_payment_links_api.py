#!/usr/bin/env python3
"""
Test Fiserv Payment Links / Checkout Solution
Generowanie linku do płatności przez REST API
"""

import requests
import json
import base64
import hmac
import hashlib
from datetime import datetime
import time
import uuid

# Klucze
API_KEY = "xWdewnCcYTy8G0s4oS1r5GAOmcdVRYQn"
API_SECRET = "aGOkU61VoIl5AWApLL7avcCpIVZxVGG6jYGVQib8xuG"

# Różne możliwe endpointy dla Payment Links
ENDPOINTS = [
    "https://test.ipg-online.com/api/v1/checkouts",
    "https://test.ipg-online.com/api/v1/payment-links",
    "https://test.ipg-online.com/api/v1/payment-url",
    "https://test.ipg-online.com/api/v1/payments/checkout",
    "https://cert.api.firstdata.com/gateway/v2/payment-links",
    "https://cert.api.firstdata.com/gateway/v2/checkouts"
]

def test_payment_links():
    """Test tworzenia Payment Links przez REST API"""
    
    print("="*60)
    print("TEST PAYMENT LINKS / CHECKOUT SOLUTION")
    print("="*60)
    
    # Przygotuj dane płatności
    payment_data = {
        "amount": {
            "total": "10.00",
            "currency": "PLN"
        },
        "transactionType": "SALE",
        "customer": {
            "email": "test@example.com",
            "name": "Test Customer"
        },
        "order": {
            "orderId": f"LINK-{datetime.now().strftime('%Y%m%d%H%M%S')}",
            "description": "Test payment link"
        },
        "redirectUrls": {
            "successUrl": "https://example.com/success",
            "failureUrl": "https://example.com/failure",
            "cancelUrl": "https://example.com/cancel"
        }
    }
    
    # Alternatywne formaty danych
    alt_payment_data = {
        "chargetotal": "10.00",
        "currency": "985",  # PLN
        "txntype": "sale",
        "oid": f"LINK-{datetime.now().strftime('%Y%m%d%H%M%S')}",
        "successUrl": "https://example.com/success",
        "failureUrl": "https://example.com/failure"
    }
    
    # Różne metody autoryzacji
    auth_methods = {
        "Basic Auth": lambda: {
            "Authorization": f"Basic {base64.b64encode(f'{API_KEY}:{API_SECRET}'.encode()).decode()}",
            "Content-Type": "application/json",
            "Accept": "application/json"
        },
        "API Key Header": lambda: {
            "Api-Key": API_KEY,
            "Api-Secret": API_SECRET,
            "Content-Type": "application/json",
            "Accept": "application/json"
        },
        "HMAC Auth": lambda: generate_hmac_headers()
    }
    
    # Test każdego endpointu
    for endpoint in ENDPOINTS:
        print(f"\n[Testing: {endpoint}]")
        
        for auth_name, auth_func in auth_methods.items():
            headers = auth_func()
            
            # Test z pierwszym formatem danych
            try:
                print(f"  Auth: {auth_name}, Format: v1...", end=" ")
                response = requests.post(
                    endpoint,
                    headers=headers,
                    json=payment_data,
                    timeout=10
                )
                print(f"Status: {response.status_code}")
                
                if response.status_code in [200, 201]:
                    print(f"  ✅ SUKCES! Response: {response.text[:200]}")
                    data = response.json()
                    if 'paymentUrl' in data:
                        print(f"  🔗 Payment URL: {data['paymentUrl']}")
                    if 'checkoutUrl' in data:
                        print(f"  🔗 Checkout URL: {data['checkoutUrl']}")
                    if 'redirectUrl' in data:
                        print(f"  🔗 Redirect URL: {data['redirectUrl']}")
                    return True
                elif response.status_code != 404:
                    print(f"  Response: {response.text[:100]}")
                    
            except Exception as e:
                print(f"Error: {type(e).__name__}")
            
            # Test z alternatywnym formatem
            try:
                print(f"  Auth: {auth_name}, Format: v2...", end=" ")
                response = requests.post(
                    endpoint,
                    headers=headers,
                    json=alt_payment_data,
                    timeout=10
                )
                print(f"Status: {response.status_code}")
                
                if response.status_code in [200, 201]:
                    print(f"  ✅ SUKCES! Response: {response.text[:200]}")
                    return True
                    
            except Exception as e:
                print(f"Error: {type(e).__name__}")
    
    # Test GET endpoints (może trzeba najpierw utworzyć sesję)
    print("\n" + "="*60)
    print("TEST SESSION ENDPOINTS")
    print("="*60)
    
    session_endpoints = [
        "https://test.ipg-online.com/api/v1/sessions",
        "https://test.ipg-online.com/api/v1/payment-sessions",
        "https://cert.api.firstdata.com/gateway/v2/sessions"
    ]
    
    for endpoint in session_endpoints:
        print(f"\nTesting: {endpoint}")
        headers = {
            "Authorization": f"Basic {base64.b64encode(f'{API_KEY}:{API_SECRET}'.encode()).decode()}",
            "Content-Type": "application/json"
        }
        
        session_data = {
            "amount": "10.00",
            "currency": "PLN",
            "returnUrl": "https://example.com/return"
        }
        
        try:
            response = requests.post(endpoint, headers=headers, json=session_data, timeout=10)
            print(f"Status: {response.status_code}")
            if response.status_code in [200, 201]:
                print(f"✅ Session created: {response.text[:200]}")
                data = response.json()
                if 'sessionId' in data:
                    print(f"Session ID: {data['sessionId']}")
                if 'paymentPageUrl' in data:
                    print(f"Payment Page URL: {data['paymentPageUrl']}")
        except Exception as e:
            print(f"Error: {e}")
    
    return False

def generate_hmac_headers():
    """Generuj nagłówki HMAC dla FirstData"""
    timestamp = str(int(time.time() * 1000))
    nonce = str(uuid.uuid4())
    
    # HMAC calculation (FirstData style)
    message = f"{API_KEY}{timestamp}{nonce}"
    signature = hmac.new(
        API_SECRET.encode('utf-8'),
        message.encode('utf-8'),
        hashlib.sha256
    ).hexdigest()
    
    return {
        "Api-Key": API_KEY,
        "Timestamp": timestamp,
        "Nonce": nonce,
        "Authorization": f"HMAC {signature}",
        "Content-Type": "application/json",
        "Accept": "application/json"
    }

def test_checkout_api():
    """Test Checkout API - inna struktura"""
    
    print("\n" + "="*60)
    print("TEST CHECKOUT API")
    print("="*60)
    
    # Checkout API może używać innej struktury
    checkout_data = {
        "checkout": {
            "amount": "10.00",
            "currency": "PLN",
            "reference": f"CHK-{datetime.now().strftime('%Y%m%d%H%M%S')}",
            "description": "Test checkout"
        },
        "customer": {
            "email": "test@example.com"
        },
        "redirectUrls": {
            "success": "https://example.com/success",
            "failure": "https://example.com/failure"
        }
    }
    
    endpoints = [
        "https://test.ipg-online.com/checkouts",
        "https://test.ipg-online.com/v1/checkouts",
        "https://test.ipg-online.com/api/checkouts"
    ]
    
    headers = {
        "Authorization": f"Basic {base64.b64encode(f'{API_KEY}:{API_SECRET}'.encode()).decode()}",
        "Content-Type": "application/json"
    }
    
    for endpoint in endpoints:
        try:
            print(f"\nTrying: {endpoint}")
            response = requests.post(endpoint, headers=headers, json=checkout_data, timeout=10)
            print(f"Status: {response.status_code}")
            if response.status_code != 404:
                print(f"Response: {response.text[:200]}")
                if response.status_code in [200, 201]:
                    return True
        except Exception as e:
            print(f"Error: {e}")
    
    return False

if __name__ == "__main__":
    # Test Payment Links
    success = test_payment_links()
    
    if not success:
        # Jeśli Payment Links nie działają, spróbuj Checkout API
        success = test_checkout_api()
    
    if success:
        print("\n✅ ZNALEZIONO DZIAŁAJĄCE API DLA PAYMENT LINKS!")
    else:
        print("\n❌ Nie znaleziono działającego endpointu dla Payment Links")
        print("\nMożliwe przyczyny:")
        print("1. Payment Links API nie jest aktywne dla tego konta")
        print("2. Wymagana inna metoda autoryzacji")
        print("3. Konto jest tylko dla IPG Connect, nie REST API")