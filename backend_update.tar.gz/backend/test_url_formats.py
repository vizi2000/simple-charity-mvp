#!/usr/bin/env python3
"""
Test różnych formatów URLi dla Fiserv
"""

import urllib.parse
from fiserv_payment_v2 import FiservIPGPayment

def test_url_formats():
    """Testuj różne formaty URLi"""
    
    print("="*60)
    print("TEST FORMATÓW URL DLA FISERV")
    print("="*60)
    
    client = FiservIPGPayment()
    
    # Różne formaty URLi do przetestowania
    test_cases = [
        {
            'name': 'Prosty URL bez parametrów',
            'success': 'https://charity.ngrok.app/success',
            'failure': 'https://charity.ngrok.app/failure',
            'notification': 'https://charity-webhook.ngrok.app/webhook'
        },
        {
            'name': 'URL z parametrami GET (niezakodowane)',
            'success': 'https://charity.ngrok.app/payment/success?result=ok&order=TEST123',
            'failure': 'https://charity.ngrok.app/payment/failure?result=error&order=TEST123',
            'notification': 'https://charity-webhook.ngrok.app/webhook?store=760995999'
        },
        {
            'name': 'URL z zakodowanymi parametrami',
            'success': 'https://charity.ngrok.app/payment/success?result=ok&amp;order=TEST123',
            'failure': 'https://charity.ngrok.app/payment/failure?result=error&amp;order=TEST123',
            'notification': None  # Bez notification URL
        },
        {
            'name': 'URL z path parameters (jak w przykładzie Fiserv)',
            'success': 'https://charity.ngrok.app/platnosc/TEST123/status?result=success',
            'failure': 'https://charity.ngrok.app/platnosc/TEST123/status?result=failure',
            'notification': 'https://charity-webhook.ngrok.app/api/webhooks/fiserv'
        },
        {
            'name': 'URL ze znakami specjalnymi w path',
            'success': 'https://charity.ngrok.app/płatność/sukces',
            'failure': 'https://charity.ngrok.app/płatność/błąd',
            'notification': None
        }
    ]
    
    for i, test_case in enumerate(test_cases, 1):
        print(f"\n🧪 TEST {i}: {test_case['name']}")
        print("-" * 40)
        
        # Generuj formularz
        form_data = client.create_payment_form(
            amount=10.00,
            order_id=f"URL-TEST-{i}",
            success_url=test_case['success'],
            failure_url=test_case['failure'],
            notification_url=test_case['notification'],
            customer_name="Test User",
            customer_email="test@example.com"
        )
        
        fields = form_data['fields']
        
        # Pokaż URLe
        print("\n📋 Wygenerowane URLe:")
        print(f"Success: {fields.get('responseSuccessURL', 'BRAK')}")
        print(f"Failure: {fields.get('responseFailURL', 'BRAK')}")
        if 'transactionNotificationURL' in fields:
            print(f"Notification: {fields.get('transactionNotificationURL')}")
        
        # Sprawdź czy URLe są w hash string
        exclude_fields = {'hash', 'hashExtended', 'hash_algorithm'}
        hash_fields = {k: v for k, v in fields.items() if k not in exclude_fields and v}
        sorted_fields = sorted(hash_fields.items())
        hash_string = '|'.join(str(v) for k, v in sorted_fields)
        
        print("\n🔐 W hash string:")
        if test_case['success'] in hash_string:
            print("✅ Success URL jest w hashu")
        else:
            print("❌ Success URL NIE jest w hashu!")
            
        if test_case['failure'] in hash_string:
            print("✅ Failure URL jest w hashu")
        else:
            print("❌ Failure URL NIE jest w hashu!")
    
    # Test URL encoding
    print("\n" + "="*60)
    print("TEST KODOWANIA URL")
    print("="*60)
    
    test_url = "https://charity.ngrok.app/platnosc/TEST-123/status?result=success&amount=50"
    
    print(f"\nOryginalny URL:")
    print(f"  {test_url}")
    
    print(f"\nURL quote:")
    print(f"  {urllib.parse.quote(test_url, safe=':/?&=')}")
    
    print(f"\nURL quote_plus:")
    print(f"  {urllib.parse.quote_plus(test_url)}")
    
    print(f"\nHTML escape (& -> &amp;):")
    print(f"  {test_url.replace('&', '&amp;')}")
    
    # Generuj HTML z przykładem
    print("\n" + "="*60)
    print("GENEROWANIE HTML Z NAJLEPSZYM FORMATEM")
    print("="*60)
    
    # Użyj formatu jak w przykładzie Fiserv
    best_format = client.create_payment_form(
        amount=50.00,
        order_id="FINAL-URL-TEST",
        success_url="https://charity.ngrok.app/platnosc/FINAL-URL-TEST/status?result=success",
        failure_url="https://charity.ngrok.app/platnosc/FINAL-URL-TEST/status?result=failure",
        notification_url="https://charity-webhook.ngrok.app/api/webhooks/fiserv",
        customer_name="Jan Kowalski",
        customer_email="jan.kowalski@example.com"
    )
    
    html_file = "test_url_format_final.html"
    client.generate_test_html(best_format, html_file)
    
    print(f"\n✅ Wygenerowano HTML: {html_file}")
    print("\nFormat URLi zgodny z przykładem Fiserv:")
    print(f"  Success: /platnosc/{{order_id}}/status?result=success")
    print(f"  Failure: /platnosc/{{order_id}}/status?result=failure")
    print(f"  Notification: /api/webhooks/fiserv")

if __name__ == "__main__":
    test_url_formats()