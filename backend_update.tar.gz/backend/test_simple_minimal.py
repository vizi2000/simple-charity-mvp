#!/usr/bin/env python3
"""
Test z ABSOLUTNIE MINIMALNYMI parametrami
Tylko wymagane pola, bez dodatkowych URL-i
"""

import httpx
import asyncio
from datetime import datetime
from zoneinfo import ZoneInfo
import hmac
import hashlib
import base64
from collections import OrderedDict


class MinimalFiservTest:
    """Test z minimalnymi parametrami"""
    
    def __init__(self):
        self.store_id = "760995999"
        self.shared_secret = "j}2W3P)Lwv"
        self.gateway_url = "https://test.ipg-online.com/connect/gateway/processing"
        
    def create_minimal_form(self):
        """Stwórz MINIMALNY formularz - tylko wymagane pola"""
        
        print("="*70)
        print("MINIMALNY TEST - TYLKO WYMAGANE POLA")
        print("="*70)
        
        # Warszawa timezone
        warsaw_tz = ZoneInfo("Europe/Warsaw")
        now_warsaw = datetime.now(warsaw_tz)
        txndatetime = now_warsaw.strftime("%Y:%m:%d-%H:%M:%S")
        
        print(f"\n📅 Timestamp warszawski: {txndatetime}")
        
        # TYLKO absolutnie wymagane pola
        form_fields = OrderedDict([
            ('storename', self.store_id),
            ('txntype', 'sale'),
            ('timezone', 'Europe/Warsaw'),
            ('txndatetime', txndatetime),
            ('hash_algorithm', 'HMACSHA256'),
            ('chargetotal', '10.00'),
            ('currency', '985'),  # PLN
            ('checkoutoption', 'combinedpage')
        ])
        
        # Oblicz hash
        fields_for_hash = OrderedDict(sorted(form_fields.items()))
        hash_string = '|'.join(str(v) for v in fields_for_hash.values())
        
        print(f"\n🔗 String do hasha: {hash_string}")
        
        hash_bytes = hmac.new(
            self.shared_secret.encode('utf-8'),
            hash_string.encode('utf-8'),
            hashlib.sha256
        ).digest()
        
        hash_value = base64.b64encode(hash_bytes).decode('utf-8')
        form_fields['hashExtended'] = hash_value
        
        print(f"\n🔐 Hash: {hash_value}")
        
        print("\n📋 Wszystkie pola:")
        for k, v in form_fields.items():
            print(f"   {k}: {v}")
        
        return form_fields
    
    async def test_minimal(self):
        """Test z minimalnymi parametrami"""
        
        form_fields = self.create_minimal_form()
        
        print("\n" + "="*70)
        print("WYSYŁANIE MINIMALNEGO FORMULARZA")
        print("="*70)
        
        async with httpx.AsyncClient(follow_redirects=False, timeout=30.0) as client:
            response = await client.post(
                self.gateway_url,
                data=form_fields,
                headers={'Content-Type': 'application/x-www-form-urlencoded'}
            )
            
            print(f"\n📡 Status: {response.status_code}")
            
            if response.status_code in [302, 303]:
                location = response.headers.get('location', '')
                print(f"📍 Redirect: {location[:100]}...")
                
                if 'validationError' in location:
                    print("\n❌ Nadal validation error z MINIMALNYMI parametrami")
                    print("\n🔴 TO POTWIERDZA PROBLEM Z:")
                    print("   1. Shared secret")
                    print("   2. Konfiguracją konta")
                    print("   3. Uprawnieniami")
                else:
                    print("\n✅ SUKCES! Przekierowanie bez błędu!")
            
            return response
    
    def generate_debug_html(self):
        """Generuj HTML do debugowania"""
        
        form_fields = self.create_minimal_form()
        
        html = f"""<!DOCTYPE html>
<html>
<head>
    <title>Minimalny Test Fiserv</title>
    <meta charset="UTF-8">
    <style>
        body {{ font-family: monospace; padding: 40px; background: #f0f0f0; }}
        .container {{ max-width: 600px; margin: auto; background: white; padding: 30px; }}
        h1 {{ color: #333; }}
        .field {{ margin: 10px 0; padding: 8px; background: #f8f8f8; }}
        button {{ background: #4CAF50; color: white; padding: 15px 30px; border: none; font-size: 16px; cursor: pointer; }}
        .warning {{ background: #fff3cd; padding: 15px; border-left: 4px solid #ffc107; margin: 20px 0; }}
    </style>
</head>
<body>
    <div class="container">
        <h1>🧪 Minimalny Test Fiserv</h1>
        
        <div class="warning">
            <strong>⚠️ UWAGA:</strong><br>
            To jest test z MINIMALNYMI parametrami.<br>
            Brak URL-i zwrotnych i innych opcjonalnych pól.
        </div>
        
        <h3>Parametry:</h3>
"""
        
        for k, v in form_fields.items():
            if k != 'hashExtended':
                html += f'        <div class="field">{k}: {v}</div>\n'
        
        html += f"""
        <div class="field">hash: {form_fields['hashExtended'][:30]}...</div>
        
        <form method="POST" action="{self.gateway_url}">
"""
        
        for k, v in form_fields.items():
            html += f'            <input type="hidden" name="{k}" value="{v}">\n'
        
        html += """
            <button type="submit">▶️ Wyślij do Fiserv</button>
        </form>
        
        <hr style="margin: 30px 0;">
        
        <h3>Co powinno się stać:</h3>
        <ol>
            <li>Kliknij przycisk</li>
            <li>Powinno przekierować na stronę płatności Fiserv</li>
            <li>Tam dopiero wpisujesz dane karty</li>
        </ol>
        
        <h3>Jeśli pojawi się błąd:</h3>
        <p>Oznacza to problem z konfiguracją konta lub shared secret.</p>
    </div>
</body>
</html>"""
        
        filename = f"minimal_test_{datetime.now().strftime('%Y%m%d_%H%M%S')}.html"
        with open(filename, 'w') as f:
            f.write(html)
        
        print(f"\n📄 HTML zapisany do: {filename}")
        print(f"   Otwórz w przeglądarce i kliknij przycisk")
        
        return filename


async def main():
    """Uruchom minimalny test"""
    
    tester = MinimalFiservTest()
    
    # Test przez API
    await tester.test_minimal()
    
    # Generuj HTML
    html_file = tester.generate_debug_html()
    
    print("\n" + "="*70)
    print("INSTRUKCJA")
    print("="*70)
    print(f"""
1. Otwórz plik: {html_file}
2. Kliknij przycisk "Wyślij do Fiserv"
3. POWINNO przekierować na stronę gdzie WPISUJESZ kartę
4. Jeśli pojawi się błąd = problem z konfiguracją

WAŻNE: Strona płatności powinna się pokazać PRZED wpisaniem karty!
""")


if __name__ == "__main__":
    asyncio.run(main())