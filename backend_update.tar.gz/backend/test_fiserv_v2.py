#!/usr/bin/env python3
"""
Kompletny zestaw testów dla nowej implementacji Fiserv
"""

import sys
import os
import json
import httpx
import asyncio
from datetime import datetime
from zoneinfo import ZoneInfo

sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from fiserv_payment_v2 import FiservIPGPayment


class FiservPaymentTester:
    """Klasa do testowania integracji Fiserv"""
    
    def __init__(self):
        self.client = FiservIPGPayment()
        self.test_results = []
        
    def test_timezone(self):
        """Test 1: Sprawdzenie timezone"""
        print("\n🧪 TEST 1: Timezone")
        print("-" * 40)
        
        form_data = self.client.create_payment_form(
            amount=10.00,
            order_id="TEST-TIMEZONE",
            success_url="https://test.com/success",
            failure_url="https://test.com/failure"
        )
        
        timezone = form_data['fields'].get('timezone')
        success = timezone == 'Europe/Warsaw'
        
        print(f"Timezone: {timezone}")
        print(f"Status: {'✅ PASS' if success else '❌ FAIL'}")
        
        self.test_results.append({
            'test': 'Timezone',
            'expected': 'Europe/Warsaw',
            'actual': timezone,
            'passed': success
        })
        
        return success
    
    def test_timestamp_format(self):
        """Test 2: Format timestamp"""
        print("\n🧪 TEST 2: Format Timestamp")
        print("-" * 40)
        
        form_data = self.client.create_payment_form(
            amount=10.00,
            order_id="TEST-TIMESTAMP",
            success_url="https://test.com/success",
            failure_url="https://test.com/failure"
        )
        
        timestamp = form_data['fields'].get('txndatetime')
        
        # Sprawdź format YYYY:MM:DD-HH:MM:SS
        format_ok = (
            len(timestamp) == 19 and
            timestamp[4] == ':' and
            timestamp[7] == ':' and
            timestamp[10] == '-' and
            timestamp[13] == ':' and
            timestamp[16] == ':'
        )
        
        print(f"Timestamp: {timestamp}")
        print(f"Format: {'✅ PASS' if format_ok else '❌ FAIL'}")
        
        # Sprawdź czy to czas warszawski
        warsaw_tz = ZoneInfo('Europe/Warsaw')
        now_warsaw = datetime.now(warsaw_tz)
        
        try:
            parts = timestamp.split('-')
            date_parts = parts[0].split(':')
            time_parts = parts[1].split(':')
            
            ts_dt = datetime(
                int(date_parts[0]), int(date_parts[1]), int(date_parts[2]),
                int(time_parts[0]), int(time_parts[1]), int(time_parts[2]),
                tzinfo=warsaw_tz
            )
            
            diff = abs((now_warsaw - ts_dt).total_seconds())
            time_ok = diff < 10  # Mniej niż 10 sekund różnicy
            
            print(f"Czas warszawski: {'✅ PASS' if time_ok else '❌ FAIL'} (różnica {diff:.1f}s)")
            
        except Exception as e:
            print(f"Błąd parsowania: {e}")
            time_ok = False
        
        success = format_ok and time_ok
        
        self.test_results.append({
            'test': 'Timestamp Format',
            'expected': 'YYYY:MM:DD-HH:MM:SS (Warsaw)',
            'actual': timestamp,
            'passed': success
        })
        
        return success
    
    def test_required_fields(self):
        """Test 3: Wszystkie wymagane pola"""
        print("\n🧪 TEST 3: Wymagane pola")
        print("-" * 40)
        
        form_data = self.client.create_payment_form(
            amount=50.00,
            order_id="TEST-FIELDS",
            success_url="https://test.com/success",
            failure_url="https://test.com/failure",
            notification_url="https://test.com/webhook",
            customer_name="Test User",
            customer_email="test@example.com"
        )
        
        fields = form_data['fields']
        
        required_fields = [
            'storename',
            'txntype',
            'timezone',
            'txndatetime',
            'hash_algorithm',
            'chargetotal',
            'currency',
            'checkoutoption',
            'oid',
            'responseSuccessURL',
            'responseFailURL',
            'hashExtended'
        ]
        
        missing = []
        for field in required_fields:
            if field not in fields or not fields[field]:
                missing.append(field)
                print(f"❌ {field}: BRAK")
            else:
                print(f"✅ {field}: {fields[field][:30]}...")
        
        success = len(missing) == 0
        
        self.test_results.append({
            'test': 'Required Fields',
            'expected': f'{len(required_fields)} fields',
            'actual': f'{len(required_fields) - len(missing)} fields',
            'passed': success
        })
        
        return success
    
    def test_hash_generation(self):
        """Test 4: Generowanie hasha"""
        print("\n🧪 TEST 4: Generowanie Hash")
        print("-" * 40)
        
        form_data = self.client.create_payment_form(
            amount=100.00,
            order_id="TEST-HASH",
            success_url="https://test.com/success",
            failure_url="https://test.com/failure"
        )
        
        hash_value = form_data['fields'].get('hashExtended')
        
        # Sprawdź czy hash istnieje i ma odpowiednią długość
        hash_ok = hash_value and len(hash_value) > 20
        
        print(f"Hash: {hash_value[:30]}... (długość: {len(hash_value) if hash_value else 0})")
        print(f"Status: {'✅ PASS' if hash_ok else '❌ FAIL'}")
        
        # Sprawdź czy hash jest w Base64
        try:
            import base64
            decoded = base64.b64decode(hash_value)
            base64_ok = len(decoded) == 32  # SHA256 = 32 bajty
            print(f"Base64 valid: {'✅ PASS' if base64_ok else '❌ FAIL'}")
        except:
            base64_ok = False
            print(f"Base64 valid: ❌ FAIL")
        
        success = hash_ok and base64_ok
        
        self.test_results.append({
            'test': 'Hash Generation',
            'expected': 'Valid Base64 SHA256',
            'actual': f'{len(hash_value)} chars' if hash_value else 'None',
            'passed': success
        })
        
        return success
    
    async def test_form_submission(self):
        """Test 5: Wysyłanie formularza do Fiserv"""
        print("\n🧪 TEST 5: Wysyłanie do Fiserv")
        print("-" * 40)
        
        form_data = self.client.create_payment_form(
            amount=15.00,
            order_id=f"TEST-SUBMIT-{datetime.now().strftime('%Y%m%d%H%M%S')}",
            success_url="https://charity.ngrok.app/success",
            failure_url="https://charity.ngrok.app/failure",
            notification_url="https://charity-webhook.ngrok.app/webhook"
        )
        
        async with httpx.AsyncClient(follow_redirects=False) as client:
            try:
                response = await client.post(
                    form_data['action'],
                    data=form_data['fields'],
                    headers={
                        'Content-Type': 'application/x-www-form-urlencoded',
                        'User-Agent': 'Mozilla/5.0 (Test Client)',
                        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
                    }
                )
                
                print(f"Status Code: {response.status_code}")
                
                if response.status_code in [302, 303]:
                    location = response.headers.get('location', '')
                    print(f"Redirect: {location[:80]}...")
                    
                    # Sprawdź czy to błąd walidacji
                    if 'validationError' in location:
                        print("❌ Błąd walidacji")
                        success = False
                    elif 'payment' in location.lower() or 'checkout' in location.lower():
                        print("✅ Przekierowanie do płatności")
                        success = True
                    else:
                        print("⚠️ Nieznane przekierowanie")
                        success = False
                else:
                    print(f"⚠️ Nieoczekiwany status: {response.status_code}")
                    success = False
                    
            except Exception as e:
                print(f"❌ Błąd: {e}")
                success = False
        
        self.test_results.append({
            'test': 'Form Submission',
            'expected': 'Redirect to payment',
            'actual': f'Status {response.status_code}',
            'passed': success
        })
        
        return success
    
    def generate_report(self):
        """Generuj raport z testów"""
        print("\n" + "="*60)
        print("RAPORT Z TESTÓW")
        print("="*60)
        
        passed = sum(1 for r in self.test_results if r['passed'])
        total = len(self.test_results)
        
        print(f"\nWyniki: {passed}/{total} testów przeszło pomyślnie")
        print("-" * 40)
        
        for result in self.test_results:
            status = "✅ PASS" if result['passed'] else "❌ FAIL"
            print(f"{status} | {result['test']}")
            if not result['passed']:
                print(f"      Expected: {result['expected']}")
                print(f"      Actual: {result['actual']}")
        
        # Zapisz raport do JSON
        report_file = f"test_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(report_file, 'w') as f:
            json.dump({
                'timestamp': datetime.now().isoformat(),
                'passed': passed,
                'total': total,
                'success_rate': f"{(passed/total*100):.1f}%",
                'results': self.test_results
            }, f, indent=2)
        
        print(f"\n💾 Raport zapisany do: {report_file}")
        
        return passed == total


async def run_all_tests():
    """Uruchom wszystkie testy"""
    print("="*60)
    print("KOMPLETNY TEST INTEGRACJI FISERV V2")
    print("="*60)
    
    tester = FiservPaymentTester()
    
    # Uruchom testy synchroniczne
    tester.test_timezone()
    tester.test_timestamp_format()
    tester.test_required_fields()
    tester.test_hash_generation()
    
    # Uruchom test asynchroniczny
    await tester.test_form_submission()
    
    # Generuj raport
    all_passed = tester.generate_report()
    
    if all_passed:
        print("\n🎉 WSZYSTKIE TESTY PRZESZŁY POMYŚLNIE!")
    else:
        print("\n⚠️ NIEKTÓRE TESTY NIE PRZESZŁY")
    
    return all_passed


if __name__ == "__main__":
    asyncio.run(run_all_tests())