#!/usr/bin/env python3
"""
Test różnych wariantów hash - może VT używa innego algorytmu
"""

import os
import hmac
import hashlib
import base64
from datetime import datetime, timedelta
import webbrowser

# Konfiguracja
STORE_ID = "760995999"
SHARED_SECRET = "j}2W3P)Lwv"
GATEWAY_URL = "https://test.ipg-online.com/connect/gateway/processing"

def test_different_hash():
    """Test z różnymi wariantami hash"""
    
    # Timestamp
    now = datetime.utcnow() + timedelta(seconds=30)
    txndatetime = now.strftime("%Y:%m:%d-%H:%M:%S")
    
    # Podstawowe parametry
    base_params = {
        'storename': STORE_ID,
        'txntype': 'sale',
        'timezone': 'Europe/Berlin',
        'txndatetime': txndatetime,
        'chargetotal': '1.00',
        'currency': '985',
        'checkoutoption': 'combinedpage',
        'oid': f'HASH-TEST-{datetime.now().strftime("%Y%m%d%H%M%S")}'
    }
    
    # Sortuj parametry
    sorted_params = sorted(base_params.items())
    values_to_hash = '|'.join(str(v) for k, v in sorted_params)
    
    print("="*60)
    print("TEST RÓŻNYCH WARIANTÓW HASH")
    print("="*60)
    print(f"\nHash input string:\n{values_to_hash}\n")
    
    # Różne algorytmy
    algorithms = {
        'SHA256': hashlib.sha256,
        'SHA1': hashlib.sha1,
        'SHA512': hashlib.sha512,
    }
    
    # Różne metody kodowania
    results = {}
    
    for algo_name, algo_func in algorithms.items():
        # HMAC + Base64
        hash_bytes = hmac.new(
            SHARED_SECRET.encode('utf-8'),
            values_to_hash.encode('utf-8'),
            algo_func
        ).digest()
        hash_base64 = base64.b64encode(hash_bytes).decode('utf-8')
        
        # HMAC + Hex
        hash_hex = hmac.new(
            SHARED_SECRET.encode('utf-8'),
            values_to_hash.encode('utf-8'),
            algo_func
        ).hexdigest()
        
        results[f'HMAC{algo_name}_Base64'] = hash_base64
        results[f'HMAC{algo_name}_Hex'] = hash_hex
        
        print(f"HMAC{algo_name} (Base64): {hash_base64[:40]}...")
        print(f"HMAC{algo_name} (Hex):    {hash_hex[:40]}...")
        print()
    
    # Generuj HTML z różnymi wersjami
    html = f"""<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Hash Variations Test</title>
    <style>
        body {{ font-family: Arial, sans-serif; max-width: 1200px; margin: 0 auto; padding: 20px; }}
        .test-form {{ 
            background: #f8f9fa; 
            padding: 20px; 
            margin: 20px 0; 
            border-radius: 5px;
            border: 2px solid #dee2e6;
        }}
        h3 {{ margin-top: 0; color: #495057; }}
        button {{ 
            background: #007bff; 
            color: white; 
            border: none; 
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
        }}
        button:hover {{ background: #0056b3; }}
        .hash-value {{ 
            font-family: monospace; 
            background: #e9ecef; 
            padding: 5px;
            word-break: break-all;
        }}
    </style>
</head>
<body>
    <h1>🔐 Test Różnych Wariantów Hash</h1>
    
    <div style="background: #fff3cd; padding: 15px; border-radius: 5px; margin-bottom: 20px;">
        <strong>⚠️ Cel testu:</strong> Sprawdzić który algorytm/format hash działa z Fiserv
    </div>
"""
    
    # Test 1: SHA256 + Base64 + hashExtended (standard)
    params1 = base_params.copy()
    params1['hash_algorithm'] = 'HMACSHA256'
    params1['hashExtended'] = results['HMACSHA256_Base64']
    
    html += f"""
    <div class="test-form">
        <h3>Test 1: HMACSHA256 + Base64 + hashExtended (Standard)</h3>
        <div class="hash-value">{results['HMACSHA256_Base64']}</div>
        <form method="POST" action="{GATEWAY_URL}" target="_blank">
"""
    for k, v in params1.items():
        html += f'            <input type="hidden" name="{k}" value="{v}">\n'
    html += """
            <button type="submit">Testuj SHA256 + hashExtended</button>
        </form>
    </div>
"""
    
    # Test 2: SHA256 + Base64 + hash (nie hashExtended)
    params2 = base_params.copy()
    params2['hash_algorithm'] = 'HMACSHA256'
    params2['hash'] = results['HMACSHA256_Base64']  # użyj 'hash' zamiast 'hashExtended'
    
    html += f"""
    <div class="test-form">
        <h3>Test 2: HMACSHA256 + Base64 + hash (nie Extended)</h3>
        <div class="hash-value">{results['HMACSHA256_Base64']}</div>
        <form method="POST" action="{GATEWAY_URL}" target="_blank">
"""
    for k, v in params2.items():
        html += f'            <input type="hidden" name="{k}" value="{v}">\n'
    html += """
            <button type="submit">Testuj SHA256 + hash</button>
        </form>
    </div>
"""
    
    # Test 3: SHA1 + Base64
    params3 = base_params.copy()
    params3['hash_algorithm'] = 'HMACSHA1'
    params3['hashExtended'] = results['HMACSHA1_Base64']
    
    html += f"""
    <div class="test-form">
        <h3>Test 3: HMACSHA1 + Base64</h3>
        <div class="hash-value">{results['HMACSHA1_Base64']}</div>
        <form method="POST" action="{GATEWAY_URL}" target="_blank">
"""
    for k, v in params3.items():
        html += f'            <input type="hidden" name="{k}" value="{v}">\n'
    html += """
            <button type="submit">Testuj SHA1</button>
        </form>
    </div>
"""
    
    # Test 4: SHA256 + Hex
    params4 = base_params.copy()
    params4['hash_algorithm'] = 'HMACSHA256'
    params4['hashExtended'] = results['HMACSHA256_Hex']
    
    html += f"""
    <div class="test-form">
        <h3>Test 4: HMACSHA256 + Hex (nie Base64)</h3>
        <div class="hash-value">{results['HMACSHA256_Hex']}</div>
        <form method="POST" action="{GATEWAY_URL}" target="_blank">
"""
    for k, v in params4.items():
        html += f'            <input type="hidden" name="{k}" value="{v}">\n'
    html += """
            <button type="submit">Testuj SHA256 Hex</button>
        </form>
    </div>
"""
    
    html += """
    <div style="margin-top: 30px; padding: 15px; background: #d1ecf1; border-radius: 5px;">
        <strong>Instrukcja:</strong><br>
        1. Kliknij każdy przycisk po kolei<br>
        2. Sprawdź który (jeśli jakikolwiek) przechodzi dalej niż "Unknown error"<br>
        3. Jeśli żaden nie działa → problem jest gdzie indziej (np. Store ID, Secret)
    </div>
</body>
</html>"""
    
    filename = f"hash_variations_test.html"
    with open(filename, 'w', encoding='utf-8') as f:
        f.write(html)
    
    print(f"✅ Test zapisany jako: {filename}")
    print("\nSprawdź który wariant hash (jeśli w ogóle) działa!")
    
    return filename

if __name__ == "__main__":
    filename = test_different_hash()
    webbrowser.open(f"file://{os.path.abspath(filename)}")