#!/usr/bin/env python3
"""
Test all possible hash generation methods for Fiserv
Based on the detailed guide analysis
"""

import hashlib
import hmac
import base64
from datetime import datetime
from zoneinfo import ZoneInfo

def method1_alphabetical_pipe(params: dict, shared_secret: str) -> str:
    """Current method - alphabetical order with pipe separator"""
    sorted_keys = sorted(params.keys())
    values = [str(params[key]) for key in sorted_keys]
    string_to_sign = '|'.join(values)
    
    print(f"Method 1 string: {string_to_sign}")
    
    signature = hmac.new(
        shared_secret.encode('utf-8'),
        string_to_sign.encode('utf-8'),
        hashlib.sha256
    ).digest()
    
    return base64.b64encode(signature).decode('utf-8')

def method2_concatenation(storename, txndatetime, chargetotal, currency, shared_secret):
    """Guide method - simple concatenation"""
    # As described in guide: storename + txndatetime + chargetotal + currency + sharedSecret
    string_to_hash = f"{storename}{txndatetime}{chargetotal}{currency}{shared_secret}"
    
    print(f"Method 2 string: {string_to_hash}")
    
    # Option A: Direct SHA256
    hash_a = hashlib.sha256(string_to_hash.encode('utf-8')).hexdigest()
    
    # Option B: HMAC with shared secret as key
    hash_b = hmac.new(
        shared_secret.encode('utf-8'),
        string_to_hash.encode('utf-8'),
        hashlib.sha256
    ).hexdigest()
    
    # Option C: HMAC with hex-encoded shared secret
    shared_secret_hex = shared_secret.encode('utf-8').hex()
    hash_c = hmac.new(
        bytes.fromhex(shared_secret_hex),
        string_to_hash.encode('utf-8'),
        hashlib.sha256
    ).hexdigest()
    
    return hash_a, hash_b, hash_c

def method3_extended_string(params: dict, shared_secret: str) -> str:
    """Extended string method - specific field order"""
    # Common Fiserv order
    field_order = [
        'chargetotal',
        'currency', 
        'oid',
        'responseFailURL',
        'responseSuccessURL',
        'storename',
        'timezone',
        'transactionNotificationURL',
        'txndatetime',
        'txntype'
    ]
    
    values = []
    for field in field_order:
        if field in params:
            values.append(str(params[field]))
    
    string_to_sign = ''.join(values) + shared_secret
    
    print(f"Method 3 string: {string_to_sign}")
    
    return hashlib.sha256(string_to_sign.encode('utf-8')).hexdigest()

def test_all_methods():
    """Test all hash generation methods"""
    
    # Configuration
    shared_secret = 'j}2W3P)Lwv'
    store_id = '760995999'
    
    # Get current Warsaw time
    warsaw_tz = ZoneInfo('Europe/Warsaw')
    now = datetime.now(warsaw_tz)
    txn_datetime = now.strftime('%Y:%m:%d-%H:%M:%S')
    
    # Test data
    amount = '10.00'
    currency = '985'
    order_id = f"TEST-{now.strftime('%Y%m%d%H%M%S')}"
    
    print("=" * 60)
    print("TESTING ALL HASH METHODS")
    print("=" * 60)
    print(f"Store ID: {store_id}")
    print(f"Amount: {amount}")
    print(f"Currency: {currency}")
    print(f"DateTime: {txn_datetime}")
    print(f"Order ID: {order_id}")
    print(f"Shared Secret: {shared_secret}")
    print("=" * 60)
    
    # Test Method 1: Current implementation
    print("\nMETHOD 1: Alphabetical with pipe separator (current)")
    params1 = {
        'chargetotal': amount,
        'currency': currency,
        'hash_algorithm': 'HMACSHA256',
        'oid': order_id,
        'storename': store_id,
        'timezone': 'Europe/Warsaw',
        'txndatetime': txn_datetime,
        'txntype': 'sale'
    }
    hash1 = method1_alphabetical_pipe(params1, shared_secret)
    print(f"Hash: {hash1}")
    
    # Test Method 2: Guide concatenation
    print("\nMETHOD 2: Simple concatenation (from guide)")
    hash2a, hash2b, hash2c = method2_concatenation(store_id, txn_datetime, amount, currency, shared_secret)
    print(f"Hash 2A (SHA256): {hash2a}")
    print(f"Hash 2B (HMAC): {hash2b}")
    print(f"Hash 2C (HMAC hex key): {hash2c}")
    
    # Test Method 3: Extended string
    print("\nMETHOD 3: Extended string method")
    params3 = {
        'chargetotal': amount,
        'currency': currency,
        'oid': order_id,
        'storename': store_id,
        'timezone': 'Europe/Warsaw',
        'txndatetime': txn_datetime,
        'txntype': 'sale'
    }
    hash3 = method3_extended_string(params3, shared_secret)
    print(f"Hash: {hash3}")
    
    # Generate test HTML forms
    print("\n" + "=" * 60)
    print("GENERATING TEST FORMS")
    print("=" * 60)
    
    # Form with Method 1 hash
    html1 = f'''<!DOCTYPE html>
<html>
<head><title>Test Method 1</title></head>
<body>
<h1>Method 1: Current Implementation</h1>
<form method="POST" action="https://test.ipg-online.com/connect/gateway/processing">
    <input type="hidden" name="txntype" value="sale"/>
    <input type="hidden" name="timezone" value="Europe/Warsaw"/>
    <input type="hidden" name="txndatetime" value="{txn_datetime}"/>
    <input type="hidden" name="hash_algorithm" value="HMACSHA256"/>
    <input type="hidden" name="hashExtended" value="{hash1}"/>
    <input type="hidden" name="storename" value="{store_id}"/>
    <input type="hidden" name="chargetotal" value="{amount}"/>
    <input type="hidden" name="currency" value="{currency}"/>
    <input type="hidden" name="oid" value="{order_id}-M1"/>
    <button type="submit">Test Method 1</button>
</form>
</body>
</html>'''
    
    with open('test_method1.html', 'w') as f:
        f.write(html1)
    print("Created: test_method1.html")
    
    # Form with Method 2B hash (HMAC)
    html2 = f'''<!DOCTYPE html>
<html>
<head><title>Test Method 2</title></head>
<body>
<h1>Method 2: Guide Concatenation</h1>
<form method="POST" action="https://test.ipg-online.com/connect/gateway/processing">
    <input type="hidden" name="txntype" value="sale"/>
    <input type="hidden" name="timezone" value="Europe/Warsaw"/>
    <input type="hidden" name="txndatetime" value="{txn_datetime}"/>
    <input type="hidden" name="hash_algorithm" value="HMACSHA256"/>
    <input type="hidden" name="hash" value="{hash2b}"/>
    <input type="hidden" name="storename" value="{store_id}"/>
    <input type="hidden" name="chargetotal" value="{amount}"/>
    <input type="hidden" name="currency" value="{currency}"/>
    <input type="hidden" name="oid" value="{order_id}-M2"/>
    <button type="submit">Test Method 2</button>
</form>
</body>
</html>'''
    
    with open('test_method2.html', 'w') as f:
        f.write(html2)
    print("Created: test_method2.html")
    
    # Minimal form without hash
    html_minimal = f'''<!DOCTYPE html>
<html>
<head><title>Test Minimal</title></head>
<body>
<h1>Minimal Test (No Hash)</h1>
<form method="POST" action="https://test.ipg-online.com/connect/gateway/processing">
    <input type="hidden" name="txntype" value="sale"/>
    <input type="hidden" name="storename" value="{store_id}"/>
    <input type="hidden" name="chargetotal" value="{amount}"/>
    <input type="hidden" name="currency" value="{currency}"/>
    <button type="submit">Test Minimal</button>
</form>
</body>
</html>'''
    
    with open('test_minimal.html', 'w') as f:
        f.write(html_minimal)
    print("Created: test_minimal.html")

if __name__ == "__main__":
    test_all_methods()