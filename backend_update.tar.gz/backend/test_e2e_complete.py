#!/usr/bin/env python3
"""
Kompleksowy test E2E płatności Fiserv
"""

import os
import sys
import time
import uuid
import json
import hmac
import hashlib
import base64
from datetime import datetime
from zoneinfo import ZoneInfo

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Import Fiserv client
from app.utils.fiserv_ipg_client import fiserv_ipg_client

# Konfiguracja
STORE_ID = '760995999'
SHARED_SECRET = 'j}2W3P)Lwv'
GATEWAY_URL = 'https://test.ipg-online.com/connect/gateway/processing'

def print_section(title):
    """Helper do formatowania sekcji"""
    print(f"\n{'='*70}")
    print(f" {title}")
    print('='*70)

def test_complete_payment_flow():
    """Pełny test przepływu płatności"""
    
    print_section("TEST KOMPLETNEGO PRZEPŁYWU PŁATNOŚCI")
    
    # Dane testowe
    test_cases = [
        {
            'name': 'Płatność kartą 100 PLN',
            'amount': 100.00,
            'payment_method': 'card',
            'donor': 'Jan Kowalski',
            'email': 'jan.kowalski@test.pl'
        },
        {
            'name': 'Płatność BLIK 50 PLN',
            'amount': 50.00,
            'payment_method': 'blik',
            'donor': 'Anna Nowak',
            'email': 'anna.nowak@test.pl'
        },
        {
            'name': 'Mała płatność 10 PLN',
            'amount': 10.00,
            'payment_method': 'card',
            'donor': 'Test User',
            'email': 'test@example.com'
        }
    ]
    
    results = []
    
    for i, test_case in enumerate(test_cases, 1):
        print(f"\nTest {i}/{len(test_cases)}: {test_case['name']}")
        print("-" * 50)
        
        # Generuj unikalny order ID
        order_id = f"E2E-{datetime.now().strftime('%Y%m%d')}-{uuid.uuid4().hex[:8]}"
        
        # Przygotuj dane płatności
        payment_data = fiserv_ipg_client.create_payment_form_data(
            amount=test_case['amount'],
            order_id=order_id,
            description=f"Test: {test_case['name']}",
            success_url=f'https://charity.ngrok.app/platnosc/{order_id}/success',
            failure_url=f'https://charity.ngrok.app/platnosc/{order_id}/failure',
            notification_url='https://charity-webhook.ngrok.app/api/webhooks/fiserv',
            payment_method=test_case['payment_method'],
            customer_info={
                'name': test_case['donor'],
                'email': test_case['email']
            }
        )
        
        form_fields = payment_data['form_fields']
        
        # Weryfikacja kluczowych pól
        print(f"  Order ID: {order_id}")
        print(f"  Kwota: {form_fields.get('chargetotal')} PLN")
        print(f"  Metoda: {test_case['payment_method']}")
        print(f"  Timezone: {form_fields.get('timezone')}")
        print(f"  Timestamp: {form_fields.get('txndatetime')}")
        
        # Sprawdź timestamp
        warsaw_tz = ZoneInfo('Europe/Warsaw')
        now = datetime.now(warsaw_tz)
        
        if form_fields.get('txndatetime'):
            try:
                # Parse timestamp
                date_part, time_part = form_fields['txndatetime'].split('-')
                year, month, day = date_part.split(':')
                hour, minute, second = time_part.split(':')
                
                dt = datetime(int(year), int(month), int(day),
                             int(hour), int(minute), int(second))
                
                time_diff = abs((now.replace(tzinfo=None) - dt).total_seconds())
                
                if time_diff < 60:
                    print(f"  ✓ Timestamp aktualny (różnica: {time_diff:.1f}s)")
                    timestamp_ok = True
                else:
                    print(f"  ✗ Timestamp nieaktualny (różnica: {time_diff:.1f}s)")
                    timestamp_ok = False
            except Exception as e:
                print(f"  ✗ Błąd parsowania timestamp: {e}")
                timestamp_ok = False
        else:
            print("  ✗ Brak timestamp")
            timestamp_ok = False
        
        # Weryfikacja hash
        if form_fields.get('hashExtended'):
            print(f"  ✓ Hash wygenerowany ({len(form_fields['hashExtended'])} znaków)")
            hash_ok = True
        else:
            print("  ✗ Brak hash")
            hash_ok = False
        
        # Weryfikacja dla BLIK
        if test_case['payment_method'] == 'blik':
            if form_fields.get('blikPayment') == 'true':
                print("  ✓ BLIK payment flag ustawiony")
                blik_ok = True
            else:
                print("  ✗ Brak BLIK payment flag")
                blik_ok = False
        else:
            blik_ok = True  # Nie dotyczy
        
        # Ocena testu
        test_passed = all([
            form_fields.get('storename') == STORE_ID,
            form_fields.get('timezone') == 'Europe/Warsaw',
            form_fields.get('currency') == '985',
            timestamp_ok,
            hash_ok,
            blik_ok
        ])
        
        if test_passed:
            print(f"  ✅ TEST ZALICZONY")
        else:
            print(f"  ❌ TEST NIE ZALICZONY")
        
        results.append({
            'name': test_case['name'],
            'order_id': order_id,
            'passed': test_passed,
            'details': {
                'amount': test_case['amount'],
                'timestamp': form_fields.get('txndatetime'),
                'hash': form_fields.get('hashExtended', '')[:20] + '...' if form_fields.get('hashExtended') else None
            }
        })
        
        # Zapisz dane formularza do pliku
        output_file = f"form_data_{order_id}.json"
        with open(output_file, 'w') as f:
            json.dump(form_fields, f, indent=2)
        print(f"  📁 Dane zapisane do: {output_file}")
        
        time.sleep(1)  # Krótka przerwa między testami
    
    return results

def test_hash_generation():
    """Test generowania hash dla różnych scenariuszy"""
    
    print_section("TEST GENEROWANIA HASH")
    
    test_scenarios = [
        {
            'name': 'Standardowa płatność',
            'params': {
                'amount': '25.00',
                'order_id': 'HASH-TEST-001',
                'customer_name': 'Test User',
                'customer_email': 'test@example.com'
            }
        },
        {
            'name': 'Płatność z polskimi znakami',
            'params': {
                'amount': '30.00',
                'order_id': 'HASH-TEST-002',
                'customer_name': 'Józef Żółć',
                'customer_email': 'jozef@example.pl'
            }
        },
        {
            'name': 'Duża kwota',
            'params': {
                'amount': '9999.99',
                'order_id': 'HASH-TEST-003',
                'customer_name': 'Big Donor',
                'customer_email': 'big@donor.com'
            }
        }
    ]
    
    for scenario in test_scenarios:
        print(f"\n{scenario['name']}:")
        
        # Przygotuj pola formularza
        warsaw_tz = ZoneInfo('Europe/Warsaw')
        now = datetime.now(warsaw_tz)
        
        fields = {
            'storename': STORE_ID,
            'txntype': 'sale',
            'timezone': 'Europe/Warsaw',
            'txndatetime': now.strftime("%Y:%m:%d-%H:%M:%S"),
            'chargetotal': scenario['params']['amount'],
            'currency': '985',
            'checkoutoption': 'combinedpage',
            'oid': scenario['params']['order_id'],
            'bname': scenario['params']['customer_name'],
            'bemail': scenario['params']['customer_email']
        }
        
        # Generuj hash
        exclude_fields = {'hash', 'hashExtended', 'hash_algorithm'}
        sorted_params = sorted([
            (k, v) for k, v in fields.items() 
            if k not in exclude_fields and v
        ])
        
        values_to_hash = '|'.join(str(v) for k, v in sorted_params)
        
        hash_value = hmac.new(
            SHARED_SECRET.encode('utf-8'),
            values_to_hash.encode('utf-8'),
            hashlib.sha256
        ).digest()
        
        hash_extended = base64.b64encode(hash_value).decode('utf-8')
        
        print(f"  Input (pierwsze 80 znaków): {values_to_hash[:80]}...")
        print(f"  Hash: {hash_extended[:30]}...")
        print(f"  ✓ Hash wygenerowany poprawnie")
    
    return True

def test_response_urls():
    """Test URL-i odpowiedzi"""
    
    print_section("TEST URL-I ODPOWIEDZI")
    
    test_urls = [
        {
            'type': 'Success URL',
            'url': 'https://charity.ngrok.app/platnosc/TEST-123/status?result=success'
        },
        {
            'type': 'Failure URL', 
            'url': 'https://charity.ngrok.app/platnosc/TEST-123/status?result=failure'
        },
        {
            'type': 'Notification URL',
            'url': 'https://charity-webhook.ngrok.app/api/webhooks/fiserv'
        }
    ]
    
    for url_test in test_urls:
        print(f"\n{url_test['type']}:")
        print(f"  URL: {url_test['url']}")
        
        # Weryfikacja formatu
        if url_test['url'].startswith('https://'):
            print("  ✓ HTTPS protocol")
        else:
            print("  ✗ Brak HTTPS")
        
        if 'localhost' not in url_test['url']:
            print("  ✓ Publiczny URL (nie localhost)")
        else:
            print("  ✗ Localhost URL (Fiserv nie może dotrzeć)")
    
    return True

def generate_summary_report(results):
    """Generuj raport podsumowujący"""
    
    print_section("RAPORT KOŃCOWY")
    
    # Statystyki
    total_tests = len(results)
    passed_tests = sum(1 for r in results if r['passed'])
    failed_tests = total_tests - passed_tests
    
    print(f"\nStatystyki testów:")
    print(f"  Wszystkie testy: {total_tests}")
    print(f"  ✅ Zaliczone: {passed_tests}")
    print(f"  ❌ Niezaliczone: {failed_tests}")
    print(f"  Wskaźnik sukcesu: {(passed_tests/total_tests*100):.1f}%")
    
    print(f"\nSzczegóły testów:")
    for i, result in enumerate(results, 1):
        status = "✅" if result['passed'] else "❌"
        print(f"  {i}. {status} {result['name']}")
        print(f"     Order ID: {result['order_id']}")
        print(f"     Kwota: {result['details']['amount']} PLN")
    
    # Wnioski
    print(f"\n📊 WNIOSKI:")
    
    if passed_tests == total_tests:
        print("  ✅ WSZYSTKIE TESTY ZALICZONE!")
        print("  Integracja z Fiserv działa poprawnie.")
        print("  System gotowy do testów z prawdziwymi kartami.")
    elif passed_tests > 0:
        print("  ⚠️ CZĘŚCIOWY SUKCES")
        print("  Niektóre testy nie przeszły.")
        print("  Sprawdź logi i popraw błędy przed produkcją.")
    else:
        print("  ❌ WSZYSTKIE TESTY NIE PRZESZŁY")
        print("  Integracja wymaga naprawy.")
    
    # Zapisz raport
    report_file = f"test_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    with open(report_file, 'w') as f:
        json.dump({
            'timestamp': datetime.now().isoformat(),
            'statistics': {
                'total': total_tests,
                'passed': passed_tests,
                'failed': failed_tests,
                'success_rate': f"{(passed_tests/total_tests*100):.1f}%"
            },
            'results': results
        }, f, indent=2)
    
    print(f"\n📁 Pełny raport zapisany do: {report_file}")
    
    return passed_tests == total_tests

def main():
    """Główna funkcja testowa"""
    
    print("\n" + "="*70)
    print(" KOMPLEKSOWE TESTY E2E PŁATNOŚCI FISERV")
    print(" " + datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    print("="*70)
    
    # Wykonaj testy
    results = test_complete_payment_flow()
    test_hash_generation()
    test_response_urls()
    
    # Generuj raport
    all_passed = generate_summary_report(results)
    
    print("\n" + "="*70)
    if all_passed:
        print(" ✅ TESTY ZAKOŃCZONE SUKCESEM")
    else:
        print(" ⚠️ TESTY ZAKOŃCZONE Z BŁĘDAMI")
    print("="*70 + "\n")
    
    return all_passed

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)