#!/usr/bin/env python3
"""
Test BLIK payment method
"""

import httpx
import asyncio
import json
from datetime import datetime

async def test_blik_payment():
    """Create a BLIK test payment"""
    
    print("\n" + "="*60)
    print("BLIK PAYMENT TEST")
    print("="*60 + "\n")
    
    async with httpx.AsyncClient() as client:
        # Create BLIK payment
        print("1. Creating BLIK payment...")
        response = await client.post(
            "http://localhost:8001/api/payments/initiate",
            json={
                "goal_id": "church",
                "amount": 25.00,
                "donor_name": "BLIK Test",
                "donor_email": "blik@test.com",
                "payment_method": "blik",
                "message": "Test BLIK payment"
            },
            headers={"Content-Type": "application/json"}
        )
        
        if response.status_code != 200:
            print(f"❌ Error creating payment: {response.status_code}")
            print(response.text)
            return
            
        payment_data = response.json()
        payment_id = payment_data["payment_id"]
        
        print(f"✅ Payment created: {payment_id}")
        print(f"   Amount: {payment_data['amount']} PLN")
        print(f"   Method: BLIK")
        
        # Get form data
        print("\n2. Getting form data...")
        form_response = await client.get(f"http://localhost:8001/api/payments/{payment_id}/form-data")
        
        if form_response.status_code != 200:
            print(f"❌ Error getting form data: {form_response.status_code}")
            return
            
        form_data = form_response.json()
        
        print("✅ Form data retrieved")
        print(f"   Action URL: {form_data['form_action']}")
        
        # Check BLIK-specific fields
        print("\n3. BLIK-specific fields:")
        fields = form_data['form_fields']
        print(f"   blikPayment: {fields.get('blikPayment', 'Not found')}")
        print(f"   Payment method: {fields.get('paymentMethod', 'Not found')}")
        
        # Save form
        html_content = f"""
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>BLIK Payment Test - {payment_id}</title>
    <style>
        body {{ font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; }}
        .info {{ background: #e7f3ff; padding: 15px; border-radius: 5px; margin: 20px 0; }}
        button {{ padding: 15px 30px; background: #4B6A9B; color: white; border: none; cursor: pointer; font-size: 18px; }}
        button:hover {{ background: #2C4770; }}
        .blik-info {{ background: #d4edda; padding: 15px; border-radius: 5px; }}
    </style>
</head>
<body>
    <h1>BLIK Payment Test</h1>
    
    <div class="info">
        <h3>Payment Details:</h3>
        <p><strong>Payment ID:</strong> {payment_id}</p>
        <p><strong>Amount:</strong> 25.00 PLN</p>
        <p><strong>Method:</strong> BLIK</p>
    </div>
    
    <div class="blik-info">
        <h3>Test BLIK Code:</h3>
        <p><strong>Use this code:</strong> 777123</p>
        <p>This is a test code for Fiserv test environment</p>
    </div>
    
    <h2>Form Fields:</h2>
    <div style="background: #f5f5f5; padding: 10px; overflow-x: auto;">
        <pre>{json.dumps(form_data['form_fields'], indent=2)}</pre>
    </div>
    
    <h2>Submit BLIK Payment:</h2>
    <form method="POST" action="{form_data['form_action']}">
"""
        
        # Add all form fields
        for key, value in form_data['form_fields'].items():
            html_content += f'        <input type="hidden" name="{key}" value="{value}">\n'
            
        html_content += """
        <button type="submit">Submit BLIK Payment to Fiserv</button>
    </form>
</body>
</html>
"""
        
        filename = f"test_blik_{payment_id}.html"
        with open(filename, "w", encoding="utf-8") as f:
            f.write(html_content)
            
        print(f"\n✅ BLIK test form saved to: {filename}")
        print(f"Open this file in your browser and submit the payment")
        
        # Save payment info
        with open(f"blik_payment_info_{payment_id}.json", "w") as f:
            json.dump({
                "payment_id": payment_id,
                "created_at": datetime.now().isoformat(),
                "amount": 25.00,
                "method": "blik",
                "form_data": form_data,
                "test_blik_code": "777123"
            }, f, indent=2)

if __name__ == "__main__":
    asyncio.run(test_blik_payment())