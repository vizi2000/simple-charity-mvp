#!/usr/bin/env python3
"""
FINALNY TEST - Działająca konfiguracja!
"""

from datetime import datetime, timedelta
from app.utils.fiserv_ipg_client import FiservIPGClient

def test_final():
    """Test finalnej działającej konfiguracji"""
    
    print("="*60)
    print("✅ DZIAŁAJĄCA KONFIGURACJA FISERV!")
    print("="*60)
    
    client = FiservIPGClient()
    
    # Przygotuj dane testowe
    order_id = f"FINAL-TEST-{datetime.now().strftime('%Y%m%d%H%M%S')}"
    amount = 25.00
    description = "Test platnosci - dzialajaca konfiguracja"
    
    # Wygeneruj formularz
    payment_data = client.create_payment_form_data(
        amount=amount,
        order_id=order_id,
        description=description,
        success_url='https://yourapp.ngrok.app/api/payments/success',
        failure_url='https://yourapp.ngrok.app/api/payments/failure',
        notification_url='https://yourapp.ngrok.app/api/payments/webhooks/fiserv'
    )
    
    print("\n✅ POTWIERDZONE PARAMETRY:")
    print(f"- Store ID: {client.store_id}")
    print(f"- Shared Secret: {client.shared_secret}")
    print(f"- Timezone: Europe/Warsaw")
    print(f"- Currency: 985 (PLN)")
    print(f"- Checkout: classic (NIE combinedpage!)")
    
    print("\n📋 FORM DATA:")
    for k, v in sorted(payment_data['form_fields'].items()):
        if k == 'hashExtended':
            print(f"  {k}: {v[:40]}...")
        else:
            print(f"  {k}: {v}")
    
    # Generuj HTML
    html = f"""<!DOCTYPE html>
<html>
<head>
    <title>Działająca Płatność Fiserv</title>
    <meta charset="UTF-8">
    <style>
        body {{ 
            font-family: Arial, sans-serif; 
            max-width: 800px; 
            margin: 50px auto; 
            padding: 20px;
            background: #f5f5f5;
        }}
        .container {{
            background: white;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }}
        .success-banner {{
            background: #d4edda;
            border: 2px solid #28a745;
            padding: 20px;
            margin-bottom: 30px;
            border-radius: 5px;
            text-align: center;
        }}
        .info {{
            background: #e3f2fd;
            padding: 15px;
            margin: 20px 0;
            border-radius: 5px;
        }}
        .warning {{
            background: #fff3e0;
            padding: 15px;
            margin: 20px 0;
            border-radius: 5px;
            border-left: 4px solid #ff9800;
        }}
        button {{
            background: #28a745;
            color: white;
            border: none;
            padding: 15px 40px;
            font-size: 18px;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 20px;
            width: 100%;
        }}
        button:hover {{
            background: #218838;
        }}
        .field {{
            background: #f8f9fa;
            padding: 8px 12px;
            margin: 5px 0;
            font-family: monospace;
            font-size: 14px;
        }}
        h1 {{ color: #28a745; }}
    </style>
</head>
<body>
    <div class="container">
        <div class="success-banner">
            <h1>🎉 SUKCES! Konfiguracja działa!</h1>
            <p>Po wielu testach znaleźliśmy działającą konfigurację</p>
        </div>
        
        <h2>💳 Test płatności: {amount:.2f} PLN</h2>
        <p>Order ID: {order_id}</p>
        
        <div class="info">
            <h3>✅ Działające parametry:</h3>
            <div class="field">storename: 760995999</div>
            <div class="field">timezone: Europe/Warsaw</div>
            <div class="field">currency: 985</div>
            <div class="field">checkoutoption: classic</div>
            <div class="field">shared secret: j}}2W3P)Lwv</div>
        </div>
        
        <div class="warning">
            <strong>⚠️ WAŻNE:</strong><br>
            Fiserv zalecił <code>combinedpage</code>, ale NIE DZIAŁA dla tego Store ID!<br>
            Używaj <code>classic</code>.
        </div>
        
        <form method="POST" action="{payment_data['form_action']}" target="_blank">
"""
    
    for k, v in payment_data['form_fields'].items():
        html += f'            <input type="hidden" name="{k}" value="{v}">\n'
    
    html += """            <button type="submit">💳 PRZEJDŹ DO PŁATNOŚCI</button>
        </form>
        
        <div class="info" style="margin-top: 30px;">
            <h3>📝 Podsumowanie problemów:</h3>
            <ol>
                <li><strong>Combined Page nie działa</strong> - mimo zaleceń Fiserv</li>
                <li><strong>Classic działa</strong> - używaj tego</li>
                <li><strong>Timezone musi być Europe/Warsaw</strong> - nie Berlin</li>
                <li><strong>Shared Secret jest poprawny</strong> - znaki specjalne OK</li>
            </ol>
        </div>
        
        <div class="info">
            <h3>🔧 Następne kroki:</h3>
            <ol>
                <li>Kod jest już zaktualizowany</li>
                <li>Możesz testować płatności</li>
                <li>Poinformuj Fiserv o problemie z Combined Page</li>
            </ol>
        </div>
    </div>
</body>
</html>"""
    
    with open('test_final_working.html', 'w', encoding='utf-8') as f:
        f.write(html)
    
    print(f"\n✅ Test zapisany jako: test_final_working.html")
    print("\n🎯 GOTOWE DO UŻYCIA!")
    
    import webbrowser
    import os
    webbrowser.open(f"file://{os.path.abspath('test_final_working.html')}")

if __name__ == "__main__":
    test_final()