#!/usr/bin/env python3
"""
Test poprawionej integracji z Fiserv
Naprawia problemy zidentyfikowane w odpowiedzi od Fiserv
"""

import requests
import hmac
import hashlib
import base64
from datetime import datetime
from zoneinfo import ZoneInfo
import json
import sys

# Konfiguracja
SECRET = 'pKg48sCoFM+R7tBfJH/MQ7nMOpXN2EFUcxaFU3Khjac='
STORE_ID = '760995999'
TEST_URL = 'https://test.ipg-online.com/connect/gateway/processing'

def generate_hash_method1(form_data, secret):
    """Metoda 1: Sortowanie alfabetyczne, tylko wartości"""
    # Kopiuj dane bez hash_algorithm i hashExtended
    data_to_hash = {k: v for k, v in form_data.items() 
                   if k not in ['hash_algorithm', 'hashExtended']}
    
    # Sortuj alfabetycznie
    sorted_fields = sorted(data_to_hash.items())
    values_only = [str(v) for k, v in sorted_fields]
    hash_input = '|'.join(values_only)
    
    print(f"   Metoda 1 input: {hash_input[:100]}...")
    
    # Generuj hash
    hash_value = base64.b64encode(
        hmac.new(secret.encode(), hash_input.encode(), hashlib.sha256).digest()
    ).decode()
    
    return hash_value, hash_input

def generate_hash_method2(form_data, secret):
    """Metoda 2: Specyficzna kolejność pól jak w dokumentacji"""
    # Kolejność z przykładu
    fields_order = [
        'chargetotal', 'currency', 'oid', 'secret',
        'storename', 'timezone', 'txndatetime', 'txntype'
    ]
    
    values = []
    for field in fields_order:
        if field == 'secret':
            values.append(secret)
        elif field in form_data:
            values.append(str(form_data[field]))
    
    hash_input = '|'.join(values)
    print(f"   Metoda 2 input: {hash_input[:100]}...")
    
    # Generuj hash
    hash_value = base64.b64encode(
        hmac.new(secret.encode(), hash_input.encode(), hashlib.sha256).digest()
    ).decode()
    
    return hash_value, hash_input

def test_payment(use_berlin_tz=False, hash_method=1):
    """Testuj płatność z różnymi ustawieniami"""
    
    # Wybierz timezone
    if use_berlin_tz:
        tz = ZoneInfo('Europe/Berlin')
        tz_name = 'Europe/Berlin'
    else:
        tz = ZoneInfo('Europe/Warsaw')
        tz_name = 'Europe/Warsaw'
    
    timestamp = datetime.now(tz).strftime('%Y:%m:%d-%H:%M:%S')
    order_id = f'CORRECTED-TEST-{datetime.now().strftime("%Y%m%d%H%M%S")}'
    
    # Dane formularza
    form_data = {
        'storename': STORE_ID,
        'txntype': 'sale',
        'timezone': tz_name,
        'txndatetime': timestamp,
        'hash_algorithm': 'HMACSHA256',
        'chargetotal': '10.00',
        'currency': '985',
        'checkoutoption': 'combinedpage',
        'oid': order_id,
        'responseSuccessURL': 'https://webhook.site/a1b2c3d4-success',
        'responseFailURL': 'https://webhook.site/a1b2c3d4-failure',
        'transactionNotificationURL': 'https://webhook.site/a1b2c3d4-webhook',
        'bname': 'Test Customer',
        'bemail': 'test@customer.pl'
    }
    
    print(f'\n{"="*60}')
    print(f'TEST {hash_method} - Timezone: {tz_name}')
    print(f'{"="*60}')
    
    print(f'\n📤 Przygotowanie danych:')
    print(f'   Order ID: {order_id}')
    print(f'   Timezone: {tz_name}')
    print(f'   Timestamp: {timestamp}')
    print(f'   Kwota: {form_data["chargetotal"]} PLN')
    
    # Generuj hash
    print(f'\n🔐 Generowanie hash (metoda {hash_method}):')
    if hash_method == 1:
        hash_value, hash_input = generate_hash_method1(form_data, SECRET)
    else:
        hash_value, hash_input = generate_hash_method2(form_data, SECRET)
    
    form_data['hashExtended'] = hash_value
    print(f'   Hash: {hash_value[:30]}...')
    
    # Wyślij request
    print(f'\n📨 Wysyłanie do Fiserv...')
    try:
        response = requests.post(TEST_URL, data=form_data, timeout=30, allow_redirects=False)
        
        print(f'\n📊 Odpowiedź:')
        print(f'   Status Code: {response.status_code}')
        
        if 'Location' in response.headers:
            location = response.headers['Location']
            print(f'   Redirect: {location}')
            
            if 'validationError' in location:
                print(f'   ❌ BŁĄD WALIDACJI!')
                
                # Pobierz szczegóły błędu
                try:
                    error_response = requests.get(location, timeout=10)
                    if 'Unknown application error' in error_response.text:
                        print(f'   ⚠️  Unknown application error - sprawdź logi Fiserv')
                    elif 'timestamp' in error_response.text.lower():
                        print(f'   ⚠️  Problem z timestamp - może być przeterminowany')
                    else:
                        print(f'   ⚠️  Inny błąd walidacji')
                except:
                    pass
                    
            elif 'payment' in location.lower() or 'success' in location.lower():
                print(f'   ✅ SUKCES - przekierowanie do strony płatności!')
            else:
                print(f'   ❓ Nieznany redirect')
        else:
            print(f'   Content: {response.text[:200]}...')
        
        # Zapisz wyniki
        result = {
            'test_id': f'{hash_method}_{tz_name}',
            'order_id': order_id,
            'timezone': tz_name,
            'timestamp': timestamp,
            'hash_method': hash_method,
            'hash_value': hash_value,
            'hash_input': hash_input,
            'status_code': response.status_code,
            'headers': dict(response.headers),
            'redirect_url': response.headers.get('Location', None),
            'success': response.status_code == 302 and 'validationError' not in response.headers.get('Location', '')
        }
        
        filename = f'test_result_{order_id}.json'
        with open(filename, 'w') as f:
            json.dump(result, f, indent=2)
        print(f'\n💾 Wyniki zapisane: {filename}')
        
        return result['success']
        
    except Exception as e:
        print(f'   ❌ Błąd: {e}')
        return False

def main():
    print('\n' + '='*70)
    print('🧪 TESTY POPRAWIONEJ INTEGRACJI FISERV')
    print('='*70)
    
    results = []
    
    # Test 1: Warsaw timezone, metoda 1 (sortowanie alfabetyczne)
    results.append(('Warsaw/Metoda1', test_payment(use_berlin_tz=False, hash_method=1)))
    
    # Test 2: Warsaw timezone, metoda 2 (specyficzna kolejność)
    results.append(('Warsaw/Metoda2', test_payment(use_berlin_tz=False, hash_method=2)))
    
    # Test 3: Berlin timezone, metoda 2
    results.append(('Berlin/Metoda2', test_payment(use_berlin_tz=True, hash_method=2)))
    
    # Podsumowanie
    print('\n' + '='*70)
    print('📊 PODSUMOWANIE TESTÓW:')
    print('='*70)
    
    for test_name, success in results:
        status = '✅ SUKCES' if success else '❌ BŁĄD'
        print(f'   {test_name}: {status}')
    
    success_count = sum(1 for _, s in results if s)
    print(f'\nWynik: {success_count}/{len(results)} testów zakończonych sukcesem')
    
    if success_count == 0:
        print('\n⚠️  WSZYSTKIE TESTY NIEUDANE!')
        print('Prawdopodobne przyczyny:')
        print('1. Nieprawidłowy algorytm hash')
        print('2. Przeterminowany timestamp (max 15 min)')
        print('3. Brakujące wymagane pola')
        print('4. Nieprawidłowy timezone')
        print('\nSprawdź logi Fiserv dla szczegółów.')
    elif success_count < len(results):
        print('\n⚠️  CZĘŚCIOWY SUKCES')
        print('Sprawdź które konfiguracje działają.')
    else:
        print('\n✅ WSZYSTKIE TESTY ZAKOŃCZONE SUKCESEM!')

if __name__ == '__main__':
    main()