import base64
import hashlib
import hmac

from app.utils.fiserv_connect import compose_hash_string, compute_hash_extended

# Dane z debugera/supportu (przykład z rozmowy):
# String to sign (wartości połączone pipe, kolejność wg nazw pól):
# 10.00|combinedpage|985|DEBUG-20250729113356|760995999|Europe/Warsaw|2025:07:29-09:33:56|sale
# Secret:
# j}2W3P)Lwv
# Expected Base64 HMAC-SHA256:
# aDMsqleb5UDagk6UQ5PMtl5DPSwYh7yxYFT50wLj+dA=

EXAMPLE_PAYLOAD = {
    "chargetotal": "10.00",
    "checkoutoption": "combinedpage",
    "currency": "985",
    "oid": "DEBUG-20250729113356",
    "storename": "760995999",
    "timezone": "Europe/Warsaw",
    "txndatetime": "2025:07:29-09:33:56",
    "txntype": "sale",
}

EXAMPLE_SECRET = "j}2W3P)Lwv"
EXPECTED_B64 = "aDMsqleb5UDagk6UQ5PMtl5DPSwYh7yxYFT50wLj+dA="


def reference_hmac_b64(message: str, secret: str) -> str:
    dig = hmac.new(secret.encode("utf-8"), message.encode("utf-8"), hashlib.sha256).digest()
    return base64.b64encode(dig).decode("utf-8")


def test_compose_hash_string_order_and_value():
    s = compose_hash_string(EXAMPLE_PAYLOAD)
    assert (
        s == "10.00|combinedpage|985|DEBUG-20250729113356|760995999|Europe/Warsaw|2025:07:29-09:33:56|sale"
    ), f"Unexpected string to sign: {s}"


def test_compute_hash_extended_matches_expected():
    # Testujemy naszą funkcję
    got = compute_hash_extended(EXAMPLE_PAYLOAD, EXAMPLE_SECRET)
    assert got == EXPECTED_B64, f"compute_hash_extended mismatch: {got} != {EXPECTED_B64}"

    # Dla pewności liczymy referencyjnie tu w teście (powinno też wyjść to samo)
    msg = compose_hash_string(EXAMPLE_PAYLOAD)
    ref = reference_hmac_b64(msg, EXAMPLE_SECRET)
    assert ref == EXPECTED_B64, f"reference_hmac_b64 mismatch: {ref} != {EXPECTED_B64}"


if __name__ == "__main__":
    # Minimalny runner bez pytesta:
    try:
        test_compose_hash_string_order_and_value()
        test_compute_hash_extended_matches_expected()
        print("All tests passed.")
    except AssertionError as e:
        print("Test failed:", e)
        raise
