#!/usr/bin/env python3
"""
Test sugestii z analizy użytkownika
"""

import os
from datetime import datetime
from app.utils.fiserv_ipg_client import FiservIPGClient
import webbrowser
import hmac
import hashlib
import base64

def test_suggestions():
    """Test wszystkich sugestii z analizy"""
    
    print("="*60)
    print("TEST SUGESTII Z ANALIZY")
    print("="*60)
    
    client = FiservIPGClient()
    
    # Prawdziwe URL-e z ngrok
    success_url = "https://77597ddbcc37.ngrok-free.app/api/payments/success"
    failure_url = "https://77597ddbcc37.ngrok-free.app/api/payments/failure"
    
    # HTML
    html = f"""<!DOCTYPE html>
<html>
<head>
    <title>Test Sugestii z Analizy</title>
    <style>
        body {{ 
            font-family: Arial, sans-serif; 
            max-width: 1200px; 
            margin: 20px auto; 
            padding: 20px;
            background: #f5f5f5;
        }}
        .test-section {{
            background: white;
            padding: 20px;
            margin: 20px 0;
            border-radius: 10px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }}
        .success {{ background: #d4edda; border: 2px solid #28a745; }}
        .warning {{ background: #fff3cd; border: 2px solid #ffc107; }}
        button {{
            background: #007bff;
            color: white;
            border: none;
            padding: 10px 20px;
            margin: 5px;
            border-radius: 5px;
            cursor: pointer;
        }}
        button:hover {{ background: #0056b3; }}
        .debug {{
            background: #f8f9fa;
            padding: 10px;
            border: 1px solid #dee2e6;
            border-radius: 5px;
            margin: 10px 0;
            font-family: monospace;
            font-size: 12px;
        }}
    </style>
</head>
<body>
    <h1>🔍 Test Sugestii z Analizy</h1>
    
    <div class="test-section warning">
        <h3>📝 Sugestie do przetestowania:</h3>
        <ol>
            <li>✅ Hash - POPRAWNY (już zweryfikowany)</li>
            <li>🔄 Prawdziwe URL-e zamiast example.com</li>
            <li>🔄 Inne waluty (EUR, USD)</li>
            <li>🔄 Bez checkoutoption lub combinedpage</li>
            <li>🔄 Inne strefy czasowe (UTC, Europe/Dublin)</li>
        </ol>
    </div>
"""
    
    tests = []
    
    # Test 1: Z prawdziwymi URL-ami (ngrok)
    test1_fields = {
        'storename': client.store_id,
        'txntype': 'sale',
        'timezone': 'Europe/Berlin',
        'txndatetime': datetime.utcnow().strftime("%Y:%m:%d-%H:%M:%S"),
        'chargetotal': '10.00',
        'currency': '985',  # PLN
        'checkoutoption': 'classic',
        'oid': f'REAL-URLS-{datetime.now().strftime("%Y%m%d%H%M%S")}',
        'responseSuccessURL': success_url,
        'responseFailURL': failure_url,
        'hash_algorithm': 'HMACSHA256'
    }
    tests.append(("Prawdziwe URL-e (ngrok)", test1_fields))
    
    # Test 2: EUR zamiast PLN
    test2_fields = test1_fields.copy()
    test2_fields['currency'] = '978'  # EUR
    test2_fields['oid'] = f'EUR-TEST-{datetime.now().strftime("%Y%m%d%H%M%S")}'
    tests.append(("Waluta EUR", test2_fields))
    
    # Test 3: USD
    test3_fields = test1_fields.copy()
    test3_fields['currency'] = '840'  # USD
    test3_fields['oid'] = f'USD-TEST-{datetime.now().strftime("%Y%m%d%H%M%S")}'
    tests.append(("Waluta USD", test3_fields))
    
    # Test 4: Bez checkoutoption
    test4_fields = test1_fields.copy()
    del test4_fields['checkoutoption']
    test4_fields['oid'] = f'NO-CHECKOUT-{datetime.now().strftime("%Y%m%d%H%M%S")}'
    tests.append(("Bez checkoutoption", test4_fields))
    
    # Test 5: combinedpage (mimo że dawał validationError)
    test5_fields = test1_fields.copy()
    test5_fields['checkoutoption'] = 'combinedpage'
    test5_fields['oid'] = f'COMBINED-{datetime.now().strftime("%Y%m%d%H%M%S")}'
    tests.append(("Checkout: combinedpage", test5_fields))
    
    # Test 6: Timezone UTC
    test6_fields = test1_fields.copy()
    test6_fields['timezone'] = 'UTC'
    test6_fields['oid'] = f'UTC-TEST-{datetime.now().strftime("%Y%m%d%H%M%S")}'
    tests.append(("Timezone: UTC", test6_fields))
    
    # Test 7: Timezone Europe/Dublin
    test7_fields = test1_fields.copy()
    test7_fields['timezone'] = 'Europe/Dublin'
    test7_fields['oid'] = f'DUBLIN-TEST-{datetime.now().strftime("%Y%m%d%H%M%S")}'
    tests.append(("Timezone: Europe/Dublin", test7_fields))
    
    # Test 8: Absolutne minimum (tylko wymagane pola)
    test8_fields = {
        'storename': client.store_id,
        'txntype': 'sale',
        'chargetotal': '10.00',
        'currency': '978',  # EUR
        'hash_algorithm': 'HMACSHA256'
    }
    tests.append(("Absolutne minimum + EUR", test8_fields))
    
    # Generuj formularze
    for name, fields in tests:
        html += f"""
    <div class="test-section">
        <h3>{name}</h3>
        <div class="debug">
"""
        
        # Pokaż pola (bez hash_algorithm)
        display_fields = {k: v for k, v in fields.items() if k != 'hash_algorithm'}
        for k, v in sorted(display_fields.items()):
            html += f"            {k}: {v}<br>\n"
        
        # Oblicz hash
        hash_fields = {k: v for k, v in fields.items() if k not in ['hash_algorithm', 'hashExtended']}
        sorted_hash_fields = sorted(hash_fields.items())
        hash_string = '|'.join(str(v) for k, v in sorted_hash_fields)
        
        hash_bytes = hmac.new(
            client.shared_secret.encode('utf-8'),
            hash_string.encode('utf-8'),
            hashlib.sha256
        ).digest()
        hash_value = base64.b64encode(hash_bytes).decode('utf-8')
        
        fields['hashExtended'] = hash_value
        
        html += f"""            <br>Hash string: {hash_string[:60]}...
            <br>Hash: {hash_value[:40]}...
        </div>
        
        <form method="POST" action="{client.gateway_url}" target="_blank">
"""
        for k, v in fields.items():
            html += f'            <input type="hidden" name="{k}" value="{v}">\n'
        
        html += f"""            <button type="submit">Testuj: {name}</button>
        </form>
    </div>
"""
    
    # Podsumowanie
    html += """
    <div class="test-section success">
        <h3>✅ Co już wiemy:</h3>
        <ul>
            <li>Hash jest obliczany POPRAWNIE</li>
            <li>checkoutoption='classic' przechodzi walidację</li>
            <li>Problem jest z przetwarzaniem transakcji</li>
        </ul>
        
        <h3>🎯 Najbardziej obiecujące testy:</h3>
        <ol>
            <li><strong>EUR/USD</strong> - może PLN nie jest obsługiwane</li>
            <li><strong>Bez checkoutoption</strong> - może to rozwiąże problem</li>
            <li><strong>Prawdziwe URL-e</strong> - eliminuje potencjalne problemy z example.com</li>
        </ol>
    </div>
    
    <div class="test-section warning">
        <h3>📝 Zapisz wyniki:</h3>
        <p>Dla każdego testu zapisz:</p>
        <ul>
            <li>Czy przeszedł walidację (nie ma validationError)?</li>
            <li>Czy doszedł do strony płatności?</li>
            <li>Jaki dokładnie błąd otrzymałeś?</li>
        </ul>
    </div>
</body>
</html>"""
    
    filename = "test_analysis_suggestions.html"
    with open(filename, 'w') as f:
        f.write(html)
    
    print(f"\n✅ Test zapisany jako: {filename}")
    print("\n🎯 Przetestuj szczególnie:")
    print("1. EUR/USD - może PLN nie jest obsługiwane")
    print("2. Bez checkoutoption - może to rozwiąże problem")
    print("3. Prawdziwe URL-e z ngrok")
    
    # Otwórz w przeglądarce
    webbrowser.open(f"file://{os.path.abspath(filename)}")

if __name__ == "__main__":
    test_suggestions()