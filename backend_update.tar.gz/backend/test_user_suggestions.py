#!/usr/bin/env python3
"""
Test wszystkich sugestii użytkownika dotyczących validationError
"""

from datetime import datetime, timezone
from app.utils.fiserv_ipg_client import FiservIPGClient
import hmac
import hashlib
import base64
import json

def test_user_suggestions():
    """Test wszystkich sugestii od użytkownika"""
    
    print("="*60)
    print("TEST SUGESTII UŻYTKOWNIKA")
    print("="*60)
    
    client = FiservIPGClient()
    
    # HTML
    html = f"""<!DOCTYPE html>
<html>
<head>
    <title>Test Sugestii Użytkownika</title>
    <meta charset="UTF-8">
    <style>
        body {{ 
            font-family: Arial, sans-serif; 
            max-width: 1200px; 
            margin: 20px auto; 
            padding: 20px;
            background: #f5f5f5;
        }}
        .test-section {{
            background: white;
            padding: 20px;
            margin: 15px 0;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }}
        .warning {{
            background: #fff3cd;
            border: 2px solid #ffc107;
            padding: 15px;
            margin: 20px 0;
            border-radius: 5px;
        }}
        .success {{
            background: #d4edda;
            border: 2px solid #28a745;
            padding: 15px;
            margin: 20px 0;
            border-radius: 5px;
        }}
        button {{
            background: #007bff;
            color: white;
            border: none;
            padding: 12px 24px;
            margin: 5px;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
        }}
        button:hover {{ background: #0056b3; }}
        .code {{
            background: #f8f9fa;
            padding: 10px;
            border: 1px solid #dee2e6;
            font-family: monospace;
            margin: 10px 0;
            overflow-x: auto;
        }}
        .field {{
            background: #e9ecef;
            padding: 5px 10px;
            margin: 2px 0;
            font-family: monospace;
        }}
    </style>
</head>
<body>
    <h1>🔍 Test Wszystkich Sugestii Użytkownika</h1>
    
    <div class="warning">
        <h3>⚠️ Sugestie do sprawdzenia:</h3>
        <ol>
            <li>Sprawdzenie dokładności hash (każdy znak)</li>
            <li>Poprawność hash_algorithm (HMACSHA256)</li>
            <li>Dodanie adresów URL zwrotnych</li>
            <li>Spójność timezone i txndatetime</li>
            <li>Włączenie "Allow URLs to be overwritten"</li>
        </ol>
    </div>
"""
    
    # Test 1: Z pełnymi URL-ami i dokładnym hashem
    order_id = f"FULL-TEST-{datetime.now().strftime('%Y%m%d%H%M%S')}"
    txn_datetime = datetime.now(timezone.utc).strftime("%Y:%m:%d-%H:%M:%S")
    
    fields = {
        'storename': '760995999',
        'txntype': 'sale',
        'timezone': 'Europe/Berlin',
        'txndatetime': txn_datetime,
        'chargetotal': '10.00',
        'currency': '985',
        'checkoutoption': 'combinedpage',
        'oid': order_id,
        'hash_algorithm': 'HMACSHA256',
        'responseSuccessURL': 'https://yourapp.ngrok.app/api/payments/success',
        'responseFailURL': 'https://yourapp.ngrok.app/api/payments/failure', 
        'transactionNotificationURL': 'https://yourapp.ngrok.app/api/payments/webhooks/fiserv'
    }
    
    # Oblicz hash DOKŁADNIE
    hash_fields = {k: v for k, v in fields.items() if k not in ['hash_algorithm', 'hashExtended']}
    sorted_fields = sorted(hash_fields.items())
    hash_string = '|'.join(str(v) for k, v in sorted_fields)
    
    # HMAC-SHA256
    hash_bytes = hmac.new(
        client.shared_secret.encode('utf-8'),
        hash_string.encode('utf-8'),
        hashlib.sha256
    ).digest()
    hash_value = base64.b64encode(hash_bytes).decode('utf-8')
    
    fields['hashExtended'] = hash_value
    
    html += f"""
    <div class="test-section">
        <h3>Test 1: Pełna konfiguracja z URL-ami</h3>
        
        <div class="code">
            <strong>String do hasha (posortowany):</strong><br>
            {hash_string}
        </div>
        
        <div class="code">
            <strong>Obliczony hash (Base64):</strong><br>
            {hash_value}
        </div>
        
        <div class="code">
            <strong>Sprawdzenie każdego znaku hasha:</strong><br>
"""
    
    # Pokaż hash znak po znaku
    for i, char in enumerate(hash_value):
        if i % 10 == 0:
            html += f"<br>[{i:02d}] "
        html += f"{char} "
    
    html += f"""
        </div>
        
        <form method="POST" action="{client.gateway_url}" target="_blank">
"""
    
    for k, v in fields.items():
        html += f'            <input type="hidden" name="{k}" value="{v}">\n'
    
    html += """            <button type="submit">🚀 Test z pełnymi URL-ami</button>
        </form>
    </div>
"""
    
    # Test 2: Minimalna konfiguracja bez URL-i
    order_id2 = f"MIN-TEST-{datetime.now().strftime('%Y%m%d%H%M%S')}"
    txn_datetime2 = datetime.now(timezone.utc).strftime("%Y:%m:%d-%H:%M:%S")
    
    fields2 = {
        'storename': '760995999',
        'txntype': 'sale',
        'timezone': 'Europe/Berlin',
        'txndatetime': txn_datetime2,
        'chargetotal': '10.00',
        'currency': '985',
        'checkoutoption': 'combinedpage',
        'oid': order_id2,
        'hash_algorithm': 'HMACSHA256'
    }
    
    # Hash dla minimalnej konfiguracji
    hash_fields2 = {k: v for k, v in fields2.items() if k not in ['hash_algorithm', 'hashExtended']}
    sorted_fields2 = sorted(hash_fields2.items())
    hash_string2 = '|'.join(str(v) for k, v in sorted_fields2)
    
    hash_bytes2 = hmac.new(
        client.shared_secret.encode('utf-8'),
        hash_string2.encode('utf-8'),
        hashlib.sha256
    ).digest()
    hash_value2 = base64.b64encode(hash_bytes2).decode('utf-8')
    
    fields2['hashExtended'] = hash_value2
    
    html += f"""
    <div class="test-section">
        <h3>Test 2: Minimalna konfiguracja (bez URL-i)</h3>
        
        <div class="code">
            <strong>String do hasha:</strong><br>
            {hash_string2}
        </div>
        
        <form method="POST" action="{client.gateway_url}" target="_blank">
"""
    
    for k, v in fields2.items():
        html += f'            <input type="hidden" name="{k}" value="{v}">\n'
    
    html += """            <button type="submit">🚀 Test bez URL-i</button>
        </form>
    </div>
"""
    
    # Test 3: Test z alternatywnym secret
    html += """
    <div class="test-section">
        <h3>Test 3: Alternatywne Shared Secrets</h3>
"""
    
    alt_secrets = [
        'c7dP/$5PBx',
        'aGOkU61VoIl5AWApLL7avcCpIVZxVGG6jYGVQib8xuG'
    ]
    
    for secret in alt_secrets:
        order_id3 = f"ALT-{datetime.now().strftime('%Y%m%d%H%M%S')}"
        
        fields3 = {
            'storename': '760995999',
            'txntype': 'sale',
            'timezone': 'Europe/Berlin',
            'txndatetime': datetime.now(timezone.utc).strftime("%Y:%m:%d-%H:%M:%S"),
            'chargetotal': '10.00',
            'currency': '985',
            'checkoutoption': 'combinedpage',
            'oid': order_id3,
            'hash_algorithm': 'HMACSHA256'
        }
        
        # Hash z alternatywnym secretem
        hash_fields3 = {k: v for k, v in fields3.items() if k not in ['hash_algorithm', 'hashExtended']}
        sorted_fields3 = sorted(hash_fields3.items())
        hash_string3 = '|'.join(str(v) for k, v in sorted_fields3)
        
        hash_bytes3 = hmac.new(
            secret.encode('utf-8'),
            hash_string3.encode('utf-8'),
            hashlib.sha256
        ).digest()
        hash_value3 = base64.b64encode(hash_bytes3).decode('utf-8')
        
        fields3['hashExtended'] = hash_value3
        
        html += f"""
        <div style="margin: 10px 0; padding: 10px; background: #f0f0f0;">
            <strong>Secret: {secret}</strong><br>
            <form method="POST" action="{client.gateway_url}" target="_blank" style="display: inline;">
"""
        
        for k, v in fields3.items():
            html += f'                <input type="hidden" name="{k}" value="{v}">\n'
        
        html += """                <button type="submit">Test</button>
            </form>
        </div>
"""
    
    html += """    </div>"""
    
    # Porady
    html += """
    <div class="success">
        <h3>✅ Lista kontrolna:</h3>
        <ol>
            <li><strong>hash_algorithm</strong> = HMACSHA256 (dokładnie tak, bez spacji)</li>
            <li><strong>hashExtended</strong> = Base64 z HMAC-SHA256</li>
            <li><strong>Sortowanie pól</strong> = alfabetycznie, bez hash_algorithm i hashExtended</li>
            <li><strong>Separator</strong> = | (pipe)</li>
            <li><strong>Encoding</strong> = UTF-8</li>
            <li><strong>timezone</strong> = Europe/Berlin</li>
            <li><strong>txndatetime</strong> = format YYYY:MM:DD-HH:MM:SS</li>
        </ol>
    </div>
    
    <div class="warning">
        <h3>🔧 W Virtual Terminal sprawdź:</h3>
        <ul>
            <li>Customization → URL settings → "Allow URLs to be overwritten" = ✅</li>
            <li>Combined Page → czy jest skonfigurowana</li>
            <li>Store Settings → czy Combined Page jest aktywna</li>
        </ul>
    </div>
    
    <div class="test-section">
        <h3>📧 Jeśli nadal nie działa:</h3>
        <p>Wyślij do supportu Fiserv:</p>
        <ul>
            <li>Store ID: 760995999</li>
            <li>Problem: validationError dla Combined Page</li>
            <li>Prośba o prawidłowy Shared Secret</li>
            <li>Prośba o potwierdzenie że Combined Page jest aktywna</li>
        </ul>
    </div>
</body>
</html>"""
    
    with open('test_user_suggestions.html', 'w', encoding='utf-8') as f:
        f.write(html)
    
    print("\n✅ Test zapisany jako: test_user_suggestions.html")
    print("\n📋 Co testujemy:")
    print("1. Dokładność hash (każdy znak)")
    print("2. Poprawność hash_algorithm")
    print("3. Wersja z URL-ami i bez")
    print("4. Alternatywne Shared Secrets")
    print("5. Spójność timezone i txndatetime")
    
    import webbrowser
    import os
    webbrowser.open(f"file://{os.path.abspath('test_user_suggestions.html')}")

if __name__ == "__main__":
    test_user_suggestions()