#!/usr/bin/env python3
"""
Test stopniowego dodawania pól - znajdź które pole powoduje błąd
"""

from datetime import datetime, timedelta
import hmac
import hashlib
import base64

def test_incremental():
    """Stopniowo dodawaj pola"""
    
    print("="*60)
    print("TEST STOPNIOWEGO DODAWANIA PÓL")
    print("="*60)
    
    shared_secret = "j}2W3P)Lwv"
    warsaw_now = datetime.utcnow() + timedelta(hours=1)  # Czas zimowy
    
    # Różne zestawy pól do testowania
    test_sets = [
        {
            "name": "1. Minimum (działa!)",
            "fields": {
                'storename': '760995999',
                'chargetotal': '10.00',
                'currency': '985'
            }
        },
        {
            "name": "2. + txntype",
            "fields": {
                'storename': '760995999',
                'chargetotal': '10.00',
                'currency': '985',
                'txntype': 'sale'
            }
        },
        {
            "name": "3. + checkoutoption",
            "fields": {
                'storename': '760995999',
                'chargetotal': '10.00',
                'currency': '985',
                'txntype': 'sale',
                'checkoutoption': 'combinedpage'
            }
        },
        {
            "name": "4. + timezone",
            "fields": {
                'storename': '760995999',
                'chargetotal': '10.00',
                'currency': '985',
                'txntype': 'sale',
                'checkoutoption': 'combinedpage',
                'timezone': 'Europe/Warsaw'
            }
        },
        {
            "name": "5. + oid (prosty)",
            "fields": {
                'storename': '760995999',
                'chargetotal': '10.00',
                'currency': '985',
                'txntype': 'sale',
                'checkoutoption': 'combinedpage',
                'timezone': 'Europe/Warsaw',
                'oid': f'TEST{warsaw_now.strftime("%Y%m%d%H%M%S")}'
            }
        },
        {
            "name": "6. + txndatetime",
            "fields": {
                'storename': '760995999',
                'chargetotal': '10.00',
                'currency': '985',
                'txntype': 'sale',
                'checkoutoption': 'combinedpage',
                'timezone': 'Europe/Warsaw',
                'oid': f'TEST{warsaw_now.strftime("%Y%m%d%H%M%S")}',
                'txndatetime': warsaw_now.strftime("%Y:%m:%d-%H:%M:%S")
            }
        },
        {
            "name": "7. + hash (BEZ hash_algorithm)",
            "fields": {
                'storename': '760995999',
                'chargetotal': '10.00',
                'currency': '985',
                'txntype': 'sale',
                'checkoutoption': 'combinedpage',
                'timezone': 'Europe/Warsaw',
                'oid': f'NOHASH{warsaw_now.strftime("%Y%m%d%H%M%S")}',
                'txndatetime': warsaw_now.strftime("%Y:%m:%d-%H:%M:%S")
            },
            "add_hash": True,
            "use_hash_algorithm": False
        },
        {
            "name": "8. + hash + hash_algorithm",
            "fields": {
                'storename': '760995999',
                'chargetotal': '10.00',
                'currency': '985',
                'txntype': 'sale',
                'checkoutoption': 'combinedpage',
                'timezone': 'Europe/Warsaw',
                'oid': f'FULL{warsaw_now.strftime("%Y%m%d%H%M%S")}',
                'txndatetime': warsaw_now.strftime("%Y:%m:%d-%H:%M:%S"),
                'hash_algorithm': 'HMACSHA256'
            },
            "add_hash": True,
            "use_hash_algorithm": True
        }
    ]
    
    html = f"""<!DOCTYPE html>
<html>
<head>
    <title>Test Incremental</title>
    <meta charset="UTF-8">
    <style>
        body {{ font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }}
        .test {{ background: white; padding: 20px; margin: 15px 0; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }}
        .success {{ background: #d4edda; border-left: 4px solid #28a745; }}
        .info {{ background: #e3f2fd; border-left: 4px solid #2196f3; }}
        button {{ background: #007bff; color: white; padding: 10px 20px; border: none; cursor: pointer; margin: 5px; }}
        button:hover {{ background: #0056b3; }}
        .fields {{ background: #f8f9fa; padding: 10px; margin: 10px 0; font-family: monospace; font-size: 12px; }}
        h3 {{ margin-top: 0; }}
    </style>
</head>
<body>
    <h1>🔍 Test stopniowego dodawania pól</h1>
    
    <div class="test success">
        <h3>✅ Wiemy że minimum działa!</h3>
        <p>storename + chargetotal + currency = przechodzi walidację</p>
    </div>
"""
    
    for test in test_sets:
        fields = test['fields'].copy()
        
        # Dodaj hash jeśli wymagany
        if test.get('add_hash'):
            hash_fields = {k: v for k, v in fields.items() if k not in ['hash_algorithm', 'hashExtended']}
            sorted_fields = sorted(hash_fields.items())
            hash_string = '|'.join(str(v) for k, v in sorted_fields)
            
            hash_value = base64.b64encode(
                hmac.new(shared_secret.encode('utf-8'), hash_string.encode('utf-8'), hashlib.sha256).digest()
            ).decode('utf-8')
            
            fields['hashExtended'] = hash_value
            
            hash_info = f"<br>Hash string: <code>{hash_string[:50]}...</code><br>Hash: <code>{hash_value[:20]}...</code>"
        else:
            hash_info = ""
        
        html += f"""
    <div class="test">
        <h3>{test['name']}</h3>
        <div class="fields">
"""
        
        # Pokaż pola
        for k, v in fields.items():
            if k == 'hashExtended':
                html += f"            {k}: {v[:20]}...<br>\n"
            else:
                html += f"            {k}: {v}<br>\n"
        
        html += f"""        </div>
        {hash_info}
        
        <form method="POST" action="https://test.ipg-online.com/connect/gateway/processing" target="_blank">
"""
        
        for k, v in fields.items():
            html += f'            <input type="hidden" name="{k}" value="{v}">\n'
        
        html += f"""            <button type="submit">TEST</button>
        </form>
    </div>
"""
    
    # Test alternatywny - może problem z Combined Page?
    html += """
    <div class="test info">
        <h3>💡 Test alternatywny - Classic zamiast Combined</h3>
        <form method="POST" action="https://test.ipg-online.com/connect/gateway/processing" target="_blank">
"""
    
    classic_fields = {
        'storename': '760995999',
        'chargetotal': '10.00',
        'currency': '985',
        'txntype': 'sale',
        'checkoutoption': 'classic',  # ZMIANA!
        'timezone': 'Europe/Warsaw',
        'oid': f'CLASSIC{warsaw_now.strftime("%Y%m%d%H%M%S")}',
        'hash_algorithm': 'HMACSHA256'
    }
    
    # Hash dla classic
    hash_fields = {k: v for k, v in classic_fields.items() if k not in ['hash_algorithm', 'hashExtended']}
    sorted_fields = sorted(hash_fields.items())
    hash_string = '|'.join(str(v) for k, v in sorted_fields)
    hash_value = base64.b64encode(
        hmac.new(shared_secret.encode('utf-8'), hash_string.encode('utf-8'), hashlib.sha256).digest()
    ).decode('utf-8')
    classic_fields['hashExtended'] = hash_value
    
    for k, v in classic_fields.items():
        html += f'            <input type="hidden" name="{k}" value="{v}">\n'
    
    html += """            <button type="submit">TEST CLASSIC</button>
        </form>
        <p>Może Combined Page nie jest aktywna?</p>
    </div>
    
    <div class="test">
        <h3>📋 Plan debugowania:</h3>
        <ol>
            <li>Sprawdź który test przestaje działać</li>
            <li>To wskaże problematyczne pole</li>
            <li>Jeśli wszystko oprócz hash działa = problem z secret</li>
            <li>Jeśli checkoutoption=classic działa = problem z Combined Page</li>
        </ol>
    </div>
</body>
</html>"""
    
    with open('test_incremental.html', 'w', encoding='utf-8') as f:
        f.write(html)
    
    print("\n✅ Test zapisany jako: test_incremental.html")
    print("\nKOLEJNOŚĆ TESTÓW:")
    for i, test in enumerate(test_sets, 1):
        print(f"{i}. {test['name']}")
    
    import webbrowser
    import os
    webbrowser.open(f"file://{os.path.abspath('test_incremental.html')}")

if __name__ == "__main__":
    test_incremental()