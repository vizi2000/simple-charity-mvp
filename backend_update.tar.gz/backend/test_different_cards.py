#!/usr/bin/env python3
"""
Test różnych kart testowych Fiserv
"""

import os
from datetime import datetime
from app.utils.fiserv_ipg_client import FiservIPGClient
import webbrowser

def test_all_cards():
    """Generuj testy dla wszystkich kart testowych"""
    
    print("="*60)
    print("TEST WSZYSTKICH KART TESTOWYCH FISERV")
    print("="*60)
    
    # Oficjalne karty z dokumentacji
    test_cards = [
        {"name": "Visa (oficjalna)", "number": "4005550000000019", "cvv": "111", "exp": "12/25"},
        {"name": "Mastercard (oficjalna)", "number": "5204740000001002", "cvv": "111", "exp": "12/25"},
        {"name": "Visa (alternatywna)", "number": "4111111111111111", "cvv": "111", "exp": "12/25"},
        {"name": "Visa (4242...)", "number": "4242424242424242", "cvv": "123", "exp": "12/25"},
        {"name": "Mastercard (5555...)", "number": "5555555555554444", "cvv": "123", "exp": "12/25"},
    ]
    
    # Różne waluty do testowania
    currencies = [
        {"code": "985", "name": "PLN"},
        {"code": "978", "name": "EUR"},
        {"code": "840", "name": "USD"}
    ]
    
    client = FiservIPGClient()
    
    # HTML z instrukcjami
    html = f"""<!DOCTYPE html>
<html>
<head>
    <title>Test Kart Fiserv</title>
    <style>
        body {{ 
            font-family: Arial, sans-serif; 
            max-width: 1200px; 
            margin: 20px auto; 
            padding: 20px;
            background: #f5f5f5;
        }}
        .card-test {{
            background: white;
            padding: 20px;
            margin: 20px 0;
            border-radius: 10px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }}
        .card-info {{
            background: #e3f2fd;
            padding: 15px;
            border-radius: 5px;
            margin: 10px 0;
            font-family: monospace;
        }}
        button {{
            background: #2196F3;
            color: white;
            border: none;
            padding: 12px 24px;
            font-size: 16px;
            border-radius: 5px;
            cursor: pointer;
            margin: 5px;
        }}
        button:hover {{
            background: #1976D2;
        }}
        .warning {{
            background: #fff3cd;
            border: 1px solid #ffc107;
            padding: 15px;
            border-radius: 5px;
            margin: 20px 0;
        }}
        .instructions {{
            background: #d1ecf1;
            border: 1px solid #17a2b8;
            padding: 15px;
            border-radius: 5px;
            margin: 20px 0;
        }}
    </style>
</head>
<body>
    <h1>🔍 Test Wszystkich Kart Testowych Fiserv</h1>
    
    <div class="warning">
        <h3>⚠️ Ważne!</h3>
        <p>Testuj każdą kartę osobno i zapisz dokładnie jaki błąd otrzymujesz.</p>
        <p>To pomoże zidentyfikować czy problem jest z kartą, walutą czy konfiguracją konta.</p>
    </div>
    
    <div class="instructions">
        <h3>📝 Instrukcja testowania:</h3>
        <ol>
            <li>Kliknij przycisk dla danej karty i waluty</li>
            <li>Na stronie Fiserv wprowadź dane karty</li>
            <li>Zapisz jaki otrzymałeś błąd</li>
            <li>Spróbuj następną kombinację</li>
        </ol>
    </div>
"""
    
    # Generuj testy dla każdej karty
    test_num = 1
    for card in test_cards:
        html += f"""
    <div class="card-test">
        <h2>{card['name']}</h2>
        <div class="card-info">
            Numer: {card['number']}<br>
            CVV: {card['cvv']}<br>
            Data ważności: {card['exp']}
        </div>
"""
        
        # Test z każdą walutą
        for currency in currencies:
            order_id = f"CARD-TEST-{test_num}-{datetime.now().strftime('%Y%m%d%H%M%S')}"
            
            form_data = client.create_payment_form_data(
                amount=10.00,
                order_id=order_id,
                description=f"Test {card['name']} {currency['name']}",
                success_url="https://example.com/success",
                failure_url="https://example.com/failure"
            )
            
            # Zmień walutę
            form_data['form_fields']['currency'] = currency['code']
            
            # Przelicz hash z nową walutą
            sorted_fields = sorted([
                (k, v) for k, v in form_data['form_fields'].items() 
                if k not in ['hashExtended', 'hash_algorithm']
            ])
            values_to_hash = '|'.join(str(v) for k, v in sorted_fields)
            
            import hmac
            import hashlib
            import base64
            
            hash_value = hmac.new(
                client.shared_secret.encode('utf-8'),
                values_to_hash.encode('utf-8'),
                hashlib.sha256
            ).digest()
            form_data['form_fields']['hashExtended'] = base64.b64encode(hash_value).decode('utf-8')
            
            html += f"""
        <form method="POST" action="{form_data['form_action']}" target="_blank" style="display: inline;">
"""
            for key, value in form_data['form_fields'].items():
                html += f'            <input type="hidden" name="{key}" value="{value}">\n'
            
            html += f"""            <button type="submit">Test {currency['name']} ({currency['code']})</button>
        </form>
"""
            test_num += 1
        
        html += """    </div>
"""
    
    # Sekcja wyników
    html += """
    <div class="card-test">
        <h2>📊 Zapisz wyniki:</h2>
        <p>Dla każdej karty zapisz:</p>
        <ul>
            <li>Czy doszło do strony płatności?</li>
            <li>Jaki komunikat błędu otrzymałeś?</li>
            <li>Czy błąd był przed czy po wprowadzeniu danych karty?</li>
        </ul>
        
        <h3>Możliwe błędy:</h3>
        <ul>
            <li><strong>"Unknown application error"</strong> - problem z konfiguracją</li>
            <li><strong>"Invalid card number"</strong> - karta nieobsługiwana</li>
            <li><strong>"Transaction declined"</strong> - karta odrzucona</li>
            <li><strong>"Currency not supported"</strong> - waluta nieobsługiwana</li>
            <li><strong>"3D Secure required"</strong> - wymaga dodatkowej autoryzacji</li>
        </ul>
    </div>
    
    <div class="warning">
        <h3>🚨 Jeśli wszystkie karty dają ten sam błąd:</h3>
        <p>To potwierdza że problem jest z konfiguracją konta testowego, nie z integracją!</p>
        <p>Wyślij wyniki testów do supportu Fiserv.</p>
    </div>
</body>
</html>"""
    
    filename = "test_all_cards.html"
    with open(filename, 'w') as f:
        f.write(html)
    
    print(f"\n✅ Test zapisany jako: {filename}")
    print("\nPrzetestuj każdą kombinację karty i waluty.")
    print("Zapisz dokładnie jakie błędy otrzymujesz!")
    
    # Otwórz w przeglądarce
    webbrowser.open(f"file://{os.path.abspath(filename)}")

if __name__ == "__main__":
    test_all_cards()