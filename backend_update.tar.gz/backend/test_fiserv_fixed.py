#!/usr/bin/env python3
"""
Test z poprawkami od Fiserv Support
"""

from datetime import datetime, timezone
from app.utils.fiserv_ipg_client import FiservIPGClient
import hmac
import hashlib
import base64

def test_fiserv_fixed():
    """Test z ustawieniami potwierdzonymi przez Fiserv"""
    
    print("="*60)
    print("TEST Z POPRAWKAMI OD FISERV")
    print("="*60)
    
    client = FiservIPGClient()
    
    # Dane potwierdzone przez Fiserv
    print("\n✅ Ustawienia potwierdzone przez Fiserv:")
    print(f"- Shared Secret: {client.shared_secret}")
    print("- timezone: Europe/Warsaw")
    print("- currency: 985")
    print("- checkoutoption: combinedpage")
    
    # HTML
    html = f"""<!DOCTYPE html>
<html>
<head>
    <title>Test Fiserv - Poprawione</title>
    <meta charset="UTF-8">
    <style>
        body {{ 
            font-family: Arial, sans-serif; 
            max-width: 1000px; 
            margin: 20px auto; 
            padding: 20px;
            background: #f5f5f5;
        }}
        .test-section {{
            background: white;
            padding: 20px;
            margin: 15px 0;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }}
        .success {{
            background: #d4edda;
            border: 2px solid #28a745;
            padding: 15px;
            margin: 20px 0;
            border-radius: 5px;
        }}
        button {{
            background: #28a745;
            color: white;
            border: none;
            padding: 15px 30px;
            margin: 5px;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
            font-size: 16px;
        }}
        button:hover {{ background: #218838; }}
        .code {{
            background: #f8f9fa;
            padding: 10px;
            border: 1px solid #dee2e6;
            font-family: monospace;
            margin: 10px 0;
        }}
    </style>
</head>
<body>
    <h1>🎯 Test z Poprawkami od Fiserv Support</h1>
    
    <div class="success">
        <h3>✅ Potwierdzone ustawienia:</h3>
        <ul>
            <li><strong>Shared Secret</strong>: j}}2W3P)Lwv</li>
            <li><strong>timezone</strong>: Europe/Warsaw</li>
            <li><strong>currency</strong>: 985 (PLN)</li>
            <li><strong>checkoutoption</strong>: combinedpage</li>
        </ul>
    </div>
"""
    
    # Test 1: Z URL-ami
    order_id = f"FISERV-FIXED-{datetime.now().strftime('%Y%m%d%H%M%S')}"
    txn_datetime = datetime.now(timezone.utc).strftime("%Y:%m:%d-%H:%M:%S")
    
    fields = {
        'storename': '760995999',
        'txntype': 'sale',
        'timezone': 'Europe/Warsaw',  # POPRAWKA!
        'txndatetime': txn_datetime,
        'chargetotal': '10.00',
        'currency': '985',
        'checkoutoption': 'combinedpage',
        'oid': order_id,
        'hash_algorithm': 'HMACSHA256',
        'responseSuccessURL': 'https://yourapp.ngrok.app/api/payments/success',
        'responseFailURL': 'https://yourapp.ngrok.app/api/payments/failure',
        'transactionNotificationURL': 'https://yourapp.ngrok.app/api/payments/webhooks/fiserv'
    }
    
    # Oblicz hash
    hash_fields = {k: v for k, v in fields.items() if k not in ['hash_algorithm', 'hashExtended']}
    sorted_fields = sorted(hash_fields.items())
    hash_string = '|'.join(str(v) for k, v in sorted_fields)
    
    # HMAC-SHA256 z potwierdzonym secretem
    hash_bytes = hmac.new(
        client.shared_secret.encode('utf-8'),
        hash_string.encode('utf-8'),
        hashlib.sha256
    ).digest()
    hash_value = base64.b64encode(hash_bytes).decode('utf-8')
    
    fields['hashExtended'] = hash_value
    
    html += f"""
    <div class="test-section">
        <h3>Test 1: Pełna konfiguracja z URL-ami</h3>
        
        <div class="code">
            <strong>String do hasha:</strong><br>
            {hash_string}
        </div>
        
        <div class="code">
            <strong>Hash (Base64):</strong><br>
            {hash_value}
        </div>
        
        <form method="POST" action="{client.gateway_url}" target="_blank">
"""
    
    for k, v in fields.items():
        html += f'            <input type="hidden" name="{k}" value="{v}">\n'
    
    html += """            <button type="submit">🚀 URUCHOM TEST</button>
        </form>
    </div>
"""
    
    # Test 2: Bez URL-i (używa VT)
    order_id2 = f"FISERV-NOURL-{datetime.now().strftime('%Y%m%d%H%M%S')}"
    txn_datetime2 = datetime.now(timezone.utc).strftime("%Y:%m:%d-%H:%M:%S")
    
    fields2 = {
        'storename': '760995999',
        'txntype': 'sale',
        'timezone': 'Europe/Warsaw',
        'txndatetime': txn_datetime2,
        'chargetotal': '10.00',
        'currency': '985',
        'checkoutoption': 'combinedpage',
        'oid': order_id2,
        'hash_algorithm': 'HMACSHA256'
    }
    
    # Hash dla wersji bez URL
    hash_fields2 = {k: v for k, v in fields2.items() if k not in ['hash_algorithm', 'hashExtended']}
    sorted_fields2 = sorted(hash_fields2.items())
    hash_string2 = '|'.join(str(v) for k, v in sorted_fields2)
    
    hash_bytes2 = hmac.new(
        client.shared_secret.encode('utf-8'),
        hash_string2.encode('utf-8'),
        hashlib.sha256
    ).digest()
    hash_value2 = base64.b64encode(hash_bytes2).decode('utf-8')
    
    fields2['hashExtended'] = hash_value2
    
    html += f"""
    <div class="test-section">
        <h3>Test 2: Bez URL-i (używa ustawień z VT)</h3>
        
        <form method="POST" action="{client.gateway_url}" target="_blank">
"""
    
    for k, v in fields2.items():
        html += f'            <input type="hidden" name="{k}" value="{v}">\n'
    
    html += """            <button type="submit">🚀 TEST BEZ URL</button>
        </form>
    </div>
    
    <div class="test-section">
        <h3>📋 Podsumowanie zmian:</h3>
        <table style="width: 100%; border-collapse: collapse;">
            <tr>
                <th style="text-align: left; padding: 10px; border-bottom: 2px solid #ddd;">Parametr</th>
                <th style="text-align: left; padding: 10px; border-bottom: 2px solid #ddd;">Było</th>
                <th style="text-align: left; padding: 10px; border-bottom: 2px solid #ddd;">Jest (poprawne)</th>
            </tr>
            <tr>
                <td style="padding: 10px; border-bottom: 1px solid #ddd;">timezone</td>
                <td style="padding: 10px; border-bottom: 1px solid #ddd; color: red;">Europe/Berlin</td>
                <td style="padding: 10px; border-bottom: 1px solid #ddd; color: green;">Europe/Warsaw</td>
            </tr>
            <tr>
                <td style="padding: 10px; border-bottom: 1px solid #ddd;">checkoutoption</td>
                <td style="padding: 10px; border-bottom: 1px solid #ddd; color: red;">classic</td>
                <td style="padding: 10px; border-bottom: 1px solid #ddd; color: green;">combinedpage</td>
            </tr>
            <tr>
                <td style="padding: 10px; border-bottom: 1px solid #ddd;">shared secret</td>
                <td style="padding: 10px; border-bottom: 1px solid #ddd;">j}2W3P)Lwv</td>
                <td style="padding: 10px; border-bottom: 1px solid #ddd; color: green;">j}2W3P)Lwv ✓</td>
            </tr>
            <tr>
                <td style="padding: 10px; border-bottom: 1px solid #ddd;">currency</td>
                <td style="padding: 10px; border-bottom: 1px solid #ddd;">985</td>
                <td style="padding: 10px; border-bottom: 1px solid #ddd; color: green;">985 ✓</td>
            </tr>
        </table>
    </div>
    
    <div class="success">
        <h3>🎯 To powinno zadziałać!</h3>
        <p>Wszystkie parametry są teraz zgodne z wymaganiami Fiserv dla store ID 760995999.</p>
    </div>
</body>
</html>"""
    
    with open('test_fiserv_fixed.html', 'w', encoding='utf-8') as f:
        f.write(html)
    
    print(f"\n✅ Test zapisany jako: test_fiserv_fixed.html")
    print("\n🔧 Główna zmiana: timezone=Europe/Warsaw (było Europe/Berlin)")
    
    import webbrowser
    import os
    webbrowser.open(f"file://{os.path.abspath('test_fiserv_fixed.html')}")

if __name__ == "__main__":
    test_fiserv_fixed()