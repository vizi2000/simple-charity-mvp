#!/usr/bin/env python3
"""
Test z alternatywnymi Shared Secrets
"""

import os
import hmac
import hashlib
import base64
from datetime import datetime, timedelta
import webbrowser

# Konfiguracja
STORE_ID = "760995999"
GATEWAY_URL = "https://test.ipg-online.com/connect/gateway/processing"

# Różne możliwe Shared Secrets
SECRETS = [
    ("Original", "j}2W3P)Lwv"),
    ("REST API Secret", "aGOkU61VoIl5AWApLL7avcCpIVZxVGG6jYGVQib8xuG"),
    ("Alternative", "c7dP/$5PBx")
]

def generate_hash(secret, values_string):
    """Generuj hash dla danego secretu"""
    hash_bytes = hmac.new(
        secret.encode('utf-8'),
        values_string.encode('utf-8'),
        hashlib.sha256
    ).digest()
    return base64.b64encode(hash_bytes).decode('utf-8')

def test_all_secrets():
    """Test wszystkich secretów"""
    
    # Timestamp
    now = datetime.utcnow() + timedelta(seconds=30)
    txndatetime = now.strftime("%Y:%m:%d-%H:%M:%S")
    
    # Podstawowe parametry
    base_params = {
        'storename': STORE_ID,
        'txntype': 'sale',
        'timezone': 'Europe/Berlin',
        'txndatetime': txndatetime,
        'chargetotal': '10.00',
        'currency': '985',
        'checkoutoption': 'combinedpage',
        'oid': f'SECRET-TEST-{datetime.now().strftime("%Y%m%d%H%M%S")}'
    }
    
    # Sortuj parametry i stwórz string do hashowania
    sorted_params = sorted(base_params.items())
    values_to_hash = '|'.join(str(v) for k, v in sorted_params)
    
    print("="*60)
    print("TEST ALTERNATYWNYCH SHARED SECRETS")
    print("="*60)
    print(f"\nTimestamp: {txndatetime}")
    print(f"Order ID: {base_params['oid']}")
    print(f"\nHash input string:\n{values_to_hash}\n")
    
    # Generuj HTML
    html = f"""<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Test Alternative Secrets</title>
    <style>
        body {{ font-family: Arial, sans-serif; max-width: 1200px; margin: 0 auto; padding: 20px; }}
        .test-form {{ 
            background: #f8f9fa; 
            padding: 20px; 
            margin: 20px 0; 
            border-radius: 5px;
            border: 2px solid #dee2e6;
        }}
        h3 {{ margin-top: 0; color: #495057; }}
        button {{ 
            background: #28a745; 
            color: white; 
            border: none; 
            padding: 12px 24px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            font-weight: bold;
        }}
        button:hover {{ background: #218838; }}
        .secret-value {{ 
            font-family: monospace; 
            background: #e9ecef; 
            padding: 5px;
            margin: 5px 0;
        }}
        .hash-value {{
            font-family: monospace;
            background: #fff3cd;
            padding: 5px;
            word-break: break-all;
            margin: 10px 0;
        }}
        .highlight {{
            background: #d4edda;
            border: 2px solid #28a745;
        }}
    </style>
</head>
<body>
    <h1>🔐 Test Alternatywnych Shared Secrets</h1>
    
    <div style="background: #d1ecf1; padding: 15px; border-radius: 5px; margin-bottom: 20px;">
        <strong>📌 Cel testu:</strong> Sprawdzić czy któryś z alternatywnych secretów działa z Fiserv IPG Connect
    </div>
"""
    
    # Test każdego secretu
    for i, (name, secret) in enumerate(SECRETS, 1):
        hash_value = generate_hash(secret, values_to_hash)
        
        print(f"{i}. {name}:")
        print(f"   Secret: {secret}")
        print(f"   Hash: {hash_value[:40]}...")
        print()
        
        # Dodaj highlight dla nowych secretów
        highlight_class = "highlight" if name != "Original" else ""
        
        params = base_params.copy()
        params['hash_algorithm'] = 'HMACSHA256'
        params['hashExtended'] = hash_value
        
        html += f"""
    <div class="test-form {highlight_class}">
        <h3>Test {i}: {name}</h3>
        <div class="secret-value">Secret: {secret}</div>
        <div class="hash-value">Hash: {hash_value}</div>
        <form method="POST" action="{GATEWAY_URL}" target="_blank">
"""
        for k, v in params.items():
            html += f'            <input type="hidden" name="{k}" value="{v}">\n'
        
        html += f"""            <button type="submit">🚀 Testuj "{name}"</button>
        </form>
    </div>
"""
    
    # Dodatkowo test z polem 'hash' zamiast 'hashExtended' dla nowych secretów
    html += """
    <hr style="margin: 40px 0;">
    <h2>🔄 Test z polem 'hash' (zamiast 'hashExtended')</h2>
"""
    
    for i, (name, secret) in enumerate(SECRETS[1:], 1):  # Tylko nowe secrety
        hash_value = generate_hash(secret, values_to_hash)
        
        params = base_params.copy()
        params['hash_algorithm'] = 'HMACSHA256'
        params['hash'] = hash_value  # użyj 'hash' zamiast 'hashExtended'
        
        html += f"""
    <div class="test-form highlight">
        <h3>Test z 'hash': {name}</h3>
        <div class="secret-value">Secret: {secret}</div>
        <div class="hash-value">Hash: {hash_value}</div>
        <form method="POST" action="{GATEWAY_URL}" target="_blank">
"""
        for k, v in params.items():
            html += f'            <input type="hidden" name="{k}" value="{v}">\n'
        
        html += f"""            <button type="submit">🚀 Testuj "{name}" z 'hash'</button>
        </form>
    </div>
"""
    
    html += """
    <div style="margin-top: 30px; padding: 15px; background: #d4edda; border-radius: 5px;">
        <strong>✅ Instrukcja:</strong><br>
        1. Kliknij każdy przycisk po kolei<br>
        2. <strong>Szczególnie przetestuj wyróżnione (zielone) formularze!</strong><br>
        3. Jeśli któryś przejdzie dalej niż "Unknown error" = SUKCES!<br>
        4. Zapisz który secret zadziałał<br><br>
        
        <strong>🎯 Najbardziej prawdopodobne:</strong><br>
        - REST API Secret: aGOkU61VoIl5AWApLL7avcCpIVZxVGG6jYGVQib8xuG<br>
        - Alternative: c7dP/$5PBx
    </div>
</body>
</html>"""
    
    filename = "test_alternative_secrets.html"
    with open(filename, 'w', encoding='utf-8') as f:
        f.write(html)
    
    print(f"✅ Test zapisany jako: {filename}")
    print("\n🎯 SZCZEGÓLNIE PRZETESTUJ:")
    print("   - REST API Secret: aGOkU61VoIl5AWApLL7avcCpIVZxVGG6jYGVQib8xuG")
    print("   - Alternative: c7dP/$5PBx")
    
    return filename

if __name__ == "__main__":
    filename = test_all_secrets()
    webbrowser.open(f"file://{os.path.abspath(filename)}")