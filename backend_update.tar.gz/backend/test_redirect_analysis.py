#!/usr/bin/env python3
"""
Analiza przekierowań - może płatność działa ale redirect jest źle interpretowany?
"""

import httpx
import asyncio
from datetime import datetime
from zoneinfo import ZoneInfo
import base64
from urllib.parse import urlparse, parse_qs


async def analyze_redirects():
    """Dokładna analiza co się dzieje z przekierowaniami"""
    
    print("="*70)
    print("ANALIZA PRZEKIEROWAŃ FISERV")
    print("="*70)
    
    # Import naszej implementacji
    from test_final_with_discoveries import FiservFinalTest
    
    tester = FiservFinalTest()
    
    # Stwórz formularz
    form_fields, order_id = tester.create_payment_form()
    
    print("\n🔍 ANALIZA PRZEKIEROWANIA:")
    print("-" * 50)
    
    async with httpx.AsyncClient(follow_redirects=False, timeout=30.0) as client:
        # Pierwszy request
        print("\n1️⃣ PIERWSZY REQUEST (wysłanie formularza):")
        
        response = await client.post(
            tester.gateway_url,
            data=form_fields,
            headers={
                'Content-Type': 'application/x-www-form-urlencoded',
                'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language': 'pl-PL,pl;q=0.9,en;q=0.8'
            }
        )
        
        print(f"   Status: {response.status_code}")
        
        if response.status_code in [302, 303]:
            location = response.headers.get('location', '')
            print(f"   Location: {location}")
            
            # Parsuj URL
            parsed = urlparse(location)
            print(f"\n   📍 Analiza URL:")
            print(f"      Path: {parsed.path}")
            print(f"      Query: {parsed.query}")
            
            # Sprawdź czy to naprawdę błąd
            if 'validationError' in location:
                print("\n   ⚠️ URL zawiera 'validationError'")
                
                # Ale może to jest tylko nazwa strony pośredniej?
                print("\n   🤔 Możliwe scenariusze:")
                print("      1. To rzeczywisty błąd walidacji")
                print("      2. To strona pośrednia przed płatnością")
                print("      3. Błędna konfiguracja URLi zwrotnych")
                
                # Spróbuj zdekodować parametry
                params = parse_qs(parsed.query)
                print(f"\n   📊 Parametry w URL:")
                for key, value in params.items():
                    print(f"      {key}: {value}")
                    
                    # Jeśli jest parametr 'k', spróbuj go zdekodować
                    if key == 'k' and value:
                        try:
                            decoded = base64.b64decode(value[0]).decode('utf-8')
                            print(f"      {key} (decoded): {decoded}")
                        except:
                            pass
                
                # Sprawdź cookies
                cookies = response.cookies
                print(f"\n   🍪 Cookies: {dict(cookies)}")
                
                # Może spróbować podążyć za przekierowaniem?
                print("\n2️⃣ PRÓBA PODĄŻENIA ZA PRZEKIEROWANIEM:")
                
                try:
                    follow_response = await client.get(
                        location,
                        cookies=cookies,
                        headers={
                            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)',
                            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                            'Referer': tester.gateway_url
                        }
                    )
                    
                    print(f"   Status: {follow_response.status_code}")
                    
                    # Sprawdź treść
                    content = follow_response.text
                    
                    # Szukaj wskazówek w treści
                    if 'payment' in content.lower():
                        print("   ✅ Strona zawiera słowo 'payment'")
                    if 'card' in content.lower():
                        print("   ✅ Strona zawiera słowo 'card'")
                    if 'error' in content.lower():
                        print("   ❌ Strona zawiera słowo 'error'")
                        
                        # Znajdź konkretny komunikat
                        import re
                        error_patterns = [
                            r'<[^>]*class="[^"]*error[^"]*"[^>]*>([^<]+)',
                            r'error[^>]*>([^<]+)',
                            r'Error: ([^<]+)',
                            r'validation[^>]*>([^<]+)'
                        ]
                        
                        for pattern in error_patterns:
                            matches = re.findall(pattern, content, re.IGNORECASE)
                            if matches:
                                print(f"   Komunikat błędu: {matches[0][:100]}")
                                break
                    
                    # Sprawdź czy jest formularz płatności
                    if '<form' in content.lower():
                        forms = re.findall(r'<form[^>]*>', content, re.IGNORECASE)
                        print(f"   📝 Znaleziono {len(forms)} formularzy")
                        
                        # Sprawdź czy jest pole na kartę
                        if 'cardnumber' in content.lower() or 'card-number' in content.lower():
                            print("   💳 Znaleziono pole na numer karty!")
                            print("   ✅ TO MOŻE BYĆ STRONA PŁATNOŚCI!")
                    
                    # Zapisz stronę do analizy
                    debug_file = f"debug_page_{order_id}.html"
                    with open(debug_file, 'w', encoding='utf-8') as f:
                        f.write(content)
                    print(f"\n   💾 Strona zapisana do: {debug_file}")
                    
                except Exception as e:
                    print(f"   ❌ Błąd podążania: {e}")
            
            elif 'payment' in location.lower() or 'checkout' in location.lower():
                print("\n   ✅ URL wygląda na stronę płatności!")
                
        elif response.status_code == 200:
            print("\n   📄 Otrzymano stronę bezpośrednio (200 OK)")
            content = response.text[:500]
            print(f"   Początek treści: {content}")
    
    print("\n" + "="*70)
    print("ALTERNATYWNY TEST")
    print("="*70)
    
    # Test z innymi URLami
    print("\n🔄 Test z prostszymi URLami (bez parametrów):")
    
    alt_form = form_fields.copy()
    alt_form['responseSuccessURL'] = 'https://webhook.site/unique-success-id'
    alt_form['responseFailURL'] = 'https://webhook.site/unique-failure-id'
    alt_form['oid'] = f'ALT-{order_id}'
    
    # Przelicz hash
    alt_form['hashExtended'] = tester.calculate_hash(alt_form)
    
    response2 = await client.post(
        tester.gateway_url,
        data=alt_form,
        headers={'Content-Type': 'application/x-www-form-urlencoded'}
    )
    
    print(f"   Status: {response2.status_code}")
    if response2.status_code in [302, 303]:
        location2 = response2.headers.get('location', '')
        print(f"   Location: {location2[:100]}...")
        
        if 'validationError' in location2:
            print("   ❌ Nadal validation error")
        else:
            print("   ✅ Inny rezultat!")
    
    print("\n" + "="*70)
    print("WNIOSKI")
    print("="*70)
    
    print("""
🤔 MOŻLIWE PRZYCZYNY "validationError":

1. ✅ To może być NORMALNE przekierowanie!
   - Niektóre systemy używają "validationError" jako nazwy strony pośredniej
   - Sprawdź czy po przekierowaniu jest formularz karty

2. ❌ Rzeczywisty błąd walidacji:
   - Nieprawidłowy shared secret
   - Błędna konfiguracja konta
   
3. ⚠️ Problem z URLami zwrotnymi:
   - Fiserv może wymagać zarejestrowanych domen
   - ngrok może być blokowany

REKOMENDACJA:
- Otwórz debug_page_*.html i sprawdź co jest na stronie
- Jeśli jest formularz karty = DZIAŁA!
- Jeśli jest komunikat błędu = sprawdź jaki
    """)


if __name__ == "__main__":
    asyncio.run(analyze_redirects())