#!/usr/bin/env python3
"""
Test z wysłaniem prawdziwego formularza do Fiserv
"""

import os
import sys
import requests
import webbrowser
from datetime import datetime
from zoneinfo import ZoneInfo

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from app.utils.fiserv_ipg_client import fiserv_ipg_client

def create_test_payment_form():
    """Tworzy formularz HTML do testowej płatności"""
    
    print("\n" + "="*70)
    print("GENEROWANIE FORMULARZA TESTOWEJ PŁATNOŚCI")
    print("="*70)
    
    # Generuj dane płatności
    order_id = f"LIVE-FORM-{datetime.now().strftime('%Y%m%d%H%M%S')}"
    
    payment_data = fiserv_ipg_client.create_payment_form_data(
        amount=10.00,  # Mała kwota testowa
        order_id=order_id,
        description='Test płatności z formularza HTML',
        success_url='https://webhook.site/a1b2c3d4-success',  # Tymczasowy URL do testów
        failure_url='https://webhook.site/a1b2c3d4-failure',
        notification_url='https://webhook.site/a1b2c3d4-webhook',
        customer_info={
            'name': 'Test Customer',
            'email': 'test@customer.pl'
        }
    )
    
    form_action = payment_data['form_action']
    form_fields = payment_data['form_fields']
    
    # Wyświetl dane
    print(f"\nDane płatności:")
    print(f"  Order ID: {order_id}")
    print(f"  Kwota: {form_fields['chargetotal']} PLN")
    print(f"  Timezone: {form_fields['timezone']}")
    print(f"  Timestamp: {form_fields['txndatetime']}")
    print(f"  Store: {form_fields['storename']}")
    print(f"  Hash: {form_fields['hashExtended'][:30]}...")
    
    # Generuj HTML
    html_content = f"""<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test Płatności Fiserv - {order_id}</title>
    <style>
        body {{
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background: #f5f5f5;
        }}
        .container {{
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }}
        h1 {{
            color: #333;
            border-bottom: 2px solid #4CAF50;
            padding-bottom: 10px;
        }}
        .info {{
            background: #e8f5e9;
            padding: 15px;
            border-radius: 5px;
            margin: 20px 0;
        }}
        .info h3 {{
            margin-top: 0;
            color: #2e7d32;
        }}
        .field {{
            margin: 10px 0;
            padding: 8px;
            background: #f9f9f9;
            border-left: 3px solid #4CAF50;
        }}
        .field strong {{
            display: inline-block;
            width: 200px;
            color: #555;
        }}
        .field span {{
            color: #333;
            font-family: monospace;
        }}
        .buttons {{
            margin-top: 30px;
            text-align: center;
        }}
        button {{
            background: #4CAF50;
            color: white;
            border: none;
            padding: 15px 40px;
            font-size: 18px;
            border-radius: 5px;
            cursor: pointer;
            margin: 0 10px;
        }}
        button:hover {{
            background: #45a049;
        }}
        button.secondary {{
            background: #757575;
        }}
        button.secondary:hover {{
            background: #616161;
        }}
        .warning {{
            background: #fff3cd;
            border: 1px solid #ffc107;
            color: #856404;
            padding: 15px;
            border-radius: 5px;
            margin: 20px 0;
        }}
        .timestamp {{
            color: #666;
            font-size: 12px;
            text-align: right;
            margin-top: 20px;
        }}
    </style>
</head>
<body>
    <div class="container">
        <h1>🔐 Test Płatności Fiserv</h1>
        
        <div class="info">
            <h3>Informacje o płatności</h3>
            <div class="field">
                <strong>ID zamówienia:</strong> 
                <span>{order_id}</span>
            </div>
            <div class="field">
                <strong>Kwota:</strong> 
                <span>{form_fields['chargetotal']} PLN</span>
            </div>
            <div class="field">
                <strong>Opis:</strong> 
                <span>Test płatności z formularza HTML</span>
            </div>
            <div class="field">
                <strong>Klient:</strong> 
                <span>{form_fields.get('bname', 'Test Customer')}</span>
            </div>
        </div>
        
        <div class="info">
            <h3>Parametry techniczne</h3>
            <div class="field">
                <strong>Store ID:</strong> 
                <span>{form_fields['storename']}</span>
            </div>
            <div class="field">
                <strong>Timezone:</strong> 
                <span>{form_fields['timezone']}</span>
            </div>
            <div class="field">
                <strong>Timestamp:</strong> 
                <span>{form_fields['txndatetime']}</span>
            </div>
            <div class="field">
                <strong>Currency:</strong> 
                <span>{form_fields['currency']} (PLN)</span>
            </div>
            <div class="field">
                <strong>Hash:</strong> 
                <span title="{form_fields['hashExtended']}">{form_fields['hashExtended'][:40]}...</span>
            </div>
        </div>
        
        <div class="warning">
            <strong>⚠️ Uwaga:</strong> To jest środowisko testowe Fiserv. 
            Użyj karty testowej do przeprowadzenia transakcji.
        </div>
        
        <form id="paymentForm" action="{form_action}" method="POST">
            <!-- Ukryte pola formularza -->
"""
    
    # Dodaj wszystkie pola formularza
    for key, value in form_fields.items():
        if value:
            html_content += f'            <input type="hidden" name="{key}" value="{value}">\n'
    
    html_content += f"""        </form>
        
        <div class="buttons">
            <button onclick="submitPayment()">
                💳 Przejdź do płatności
            </button>
            <button class="secondary" onclick="showFormData()">
                📋 Pokaż dane formularza
            </button>
        </div>
        
        <div class="timestamp">
            Wygenerowano: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
        </div>
    </div>
    
    <script>
        function submitPayment() {{
            if (confirm('Czy chcesz przejść do strony płatności Fiserv?')) {{
                document.getElementById('paymentForm').submit();
            }}
        }}
        
        function showFormData() {{
            const formData = {{"""
    
    # Dodaj dane do JS
    for key, value in form_fields.items():
        if value:
            # Escape dla JavaScript
            value_escaped = str(value).replace("'", "\\'").replace('"', '\\"')
            html_content += f"\n                '{key}': '{value_escaped}',"
    
    html_content += f"""
            }};
            
            let output = 'Dane wysyłane do Fiserv:\\n\\n';
            for (const [key, value] of Object.entries(formData)) {{
                output += key + ': ' + value + '\\n';
            }}
            
            alert(output);
        }}
    </script>
</body>
</html>"""
    
    # Zapisz do pliku
    filename = f"test_payment_form_{order_id}.html"
    with open(filename, 'w', encoding='utf-8') as f:
        f.write(html_content)
    
    print(f"\n✅ Formularz wygenerowany pomyślnie!")
    print(f"📁 Zapisano do: {filename}")
    
    return filename, order_id

def test_with_test_cards():
    """Informacje o kartach testowych"""
    
    print("\n" + "="*70)
    print("KARTY TESTOWE FISERV")
    print("="*70)
    
    test_cards = [
        {
            'type': 'Visa',
            'number': '4111111111111111',
            'expiry': '12/25',
            'cvv': '123',
            'result': 'Sukces'
        },
        {
            'type': 'MasterCard',
            'number': '5500000000000004',
            'expiry': '12/25',
            'cvv': '123',
            'result': 'Sukces'
        },
        {
            'type': 'Visa (odmowa)',
            'number': '4111111111111111',
            'expiry': '12/20',
            'cvv': '123',
            'result': 'Odmowa - karta wygasła'
        }
    ]
    
    print("\nDostępne karty testowe:")
    for i, card in enumerate(test_cards, 1):
        print(f"\n{i}. {card['type']}:")
        print(f"   Numer: {card['number']}")
        print(f"   Data ważności: {card['expiry']}")
        print(f"   CVV: {card['cvv']}")
        print(f"   Oczekiwany wynik: {card['result']}")
    
    print("\n💡 Wskazówka: Użyj pierwszej karty (Visa) do testu sukcesu")

def main():
    """Główna funkcja"""
    
    print("\n" + "="*70)
    print("TEST PŁATNOŚCI Z FORMULARZEM HTML")
    print(datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    print("="*70)
    
    # Generuj formularz
    filename, order_id = create_test_payment_form()
    
    # Pokaż karty testowe
    test_with_test_cards()
    
    # Instrukcje
    print("\n" + "="*70)
    print("INSTRUKCJE TESTOWANIA")
    print("="*70)
    
    print(f"""
1. Otwórz wygenerowany plik HTML:
   {filename}
   
2. Kliknij przycisk "💳 Przejdź do płatności"

3. Na stronie Fiserv użyj karty testowej:
   - Numer: 4111111111111111
   - Data: 12/25
   - CVV: 123
   
4. Wypełnij pozostałe dane (dowolne)

5. Dokończ płatność

6. Sprawdź czy zostałeś przekierowany na stronę sukcesu/błędu
""")
    
    # Opcja automatycznego otwarcia
    response = input("\n🌐 Czy otworzyć formularz w przeglądarce? (t/n): ")
    if response.lower() == 't':
        abs_path = os.path.abspath(filename)
        webbrowser.open(f'file://{abs_path}')
        print(f"\n✅ Formularz otwarty w przeglądarce!")
    
    print(f"\n📌 Order ID do śledzenia: {order_id}")
    print("\nTest zakończony. Sprawdź wyniki w przeglądarce.")

if __name__ == "__main__":
    main()