#!/usr/bin/env python3
"""
Test minimalnego payloadu dla Fiserv IPG Connect w EUR
"""

import os
import hmac
import hashlib
import base64
from datetime import datetime, timedelta
import json
import webbrowser

# Konfiguracja
STORE_ID = "760995999"
SHARED_SECRET = "j}2W3P)Lwv"
GATEWAY_URL = "https://test.ipg-online.com/connect/gateway/processing"

def generate_minimal_eur_form():
    """Generuj minimalny formularz w EUR"""
    
    # Timestamp w formacie Fiserv (kilka sekund w przyszłości)
    now = datetime.utcnow() + timedelta(seconds=30)
    txndatetime = now.strftime("%Y:%m:%d-%H:%M:%S")
    
    # Minimalny zestaw pól z EUR
    params = {
        'storename': STORE_ID,
        'txntype': 'sale',
        'timezone': 'Europe/Berlin',  # Wspierana strefa
        'txndatetime': txndatetime,
        'chargetotal': '10.00',  # 10 EUR
        'currency': '978',  # EUR
        'checkoutoption': 'combinedpage',
        'oid': f'EUR-TEST-{datetime.now().strftime("%Y%m%d%H%M%S")}',
        'hash_algorithm': 'HMACSHA256'
    }
    
    # Generuj hash - tylko wartości, wykluczając hash_algorithm
    sorted_params = sorted([(k, v) for k, v in params.items() if k != 'hash_algorithm'])
    values_to_hash = '|'.join(str(v) for k, v in sorted_params)
    
    print("Hash input (tylko wartości):")
    print(values_to_hash)
    print()
    
    # Oblicz HMAC SHA256
    hash_bytes = hmac.new(
        SHARED_SECRET.encode('utf-8'),
        values_to_hash.encode('utf-8'),
        hashlib.sha256
    ).digest()
    hash_base64 = base64.b64encode(hash_bytes).decode('utf-8')
    
    # Użyj hashExtended zamiast hash
    params['hashExtended'] = hash_base64
    
    # Generuj HTML
    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Minimal EUR Test - Fiserv IPG</title>
    <style>
        body {{ font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; }}
        .info {{ background: #d4edda; padding: 15px; border-radius: 5px; margin: 20px 0; }}
        .warning {{ background: #cce5ff; padding: 15px; border-radius: 5px; margin: 20px 0; }}
        pre {{ background: #f5f5f5; padding: 10px; overflow-x: auto; }}
        button {{ padding: 15px 30px; background: #007bff; color: white; border: none; cursor: pointer; font-size: 18px; }}
        button:hover {{ background: #0056b3; }}
    </style>
</head>
<body>
    <h1>Minimal EUR Payment Test</h1>
    
    <div class="warning">
        <h3>💶 EUR Test with Minimal Fields</h3>
        <p>Testing with EUR currency (978) and Europe/Berlin timezone</p>
        <p>Using <strong>hashExtended</strong> field as per IPG Connect docs</p>
    </div>
    
    <div class="info">
        <h3>Test Parameters:</h3>
        <ul>
            <li><strong>Store ID:</strong> {STORE_ID}</li>
            <li><strong>Amount:</strong> 10.00 EUR</li>
            <li><strong>Order ID:</strong> {params['oid']}</li>
            <li><strong>Timestamp:</strong> {txndatetime}</li>
            <li><strong>Timezone:</strong> Europe/Berlin</li>
            <li><strong>Currency:</strong> 978 (EUR)</li>
        </ul>
    </div>
    
    <h3>Form Data:</h3>
    <pre>{json.dumps(params, indent=2, ensure_ascii=False)}</pre>
    
    <h3>Hash Input String:</h3>
    <pre>{values_to_hash}</pre>
    
    <form method="POST" action="{GATEWAY_URL}">
"""
    
    # Dodaj wszystkie pola
    for key, value in params.items():
        html += f'        <input type="hidden" name="{key}" value="{value}">\n'
    
    html += """
        <button type="submit">Submit EUR Payment</button>
    </form>
    
    <div class="info" style="margin-top: 30px;">
        <h3>Test Cards:</h3>
        <ul>
            <li>Visa: 4005550000000019 (CVV: 111, Exp: 12/25)</li>
            <li>Mastercard: 5204740000001002 (CVV: 111, Exp: 12/25)</li>
        </ul>
    </div>
</body>
</html>"""
    
    # Zapisz plik
    filename = f"minimal_eur_{params['oid']}.html"
    with open(filename, 'w', encoding='utf-8') as f:
        f.write(html)
    
    print(f"✅ EUR test form saved as: {filename}")
    print(f"✅ Hash (hashExtended): {hash_base64}")
    print("\nOpen the file in browser and click 'Submit EUR Payment'")
    
    return filename

if __name__ == "__main__":
    filename = generate_minimal_eur_form()
    webbrowser.open(f"file://{os.path.abspath(filename)}")