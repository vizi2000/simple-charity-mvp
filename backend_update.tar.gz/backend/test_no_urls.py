#!/usr/bin/env python3
"""
Test bez URL-i powrotu - jeśli VT nie pozwala na nadpisywanie
"""

import os
import hmac
import hashlib
import base64
from datetime import datetime, timedelta
import json
import webbrowser

# Konfiguracja
STORE_ID = "760995999"
SHARED_SECRET = "j}2W3P)Lwv"
GATEWAY_URL = "https://test.ipg-online.com/connect/gateway/processing"

def generate_no_urls_test():
    """Generuj formularz BEZ URL-i powrotu"""
    
    # Timestamp w formacie Fiserv
    now = datetime.utcnow() + timedelta(seconds=30)
    txndatetime = now.strftime("%Y:%m:%d-%H:%M:%S")
    
    # Parametry BEZ URL-i
    params = {
        'storename': STORE_ID,
        'txntype': 'sale',
        'timezone': 'Europe/Berlin',
        'txndatetime': txndatetime,
        'chargetotal': '5.00',  # Mała kwota
        'currency': '985',  # PLN
        'checkoutoption': 'combinedpage',
        'oid': f'NOURL-{datetime.now().strftime("%Y%m%d%H%M%S")}',
        'hash_algorithm': 'HMACSHA256'
    }
    
    # NIE DODAJEMY:
    # - responseSuccessURL
    # - responseFailURL
    # - transactionNotificationURL
    
    # Generuj hash
    sorted_params = sorted([(k, v) for k, v in params.items() if k != 'hash_algorithm'])
    values_to_hash = '|'.join(str(v) for k, v in sorted_params)
    
    print("="*60)
    print("TEST BEZ URL-i POWROTU")
    print("="*60)
    print("\nParametry (bez URL-i):")
    for k, v in params.items():
        print(f"  {k}: {v}")
    
    print(f"\nHash input string:\n{values_to_hash}")
    
    # Oblicz HMAC SHA256
    hash_bytes = hmac.new(
        SHARED_SECRET.encode('utf-8'),
        values_to_hash.encode('utf-8'),
        hashlib.sha256
    ).digest()
    hash_base64 = base64.b64encode(hash_bytes).decode('utf-8')
    
    params['hashExtended'] = hash_base64
    
    print(f"\nhashExtended: {hash_base64}")
    print("="*60)
    
    # Generuj HTML
    html = f"""<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Test Bez URL - Fiserv</title>
    <style>
        body {{ 
            font-family: Arial, sans-serif; 
            max-width: 800px; 
            margin: 50px auto; 
            padding: 20px;
            background: #f0f0f0;
        }}
        .container {{
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }}
        h1 {{ color: #333; }}
        .warning {{
            background: #ffebee;
            padding: 20px;
            border-radius: 5px;
            margin: 20px 0;
            border-left: 4px solid #f44336;
        }}
        .info {{
            background: #e3f2fd;
            padding: 20px;
            border-radius: 5px;
            margin: 20px 0;
            border-left: 4px solid #2196f3;
        }}
        .params {{
            background: #f8f8f8;
            padding: 20px;
            border-radius: 5px;
            margin: 20px 0;
            font-family: monospace;
        }}
        button {{
            background: #ff5722;
            color: white;
            border: none;
            padding: 15px 30px;
            font-size: 18px;
            border-radius: 5px;
            cursor: pointer;
            margin: 20px 0;
            width: 100%;
        }}
        button:hover {{
            background: #e64a19;
        }}
    </style>
</head>
<body>
    <div class="container">
        <h1>🚫 Test BEZ URL-i Powrotu</h1>
        
        <div class="warning">
            <strong>⚠️ UWAGA:</strong> Ten test NIE zawiera URL-i powrotu!<br>
            Użyj go jeśli w Virtual Terminal NIE jest zaznaczone "Overwrite Store URLs"
        </div>
        
        <div class="info">
            <strong>Co się stanie po płatności?</strong><br>
            • Sukces → Fiserv użyje URL z Virtual Terminal<br>
            • Błąd → Fiserv użyje URL z Virtual Terminal<br>
            • Jeśli URL-e nie są skonfigurowane w VT → domyślna strona Fiserv
        </div>
        
        <h2>Parametry (BEZ URL-i):</h2>
        <div class="params">
"""
    
    for key, value in params.items():
        if 'URL' not in key:  # Upewnij się że nie ma URL-i
            html += f'            <div><strong>{key}:</strong> {value}</div>\n'
    
    html += f"""
        </div>
        
        <form method="POST" action="{GATEWAY_URL}">
"""
    
    # Dodaj pola do formularza
    for key, value in params.items():
        html += f'            <input type="hidden" name="{key}" value="{value}">\n'
    
    html += """
            <button type="submit">🔥 Wyślij BEZ URL-i</button>
        </form>
        
        <div class="info" style="margin-top: 30px;">
            <strong>Jeśli to zadziała:</strong><br>
            1. Zaloguj się do Virtual Terminal<br>
            2. Zaznacz opcję "Overwrite Store URLs"<br>
            3. Wtedy będziesz mógł używać własnych URL-i w formularzu
        </div>
        
        <div style="background: #fff3cd; padding: 15px; border-radius: 5px; margin-top: 20px;">
            <strong>Karty testowe:</strong><br>
            • Visa: 4005550000000019 (CVV: 111, Exp: 12/25)<br>
            • Mastercard: 5204740000001002 (CVV: 111, Exp: 12/25)
        </div>
    </div>
</body>
</html>"""
    
    # Zapisz plik
    filename = f"test_no_urls_{params['oid']}.html"
    with open(filename, 'w', encoding='utf-8') as f:
        f.write(html)
    
    print(f"\n✅ Formularz BEZ URL-i zapisany jako: {filename}")
    print("\nJeśli ten test zadziała, problem jest w ustawieniach URL w Virtual Terminal!")
    
    return filename

if __name__ == "__main__":
    filename = generate_no_urls_test()
    webbrowser.open(f"file://{os.path.abspath(filename)}")