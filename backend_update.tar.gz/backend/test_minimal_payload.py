#!/usr/bin/env python3
"""
Test minimalnego payloadu dla Fiserv IPG Connect
Zgodnie z przewodnikiem - tylko obowiązkowe pola
"""

import os
import hmac
import hashlib
import base64
from datetime import datetime, timedelta
import json

# Konfiguracja
STORE_ID = "760995999"
SHARED_SECRET = "j}2W3P)Lwv"
GATEWAY_URL = "https://test.ipg-online.com/connect/gateway/processing"

def generate_minimal_form():
    """Generuj minimalny formularz z tylko obowiązkowymi polami"""
    
    # Timestamp w formacie Fiserv (kilka sekund w przyszłości)
    now = datetime.utcnow() + timedelta(seconds=30)
    txndatetime = now.strftime("%Y:%m:%d-%H:%M:%S")
    
    # Minimalny zestaw pól
    params = {
        'storename': STORE_ID,
        'txntype': 'sale',
        'timezone': 'Europe/Warsaw',
        'txndatetime': txndatetime,
        'chargetotal': '10.00',  # Mała kwota testowa
        'currency': '985',
        'checkoutoption': 'combinedpage',
        'oid': f'MIN-TEST-{datetime.now().strftime("%Y%m%d%H%M%S")}',
        'hash_algorithm': 'HMACSHA256'
    }
    
    # Generuj hash - tylko wartości!
    sorted_params = sorted([(k, v) for k, v in params.items() if k != 'hash_algorithm'])
    values_to_hash = '|'.join(str(v) for k, v in sorted_params)
    
    print("Hash input (tylko wartości):")
    print(values_to_hash)
    print()
    
    # Oblicz HMAC SHA256
    hash_bytes = hmac.new(
        SHARED_SECRET.encode('utf-8'),
        values_to_hash.encode('utf-8'),
        hashlib.sha256
    ).digest()
    hash_base64 = base64.b64encode(hash_bytes).decode('utf-8')
    
    params['hash'] = hash_base64
    
    # Generuj HTML
    html = f"""<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Minimalny Test Fiserv IPG</title>
    <style>
        body {{ font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; }}
        .info {{ background: #e7f3ff; padding: 15px; border-radius: 5px; margin: 20px 0; }}
        .warning {{ background: #fff3cd; padding: 15px; border-radius: 5px; margin: 20px 0; }}
        pre {{ background: #f5f5f5; padding: 10px; overflow-x: auto; }}
        button {{ padding: 15px 30px; background: #28a745; color: white; border: none; cursor: pointer; font-size: 18px; }}
        button:hover {{ background: #218838; }}
    </style>
</head>
<body>
    <h1>Minimalny Test Płatności Fiserv</h1>
    
    <div class="warning">
        <h3>⚠️ Test Minimalnego Payloadu</h3>
        <p>Ten formularz zawiera TYLKO pola obowiązkowe zgodnie z przewodnikiem.</p>
        <p>Jeśli to zadziała, problem leży w dodatkowych polach.</p>
    </div>
    
    <div class="info">
        <h3>Parametry testowe:</h3>
        <ul>
            <li><strong>Store ID:</strong> {STORE_ID}</li>
            <li><strong>Kwota:</strong> 10.00 PLN</li>
            <li><strong>Order ID:</strong> {params['oid']}</li>
            <li><strong>Timestamp:</strong> {txndatetime}</li>
        </ul>
    </div>
    
    <h3>Dane formularza:</h3>
    <pre>{json.dumps(params, indent=2, ensure_ascii=False)}</pre>
    
    <h3>String do hasha (wartości posortowane alfabetycznie):</h3>
    <pre>{values_to_hash}</pre>
    
    <form method="POST" action="{GATEWAY_URL}">
"""
    
    # Dodaj wszystkie pola
    for key, value in params.items():
        html += f'        <input type="hidden" name="{key}" value="{value}">\n'
    
    html += """
        <button type="submit">Wyślij Minimalny Formularz</button>
    </form>
    
    <div class="info" style="margin-top: 30px;">
        <h3>Karty testowe:</h3>
        <ul>
            <li>Visa: 4005550000000019 (CVV: 111, Exp: 12/25)</li>
            <li>Mastercard: 5204740000001002 (CVV: 111, Exp: 12/25)</li>
        </ul>
    </div>
</body>
</html>"""
    
    # Zapisz plik
    filename = f"minimal_test_{params['oid']}.html"
    with open(filename, 'w', encoding='utf-8') as f:
        f.write(html)
    
    print(f"✅ Minimalny formularz zapisany jako: {filename}")
    print(f"✅ Hash: {hash_base64}")
    print("\nOtwórz plik w przeglądarce i kliknij 'Wyślij Minimalny Formularz'")
    
    # Zapisz też dane do debugowania
    debug_file = f"minimal_debug_{params['oid']}.json"
    with open(debug_file, 'w', encoding='utf-8') as f:
        json.dump({
            'params': params,
            'hash_input': values_to_hash,
            'hash_output': hash_base64,
            'timestamp': datetime.now().isoformat()
        }, f, indent=2, ensure_ascii=False)
    
    return filename

if __name__ == "__main__":
    import webbrowser
    filename = generate_minimal_form()
    webbrowser.open(f"file://{os.path.abspath(filename)}")