#!/usr/bin/env python3
"""
Test End-to-End płatności z poprawionymi wartościami timezone/timestamp
"""

import sys
import os
import json
import time
from datetime import datetime
from zoneinfo import ZoneInfo

sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from app.utils.fiserv_ipg_client import FiservIPGClient

def test_e2e_payment():
    """Test pełnego flow płatności"""
    
    print("="*60)
    print("TEST END-TO-END PŁATNOŚCI")
    print("="*60)
    
    # Dane testowe
    test_order_id = f"E2E-TEST-{datetime.now().strftime('%Y%m%d%H%M%S')}"
    test_amount = 25.00
    
    print(f"\n📋 DANE TESTOWE:")
    print(f"   Order ID: {test_order_id}")
    print(f"   Kwota: {test_amount} PLN")
    
    # Inicjalizuj klienta
    client = FiservIPGClient()
    
    # Generuj dane formularza
    print("\n🔧 GENEROWANIE FORMULARZA...")
    form_data = client.create_payment_form_data(
        amount=test_amount,
        order_id=test_order_id,
        description="Test E2E płatności",
        success_url="https://charity.ngrok.app/platnosc/success",
        failure_url="https://charity.ngrok.app/platnosc/failure", 
        notification_url="https://charity-webhook.ngrok.app/api/webhooks/fiserv",
        payment_method="card",
        customer_info={
            "name": "Jan Testowy",
            "email": "jan.testowy@example.com"
        }
    )
    
    # Sprawdź wygenerowane dane
    fields = form_data['form_fields']
    
    print("\n✅ WERYFIKACJA DANYCH:")
    print("-" * 40)
    
    # 1. Timezone
    timezone = fields.get('timezone')
    print(f"1. Timezone: {timezone}")
    assert timezone == 'Europe/Warsaw', f"Błąd: timezone={timezone}"
    print("   ✅ Poprawny (Europe/Warsaw)")
    
    # 2. Timestamp
    txndatetime = fields.get('txndatetime')
    print(f"\n2. Timestamp: {txndatetime}")
    
    # Sprawdź format
    assert len(txndatetime) == 19, f"Błąd formatu timestamp: {txndatetime}"
    assert txndatetime[4] == ':' and txndatetime[7] == ':', f"Błąd formatu timestamp: {txndatetime}"
    print("   ✅ Format poprawny (YYYY:MM:DD-HH:MM:SS)")
    
    # Sprawdź czy to czas warszawski
    warsaw_tz = ZoneInfo('Europe/Warsaw')
    now_warsaw = datetime.now(warsaw_tz)
    
    # Parsuj timestamp
    parts = txndatetime.split('-')
    date_parts = parts[0].split(':')
    time_parts = parts[1].split(':')
    
    form_dt = datetime(
        int(date_parts[0]), int(date_parts[1]), int(date_parts[2]),
        int(time_parts[0]), int(time_parts[1]), int(time_parts[2]),
        tzinfo=warsaw_tz
    )
    
    diff = abs((now_warsaw - form_dt).total_seconds())
    assert diff < 10, f"Timestamp nieaktualny (różnica {diff}s)"
    print(f"   ✅ Czas warszawski (różnica {diff:.1f}s)")
    
    # 3. Pozostałe kluczowe pola
    print("\n3. POZOSTAŁE POLA:")
    assert fields.get('storename') == '760995999', "Błąd storename"
    print(f"   ✅ storename: {fields.get('storename')}")
    
    assert fields.get('currency') == '985', "Błąd currency"
    print(f"   ✅ currency: {fields.get('currency')} (PLN)")
    
    assert fields.get('checkoutoption') == 'combinedpage', "Błąd checkoutoption"
    print(f"   ✅ checkoutoption: {fields.get('checkoutoption')}")
    
    assert float(fields.get('chargetotal')) == test_amount, "Błąd amount"
    print(f"   ✅ chargetotal: {fields.get('chargetotal')}")
    
    # 4. URLs
    print("\n4. ADRESY URL:")
    for url_field in ['responseSuccessURL', 'responseFailURL', 'transactionNotificationURL']:
        url = fields.get(url_field)
        assert url and url.startswith('https://'), f"Błąd {url_field}: {url}"
        print(f"   ✅ {url_field}: {url[:50]}...")
    
    # 5. Hash
    print("\n5. HASH:")
    hash_value = fields.get('hashExtended')
    assert hash_value and len(hash_value) > 20, "Błąd hash"
    print(f"   ✅ hashExtended: {hash_value[:30]}... (długość: {len(hash_value)})")
    
    # Zapisz dane do pliku dla analizy
    output_file = f"test_e2e_{test_order_id}.json"
    with open(output_file, 'w') as f:
        json.dump({
            "timestamp": datetime.now().isoformat(),
            "order_id": test_order_id,
            "form_action": form_data['form_action'],
            "form_fields": fields
        }, f, indent=2)
    
    print(f"\n💾 Dane zapisane do: {output_file}")
    
    # Generuj HTML do ręcznego testowania
    html_file = f"test_e2e_{test_order_id}.html"
    html_content = f"""<!DOCTYPE html>
<html>
<head>
    <title>Test E2E - {test_order_id}</title>
    <meta charset="UTF-8">
    <style>
        body {{ font-family: Arial, sans-serif; padding: 20px; background: #f5f5f5; }}
        .container {{ max-width: 800px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; }}
        h1 {{ color: #333; }}
        .info {{ background: #e8f5e9; padding: 15px; border-radius: 5px; margin: 20px 0; }}
        .fields {{ background: #f5f5f5; padding: 15px; border-radius: 5px; margin: 20px 0; }}
        .field {{ margin: 10px 0; padding: 8px; background: white; border-left: 3px solid #4caf50; }}
        .submit-btn {{ background: #4caf50; color: white; padding: 15px 30px; border: none; border-radius: 5px; font-size: 18px; cursor: pointer; }}
        .submit-btn:hover {{ background: #45a049; }}
        .warning {{ background: #fff3cd; border: 1px solid #ffc107; padding: 15px; border-radius: 5px; margin: 20px 0; }}
    </style>
</head>
<body>
    <div class="container">
        <h1>🧪 Test E2E Płatności</h1>
        
        <div class="info">
            <h3>✅ Dane testowe:</h3>
            <p><strong>Order ID:</strong> {test_order_id}</p>
            <p><strong>Kwota:</strong> {test_amount} PLN</p>
            <p><strong>Czas generacji:</strong> {datetime.now(ZoneInfo('Europe/Warsaw')).strftime('%Y-%m-%d %H:%M:%S')} (Warsaw)</p>
        </div>
        
        <div class="fields">
            <h3>📋 Kluczowe pola formularza:</h3>
            <div class="field"><strong>timezone:</strong> {fields.get('timezone')}</div>
            <div class="field"><strong>txndatetime:</strong> {fields.get('txndatetime')}</div>
            <div class="field"><strong>storename:</strong> {fields.get('storename')}</div>
            <div class="field"><strong>chargetotal:</strong> {fields.get('chargetotal')}</div>
            <div class="field"><strong>currency:</strong> {fields.get('currency')}</div>
        </div>
        
        <div class="warning">
            <h3>⚠️ Karta testowa Fiserv:</h3>
            <p><strong>Numer:</strong> 4012 0010 3714 1112</p>
            <p><strong>Data ważności:</strong> 12/26</p>
            <p><strong>CVV:</strong> 123</p>
        </div>
        
        <form method="POST" action="{form_data['form_action']}" id="paymentForm">
"""
    
    # Dodaj wszystkie pola formularza
    for key, value in fields.items():
        html_content += f'            <input type="hidden" name="{key}" value="{value}">\n'
    
    html_content += """
            <button type="submit" class="submit-btn">🚀 Wyślij do Fiserv</button>
        </form>
        
        <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #ddd;">
            <small>Wygenerowano: """ + datetime.now().isoformat() + """</small>
        </div>
    </div>
</body>
</html>"""
    
    with open(html_file, 'w') as f:
        f.write(html_content)
    
    print(f"📄 HTML do testowania: {html_file}")
    
    print("\n" + "="*60)
    print("✅ TEST ZAKOŃCZONY POMYŚLNIE!")
    print("="*60)
    print("\nWszystkie weryfikacje przeszły poprawnie:")
    print("  ✅ Timezone: Europe/Warsaw")
    print("  ✅ Timestamp: Aktualny czas warszawski")
    print("  ✅ Wszystkie wymagane pola są poprawne")
    print(f"\n🎯 Możesz teraz otworzyć {html_file} w przeglądarce")
    print("   i przetestować płatność z kartą testową Fiserv")
    
    return True

if __name__ == "__main__":
    test_e2e_payment()