#!/usr/bin/env python3
"""
Test płatności przez API backend
"""

import requests
import json
from datetime import datetime

# Backend API URL (lokalny lub zdalny)
API_BASE_URL = "http://192.168.100.159:8001/api"  # Serwer produkcyjny

def test_payment_initiation():
    """Test inicjalizacji płatności przez API"""
    
    print("\n=== Test płatności przez API Backend ===\n")
    
    # Dane płatności
    payment_data = {
        "goal_id": "church",  # Cel: Ofiara na kościół
        "amount": 25.50,
        "payment_method": "card",
        "donor_name": "Jan Testowy",
        "donor_email": "jan.testowy@example.com",
        "message": "Test płatności z poprawkami Warsaw timezone"
    }
    
    print(f"Wysyłanie płatności:")
    print(f"  Cel: {payment_data['goal_id']}")
    print(f"  Kwota: {payment_data['amount']} PLN")
    print(f"  Metoda: {payment_data['payment_method']}")
    print(f"  Darczyńca: {payment_data['donor_name']}")
    
    # Wyślij żądanie
    try:
        response = requests.post(
            f"{API_BASE_URL}/payments/initiate",
            json=payment_data,
            headers={"Content-Type": "application/json"}
        )
        
        print(f"\nStatus odpowiedzi: {response.status_code}")
        
        if response.status_code == 200:
            result = response.json()
            print("\n✓ Płatność zainicjowana pomyślnie!")
            print(f"  Payment ID: {result.get('payment_id')}")
            print(f"  Form Action: {result.get('form_action')}")
            
            # Wyświetl niektóre pola formularza
            form_fields = result.get('form_fields', {})
            print("\nPola formularza:")
            print(f"  Store: {form_fields.get('storename')}")
            print(f"  Timezone: {form_fields.get('timezone')}")
            print(f"  Timestamp: {form_fields.get('txndatetime')}")
            print(f"  Amount: {form_fields.get('chargetotal')} PLN")
            print(f"  Order ID: {form_fields.get('oid')}")
            print(f"  Hash: {form_fields.get('hashExtended', '')[:30]}...")
            
            # Zapisz HTML formularza do pliku
            if 'form_html' in result:
                filename = f"payment_form_{result.get('payment_id')}.html"
                with open(filename, 'w', encoding='utf-8') as f:
                    f.write(result['form_html'])
                print(f"\n✓ Formularz HTML zapisany do: {filename}")
            
            return result
            
        else:
            print(f"\n✗ Błąd: {response.text}")
            return None
            
    except requests.exceptions.ConnectionError:
        print("\n✗ Nie można połączyć się z serwerem backend")
        print("  Upewnij się, że serwer działa na porcie 8001")
        return None
    except Exception as e:
        print(f"\n✗ Nieoczekiwany błąd: {e}")
        return None

def test_payment_with_blik():
    """Test płatności BLIK"""
    
    print("\n=== Test płatności BLIK ===\n")
    
    payment_data = {
        "goal_id": "poor",  # Cel: Ofiara na ubogich
        "amount": 15.00,
        "payment_method": "blik",
        "donor_name": "Anna Testowa",
        "donor_email": "anna.test@example.com"
    }
    
    print(f"Wysyłanie płatności BLIK:")
    print(f"  Cel: {payment_data['goal_id']}")
    print(f"  Kwota: {payment_data['amount']} PLN")
    
    try:
        response = requests.post(
            f"{API_BASE_URL}/payments/initiate",
            json=payment_data,
            headers={"Content-Type": "application/json"}
        )
        
        if response.status_code == 200:
            result = response.json()
            form_fields = result.get('form_fields', {})
            
            if 'blikPayment' in form_fields:
                print(f"\n✓ BLIK payment flag: {form_fields['blikPayment']}")
            
            print(f"✓ Payment ID: {result.get('payment_id')}")
            print(f"✓ Timestamp: {form_fields.get('txndatetime')}")
            
            return result
        else:
            print(f"\n✗ Błąd: {response.text}")
            return None
            
    except Exception as e:
        print(f"\n✗ Błąd: {e}")
        return None

def check_organization_data():
    """Sprawdź dane organizacji"""
    
    print("\n=== Dane organizacji ===\n")
    
    try:
        response = requests.get(f"{API_BASE_URL}/organization")
        
        if response.status_code == 200:
            org = response.json()
            print(f"Organizacja: {org['name']}")
            print(f"Lokalizacja: {org['location']}")
            print("\nCele zbiórki:")
            
            for goal in org['goals']:
                progress = (goal['collected_amount'] / goal['target_amount']) * 100
                print(f"  - {goal['name']}: {goal['collected_amount']:.2f}/{goal['target_amount']:.2f} PLN ({progress:.1f}%)")
            
            return org
        else:
            print(f"✗ Błąd pobierania danych: {response.status_code}")
            return None
            
    except Exception as e:
        print(f"✗ Błąd: {e}")
        return None

def main():
    """Uruchom wszystkie testy"""
    
    print("="*60)
    print("TESTY PŁATNOŚCI - BACKEND API")
    print(f"Timestamp: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("="*60)
    
    # Sprawdź dane organizacji
    org = check_organization_data()
    
    if org:
        # Test standardowej płatności
        payment1 = test_payment_initiation()
        
        # Test płatności BLIK
        payment2 = test_payment_with_blik()
        
        # Podsumowanie
        print("\n" + "="*60)
        print("PODSUMOWANIE TESTÓW")
        print("="*60)
        
        if payment1:
            print("✓ Test płatności kartą: SUKCES")
        else:
            print("✗ Test płatności kartą: BŁĄD")
            
        if payment2:
            print("✓ Test płatności BLIK: SUKCES")
        else:
            print("✗ Test płatności BLIK: BŁĄD")
    else:
        print("\n✗ Nie można kontynuować testów - brak połączenia z API")

if __name__ == "__main__":
    main()