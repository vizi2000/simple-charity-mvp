#!/usr/bin/env python3
"""
Test wszystkich metod płatności i kart z obrazu testowego
"""

import os
from datetime import datetime
from app.utils.fiserv_ipg_client import FiservIPGClient
import webbrowser
import hmac
import hashlib
import base64

def test_all_payment_methods():
    """Generuj testy dla wszystkich metod płatności"""
    
    print("="*60)
    print("TEST WSZYSTKICH METOD PŁATNOŚCI I KART")
    print("="*60)
    
    # Karty z obrazu testowego
    test_cards = [
        # Karty z dokumentacji
        {"name": "Visa (dokumentacja)", "number": "4005550000000019", "cvv": "111", "exp": "12/25", "source": "docs"},
        {"name": "Mastercard (dokumentacja)", "number": "5204740000001002", "cvv": "111", "exp": "12/25", "source": "docs"},
        
        # Karty z obrazu testowego
        {"name": "Visa Debit", "number": "4410947715337430", "cvv": "287", "exp": "12/26", "source": "image"},
        {"name": "Mastercard Debit", "number": "5575233623260024", "cvv": "123", "exp": "12/26", "source": "image"},
        {"name": "Visa", "number": "4176660000000100", "cvv": "79", "exp": "12/24", "source": "image"},
    ]
    
    client = FiservIPGClient()
    
    # HTML
    html = f"""<!DOCTYPE html>
<html>
<head>
    <title>Test Wszystkich Metod Płatności</title>
    <style>
        body {{ 
            font-family: Arial, sans-serif; 
            max-width: 1400px; 
            margin: 20px auto; 
            padding: 20px;
            background: #f5f5f5;
        }}
        .section {{
            background: white;
            padding: 25px;
            margin: 20px 0;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }}
        .card-info {{
            background: #e3f2fd;
            padding: 15px;
            border-radius: 5px;
            margin: 10px 0;
            font-family: monospace;
            border-left: 4px solid #2196F3;
        }}
        .blik-info {{
            background: #f3e5f5;
            padding: 15px;
            border-radius: 5px;
            margin: 10px 0;
            border-left: 4px solid #9c27b0;
        }}
        button {{
            background: #4CAF50;
            color: white;
            border: none;
            padding: 12px 24px;
            font-size: 16px;
            border-radius: 5px;
            cursor: pointer;
            margin: 5px;
            font-weight: bold;
        }}
        button:hover {{
            background: #45a049;
        }}
        .blik-button {{
            background: #9c27b0;
        }}
        .blik-button:hover {{
            background: #7b1fa2;
        }}
        .warning {{
            background: #fff3cd;
            border: 1px solid #ffc107;
            padding: 15px;
            border-radius: 5px;
            margin: 20px 0;
        }}
        .success {{
            background: #d4edda;
            border: 1px solid #28a745;
            padding: 15px;
            border-radius: 5px;
            margin: 20px 0;
        }}
        table {{
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }}
        th, td {{
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }}
        th {{
            background: #f2f2f2;
            font-weight: bold;
        }}
        .from-image {{
            background: #e8f5e9;
        }}
    </style>
</head>
<body>
    <h1>🔍 Test Wszystkich Metod Płatności Fiserv</h1>
    
    <div class="warning">
        <h3>⚠️ Ważne informacje o testach:</h3>
        <ul>
            <li>Używamy kart z <strong>obrazu testowego</strong> oraz oficjalnej dokumentacji</li>
            <li>Testujemy również <strong>BLIK</strong></li>
            <li>VPN jest włączony (IP: nie z Play)</li>
            <li>Używamy <strong>checkoutoption='classic'</strong> (przechodzi walidację)</li>
        </ul>
    </div>
"""
    
    # Sekcja 1: BLIK
    html += """
    <div class="section">
        <h2>🟣 Test BLIK</h2>
        <div class="blik-info">
            <strong>BLIK nie wymaga danych karty!</strong><br>
            Użytkownik wprowadza tylko 6-cyfrowy kod z aplikacji bankowej.
        </div>
"""
    
    # Test BLIK z PLN
    order_id = f"BLIK-PLN-{datetime.now().strftime('%Y%m%d%H%M%S')}"
    form_data = client.create_payment_form_data(
        amount=10.00,
        order_id=order_id,
        description="Test BLIK PLN",
        success_url="https://example.com/success",
        failure_url="https://example.com/failure",
        payment_method="blik"
    )
    
    html += f"""
        <form method="POST" action="{form_data['form_action']}" target="_blank">
"""
    for key, value in form_data['form_fields'].items():
        html += f'            <input type="hidden" name="{key}" value="{value}">\n'
    
    html += """            <button type="submit" class="blik-button">🟣 Test BLIK (10 PLN)</button>
        </form>
        
        <p><strong>Kod testowy BLIK:</strong> Sprawdź w dokumentacji lub użyj dowolnego 6-cyfrowego kodu</p>
    </div>
"""
    
    # Sekcja 2: Karty płatnicze
    html += """
    <div class="section">
        <h2>💳 Test Kart Płatniczych</h2>
        
        <table>
            <tr>
                <th>Karta</th>
                <th>Numer</th>
                <th>CVV</th>
                <th>Data</th>
                <th>Źródło</th>
                <th>Test PLN</th>
                <th>Test EUR</th>
            </tr>
"""
    
    # Testy kart
    for card in test_cards:
        row_class = 'from-image' if card['source'] == 'image' else ''
        html += f"""
            <tr class="{row_class}">
                <td><strong>{card['name']}</strong></td>
                <td style="font-family: monospace">{card['number']}</td>
                <td>{card['cvv']}</td>
                <td>{card['exp']}</td>
                <td>{card['source']}</td>
"""
        
        # Test PLN
        order_id_pln = f"CARD-PLN-{card['number'][-4:]}-{datetime.now().strftime('%Y%m%d%H%M%S')}"
        form_data_pln = client.create_payment_form_data(
            amount=10.00,
            order_id=order_id_pln,
            description=f"Test {card['name']} PLN",
            success_url="https://example.com/success",
            failure_url="https://example.com/failure"
        )
        
        html += """                <td>
                    <form method="POST" action="{}" target="_blank" style="display: inline;">
""".format(form_data_pln['form_action'])
        
        for key, value in form_data_pln['form_fields'].items():
            html += f'                        <input type="hidden" name="{key}" value="{value}">\n'
        
        html += """                        <button type="submit">PLN</button>
                    </form>
                </td>
"""
        
        # Test EUR
        order_id_eur = f"CARD-EUR-{card['number'][-4:]}-{datetime.now().strftime('%Y%m%d%H%M%S')}"
        form_data_eur = client.create_payment_form_data(
            amount=10.00,
            order_id=order_id_eur,
            description=f"Test {card['name']} EUR",
            success_url="https://example.com/success",
            failure_url="https://example.com/failure"
        )
        
        # Zmień walutę na EUR
        form_data_eur['form_fields']['currency'] = '978'
        
        # Przelicz hash
        sorted_fields = sorted([
            (k, v) for k, v in form_data_eur['form_fields'].items() 
            if k not in ['hashExtended', 'hash_algorithm']
        ])
        values_to_hash = '|'.join(str(v) for k, v in sorted_fields)
        
        hash_value = hmac.new(
            client.shared_secret.encode('utf-8'),
            values_to_hash.encode('utf-8'),
            hashlib.sha256
        ).digest()
        form_data_eur['form_fields']['hashExtended'] = base64.b64encode(hash_value).decode('utf-8')
        
        html += """                <td>
                    <form method="POST" action="{}" target="_blank" style="display: inline;">
""".format(form_data_eur['form_action'])
        
        for key, value in form_data_eur['form_fields'].items():
            html += f'                        <input type="hidden" name="{key}" value="{value}">\n'
        
        html += """                        <button type="submit">EUR</button>
                    </form>
                </td>
            </tr>
"""
    
    html += """        </table>
    </div>
"""
    
    # Sekcja 3: Instrukcje
    html += """
    <div class="section">
        <h2>📝 Instrukcje testowania</h2>
        
        <h3>Dla BLIK:</h3>
        <ol>
            <li>Kliknij przycisk "Test BLIK"</li>
            <li>Na stronie Fiserv wybierz opcję BLIK</li>
            <li>Wprowadź 6-cyfrowy kod (dowolny dla testów)</li>
            <li>Zapisz czy transakcja przeszła</li>
        </ol>
        
        <h3>Dla Kart:</h3>
        <ol>
            <li>Kliknij przycisk PLN lub EUR dla danej karty</li>
            <li>Na stronie Fiserv wprowadź dane karty dokładnie jak w tabeli</li>
            <li>Użyj dowolnego imienia (np. "Test User")</li>
            <li>Zapisz jaki błąd otrzymałeś</li>
        </ol>
        
        <div class="success">
            <strong>🎯 Karty z obrazu testowego</strong> (zielone wiersze) powinny mieć większą szansę na sukces!
        </div>
    </div>
    
    <div class="section">
        <h2>📊 Tabela wyników (wypełnij po testach)</h2>
        
        <table>
            <tr>
                <th>Metoda</th>
                <th>Waluta</th>
                <th>Rezultat</th>
                <th>Komunikat błędu</th>
            </tr>
            <tr>
                <td>BLIK</td>
                <td>PLN</td>
                <td>[ ] Sukces [ ] Błąd</td>
                <td>_________________________</td>
            </tr>
            <tr>
                <td>Visa Debit (obraz)</td>
                <td>PLN</td>
                <td>[ ] Sukces [ ] Błąd</td>
                <td>_________________________</td>
            </tr>
            <tr>
                <td>Visa Debit (obraz)</td>
                <td>EUR</td>
                <td>[ ] Sukces [ ] Błąd</td>
                <td>_________________________</td>
            </tr>
            <tr>
                <td>Mastercard Debit (obraz)</td>
                <td>PLN</td>
                <td>[ ] Sukces [ ] Błąd</td>
                <td>_________________________</td>
            </tr>
            <tr>
                <td>Mastercard Debit (obraz)</td>
                <td>EUR</td>
                <td>[ ] Sukces [ ] Błąd</td>
                <td>_________________________</td>
            </tr>
            <tr>
                <td>Visa (obraz)</td>
                <td>PLN</td>
                <td>[ ] Sukces [ ] Błąd</td>
                <td>_________________________</td>
            </tr>
            <tr>
                <td>Visa (obraz)</td>
                <td>EUR</td>
                <td>[ ] Sukces [ ] Błąd</td>
                <td>_________________________</td>
            </tr>
        </table>
    </div>
    
    <div class="warning">
        <h3>🚨 Do supportu Fiserv:</h3>
        <p>Jeśli wszystkie metody nie działają, wyślij tę tabelę wyników wraz z ID transakcji.</p>
        <p>Szczególnie ważne: czy BLIK działa? Czy karty z obrazu testowego działają?</p>
    </div>
</body>
</html>"""
    
    filename = "test_all_payment_methods.html"
    with open(filename, 'w') as f:
        f.write(html)
    
    print(f"\n✅ Test zapisany jako: {filename}")
    print("\n🎯 Przetestuj szczególnie:")
    print("1. BLIK - może działać nawet jeśli karty nie działają")
    print("2. Karty z obrazu testowego - powinny mieć większą szansę")
    print("3. Różnice między PLN a EUR")
    
    # Otwórz w przeglądarce
    webbrowser.open(f"file://{os.path.abspath(filename)}")

if __name__ == "__main__":
    test_all_payment_methods()