#!/usr/bin/env python3
"""
Test płatności po włączeniu VPN
"""

import requests
import os
from datetime import datetime
from app.utils.fiserv_ipg_client import FiservIPGClient
import webbrowser

def check_new_ip():
    """Sprawdź nowe IP po VPN"""
    try:
        response = requests.get('https://ipinfo.io/json', timeout=5)
        ip_info = response.json()
        
        print("="*60)
        print("NOWE IP PO WŁĄCZENIU VPN")
        print("="*60)
        print(f"IP: {ip_info.get('ip')}")
        print(f"Kraj: {ip_info.get('country')}")
        print(f"Miasto: {ip_info.get('city')}")
        print(f"Organizacja: {ip_info.get('org')}")
        
        # Sprawdź czy to nie jest już Play
        if 'play' in ip_info.get('org', '').lower():
            print("\n⚠️  UWAGA: Nadal masz IP z Play!")
            print("Sprawdź czy VPN jest poprawnie połączony.")
            return False
        else:
            print("\n✅ IP zmienione! Nie jest już z Play.")
            return True
            
    except Exception as e:
        print(f"Błąd: {e}")
        return False

def test_payment_with_vpn():
    """Test płatności z nowym IP"""
    
    if not check_new_ip():
        print("\nSprawdź połączenie VPN i spróbuj ponownie.")
        return
    
    print("\n" + "="*60)
    print("TEST PŁATNOŚCI Z VPN")
    print("="*60)
    
    # Przygotuj test
    client = FiservIPGClient()
    order_id = f"VPN-TEST-{datetime.now().strftime('%Y%m%d%H%M%S')}"
    
    # Generuj formularz
    form_data = client.create_payment_form_data(
        amount=10.00,
        order_id=order_id,
        description="Test z VPN",
        success_url="https://example.com/success",
        failure_url="https://example.com/failure"
    )
    
    print(f"\nOrder ID: {order_id}")
    print("Generuję formularz testowy...")
    
    # HTML
    html = f"""<!DOCTYPE html>
<html>
<head>
    <title>Test z VPN</title>
    <style>
        body {{ 
            font-family: Arial, sans-serif; 
            max-width: 800px; 
            margin: 50px auto; 
            padding: 20px;
        }}
        .success {{
            background: #d4edda;
            border: 2px solid #28a745;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
        }}
        .info {{
            background: #e9ecef;
            padding: 15px;
            border-radius: 5px;
            margin: 20px 0;
            font-family: monospace;
        }}
        button {{
            background: #28a745;
            color: white;
            border: none;
            padding: 15px 30px;
            font-size: 18px;
            border-radius: 5px;
            cursor: pointer;
            width: 100%;
            font-weight: bold;
        }}
        button:hover {{
            background: #218838;
        }}
    </style>
</head>
<body>
    <div class="success">
        <h1>✅ VPN Aktywny - Test Płatności</h1>
        <p>IP zostało zmienione. Teraz przetestuj płatność!</p>
    </div>
    
    <div class="info">
        <strong>Order ID:</strong> {order_id}<br>
        <strong>Kwota:</strong> 10.00 PLN<br>
        <strong>Checkout:</strong> classic (działa!)
    </div>
    
    <form method="POST" action="{form_data['form_action']}">
"""
    
    for key, value in form_data['form_fields'].items():
        html += f'        <input type="hidden" name="{key}" value="{value}">\n'
    
    html += """        <button type="submit">🚀 TESTUJ PŁATNOŚĆ Z VPN</button>
    </form>
    
    <div style="margin-top: 30px; padding: 15px; background: #cce5ff; border-radius: 5px;">
        <strong>Co się powinno stać:</strong><br>
        1. Powinnaś zobaczyć stronę płatności Fiserv<br>
        2. NIE powinno być błędu aplikacji<br>
        3. Możesz użyć karty testowej: 4005550000000019<br><br>
        
        <strong>Jeśli działa:</strong><br>
        ✅ Problem był z IP mobilnym!<br>
        ✅ Rozwiązanie: zawsze używaj VPN lub deploy na serwer
    </div>
</body>
</html>"""
    
    filename = "test_vpn_payment.html"
    with open(filename, 'w') as f:
        f.write(html)
    
    print(f"\n✅ Test zapisany jako: {filename}")
    print("\n🎯 Kliknij przycisk i sprawdź czy teraz działa!")
    
    # Otwórz w przeglądarce
    webbrowser.open(f"file://{os.path.abspath(filename)}")

if __name__ == "__main__":
    test_payment_with_vpn()