#!/usr/bin/env python3
"""
Test naprawy dla Combined Page - skoro jest skonfigurowana
"""

import os
from datetime import datetime, timezone, timedelta
from app.utils.fiserv_ipg_client import FiservIPGClient
import webbrowser
import hmac
import hashlib
import base64

def test_combined_page_fix():
    """Test różnych wariantów dla combined page"""
    
    print("="*60)
    print("TEST COMBINED PAGE - NAPRAWIAMY VALIDATION ERROR")
    print("="*60)
    
    client = FiservIPGClient()
    
    # Tymczasowo zmień na combinedpage
    original_checkout = 'classic'
    
    # HTML
    html = f"""<!DOCTYPE html>
<html>
<head>
    <title>Test Combined Page Fix</title>
    <style>
        body {{ 
            font-family: Arial, sans-serif; 
            max-width: 1200px; 
            margin: 20px auto; 
            padding: 20px;
            background: #f5f5f5;
        }}
        .test-section {{
            background: white;
            padding: 20px;
            margin: 15px 0;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }}
        .important {{
            background: #fff3cd;
            border: 2px solid #ffc107;
            padding: 15px;
            margin: 20px 0;
        }}
        button {{
            background: #28a745;
            color: white;
            border: none;
            padding: 12px 24px;
            margin: 5px;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
        }}
        button:hover {{ background: #218838; }}
        .code {{
            background: #f8f9fa;
            padding: 10px;
            border: 1px solid #dee2e6;
            border-radius: 4px;
            font-family: monospace;
            margin: 10px 0;
        }}
    </style>
</head>
<body>
    <h1>🔧 Test Combined Page (która jest skonfigurowana)</h1>
    
    <div class="important">
        <h3>⚠️ Odkrycie:</h3>
        <ul>
            <li><strong>Combined Page</strong> - SKONFIGUROWANA (ma metody płatności)</li>
            <li><strong>Classic</strong> - PUSTA (brak konfiguracji)</li>
        </ul>
        <p>Musimy naprawić validationError dla combinedpage!</p>
    </div>
"""
    
    tests = []
    
    # Test 1: Standard combinedpage
    test1_fields = {
        'storename': client.store_id,
        'txntype': 'sale',
        'timezone': 'Europe/Berlin',
        'txndatetime': datetime.now(timezone.utc).strftime("%Y:%m:%d-%H:%M:%S"),
        'chargetotal': '10.00',
        'currency': '985',  # PLN
        'checkoutoption': 'combinedpage',  # ZMIANA!
        'oid': f'COMBINED-FIX-{datetime.now().strftime("%Y%m%d%H%M%S")}',
        'hash_algorithm': 'HMACSHA256'
    }
    tests.append(("Combined Page - Standard", test1_fields))
    
    # Test 2: Bez timezone (może to problem?)
    test2_fields = test1_fields.copy()
    del test2_fields['timezone']
    test2_fields['oid'] = f'COMBINED-NOTZ-{datetime.now().strftime("%Y%m%d%H%M%S")}'
    tests.append(("Combined Page - Bez timezone", test2_fields))
    
    # Test 3: Bez txndatetime
    test3_fields = {
        'storename': client.store_id,
        'txntype': 'sale',
        'chargetotal': '10.00',
        'currency': '985',
        'checkoutoption': 'combinedpage',
        'oid': f'COMBINED-NODT-{datetime.now().strftime("%Y%m%d%H%M%S")}',
        'hash_algorithm': 'HMACSHA256'
    }
    tests.append(("Combined Page - Bez datetime", test3_fields))
    
    # Test 4: Z response URLs
    test4_fields = test1_fields.copy()
    test4_fields['responseSuccessURL'] = 'https://77597ddbcc37.ngrok-free.app/api/payments/success'
    test4_fields['responseFailURL'] = 'https://77597ddbcc37.ngrok-free.app/api/payments/failure'
    test4_fields['oid'] = f'COMBINED-URLS-{datetime.now().strftime("%Y%m%d%H%M%S")}'
    tests.append(("Combined Page - Z URLs", test4_fields))
    
    # Test 5: EUR zamiast PLN
    test5_fields = test1_fields.copy()
    test5_fields['currency'] = '978'  # EUR
    test5_fields['oid'] = f'COMBINED-EUR-{datetime.now().strftime("%Y%m%d%H%M%S")}'
    tests.append(("Combined Page - EUR", test5_fields))
    
    # Test 6: Różne Shared Secrets
    secrets_to_test = [
        ("Original", "j}2W3P)Lwv"),
        ("Alternative", "c7dP/$5PBx"),
        ("API Secret", "aGOkU61VoIl5AWApLL7avcCpIVZxVGG6jYGVQib8xuG")
    ]
    
    # Generuj testy
    for name, fields in tests:
        html += f"""
    <div class="test-section">
        <h3>{name}</h3>
        <div class="code">
"""
        
        # Pokaż pola
        display_fields = {k: v for k, v in fields.items() if k not in ['hash_algorithm', 'hashExtended']}
        for k, v in sorted(display_fields.items()):
            html += f"            {k}: {v}<br>\n"
        
        # Oblicz hash ze standardowym secretem
        hash_fields = {k: v for k, v in fields.items() if k not in ['hash_algorithm', 'hashExtended']}
        sorted_hash_fields = sorted(hash_fields.items())
        hash_string = '|'.join(str(v) for k, v in sorted_hash_fields)
        
        hash_bytes = hmac.new(
            client.shared_secret.encode('utf-8'),
            hash_string.encode('utf-8'),
            hashlib.sha256
        ).digest()
        hash_value = base64.b64encode(hash_bytes).decode('utf-8')
        
        fields['hashExtended'] = hash_value
        
        html += f"""            <br>Hash: {hash_value[:40]}...
        </div>
        
        <form method="POST" action="{client.gateway_url}" target="_blank">
"""
        for k, v in fields.items():
            html += f'            <input type="hidden" name="{k}" value="{v}">\n'
        
        html += f"""            <button type="submit">Test: {name}</button>
        </form>
    </div>
"""
    
    # Test z różnymi secretami
    html += """
    <div class="test-section" style="background: #e8f5e9;">
        <h3>🔐 Test różnych Shared Secrets dla Combined Page</h3>
"""
    
    base_fields = {
        'storename': client.store_id,
        'txntype': 'sale',
        'chargetotal': '10.00',
        'currency': '985',
        'checkoutoption': 'combinedpage',
        'oid': f'COMBINED-SECRET-{datetime.now().strftime("%Y%m%d%H%M%S")}',
        'hash_algorithm': 'HMACSHA256'
    }
    
    for secret_name, secret_value in secrets_to_test:
        # Oblicz hash z tym secretem
        hash_fields = {k: v for k, v in base_fields.items() if k not in ['hash_algorithm', 'hashExtended']}
        sorted_hash_fields = sorted(hash_fields.items())
        hash_string = '|'.join(str(v) for k, v in sorted_hash_fields)
        
        hash_bytes = hmac.new(
            secret_value.encode('utf-8'),
            hash_string.encode('utf-8'),
            hashlib.sha256
        ).digest()
        test_fields = base_fields.copy()
        test_fields['hashExtended'] = base64.b64encode(hash_bytes).decode('utf-8')
        test_fields['oid'] = f'COMBINED-{secret_name.upper()}-{datetime.now().strftime("%Y%m%d%H%M%S")}'
        
        html += f"""        <h4>Secret: {secret_name}</h4>
        <form method="POST" action="{client.gateway_url}" target="_blank" style="display: inline;">
"""
        for k, v in test_fields.items():
            html += f'            <input type="hidden" name="{k}" value="{v}">\n'
        
        html += f"""            <button type="submit">Test {secret_name} Secret</button>
        </form>
"""
    
    html += """    </div>
    
    <div class="important">
        <h3>📝 Co sprawdzić:</h3>
        <ol>
            <li>Czy któryś test NIE daje validationError?</li>
            <li>Czy dochodzi do strony płatności?</li>
            <li>Który secret działa (jeśli jakiś)?</li>
        </ol>
        
        <p><strong>Jeśli wszystkie dają validationError:</strong><br>
        Problem jest z Shared Secret lub wymagane jest dodatkowe pole dla combinedpage.</p>
    </div>
</body>
</html>"""
    
    filename = "test_combined_page_fix.html"
    with open(filename, 'w') as f:
        f.write(html)
    
    print(f"\n✅ Test zapisany jako: {filename}")
    print("\n🎯 Testuj różne warianty Combined Page")
    print("Skoro jest skonfigurowana, powinna działać!")
    
    # Otwórz w przeglądarce
    webbrowser.open(f"file://{os.path.abspath(filename)}")

if __name__ == "__main__":
    test_combined_page_fix()