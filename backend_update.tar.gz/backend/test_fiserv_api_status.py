#!/usr/bin/env python3
"""
Test statusu konta Fiserv przez API
"""
import requests
import base64
import json
from datetime import datetime

# Dane z .env
API_KEY = "xWdewnCcYTy8G0s4oS1r5GAOmcdVRYQn"
API_SECRET = "aGOkU61VoIl5AWApLL7avcCpIVZxVGG6jYGVQib8xuG"
STORE_ID = "760995999"

def test_api_connection():
    """Test podstawowego połączenia z API"""
    print("="*60)
    print("TEST STATUSU KONTA FISERV")
    print("="*60)
    print(f"Store ID: {STORE_ID}")
    print(f"Test time: {datetime.now()}")
    print("="*60)
    
    # Podstawowa autoryzacja
    credentials = f"{API_KEY}:{API_SECRET}"
    encoded_credentials = base64.b64encode(credentials.encode()).decode()
    
    headers = {
        "Authorization": f"Basic {encoded_credentials}",
        "Content-Type": "application/json",
        "Accept": "application/json"
    }
    
    # Różne endpointy do testowania
    test_endpoints = [
        {
            "name": "Store Info",
            "url": f"https://test.ipg-online.com/api/v1/stores/{STORE_ID}",
            "method": "GET"
        },
        {
            "name": "Payment Methods",
            "url": "https://test.ipg-online.com/api/v1/payment-methods",
            "method": "GET"
        },
        {
            "name": "Supported Currencies",
            "url": "https://test.ipg-online.com/api/v1/currencies",
            "method": "GET"
        },
        {
            "name": "Store Status",
            "url": f"https://test.ipg-online.com/api/v1/stores/{STORE_ID}/status",
            "method": "GET"
        }
    ]
    
    results = []
    
    for endpoint in test_endpoints:
        print(f"\n[{endpoint['name']}]")
        print(f"URL: {endpoint['url']}")
        
        try:
            if endpoint['method'] == 'GET':
                response = requests.get(
                    endpoint['url'], 
                    headers=headers, 
                    timeout=10
                )
            
            print(f"Status Code: {response.status_code}")
            
            result = {
                "endpoint": endpoint['name'],
                "status_code": response.status_code,
                "success": response.status_code == 200
            }
            
            if response.status_code == 200:
                print("✅ SUCCESS")
                try:
                    data = response.json()
                    print(f"Response: {json.dumps(data, indent=2)[:500]}...")
                    result["data"] = data
                except:
                    print(f"Response: {response.text[:200]}...")
                    result["data"] = response.text
            else:
                print("❌ FAILED")
                print(f"Error: {response.text[:200]}...")
                result["error"] = response.text
                
            results.append(result)
            
        except requests.exceptions.Timeout:
            print("❌ TIMEOUT")
            results.append({
                "endpoint": endpoint['name'],
                "status_code": 0,
                "success": False,
                "error": "Timeout"
            })
        except requests.exceptions.ConnectionError as e:
            print(f"❌ CONNECTION ERROR: {str(e)[:100]}")
            results.append({
                "endpoint": endpoint['name'],
                "status_code": 0,
                "success": False,
                "error": str(e)
            })
        except Exception as e:
            print(f"❌ ERROR: {type(e).__name__}: {str(e)[:100]}")
            results.append({
                "endpoint": endpoint['name'],
                "status_code": 0,
                "success": False,
                "error": str(e)
            })
    
    # Podsumowanie
    print("\n" + "="*60)
    print("PODSUMOWANIE")
    print("="*60)
    
    successful = sum(1 for r in results if r.get("success", False))
    total = len(results)
    
    print(f"Testy zakończone: {successful}/{total} sukces")
    
    if successful == 0:
        print("\n⚠️  UWAGA: Żaden endpoint nie odpowiedział poprawnie!")
        print("Możliwe przyczyny:")
        print("- Konto nieaktywne")
        print("- Nieprawidłowe credentials")
        print("- Problem z dostępem do API")
        print("- IP nie jest na białej liście")
    elif successful < total:
        print("\n⚠️  Niektóre endpointy nie działają")
        print("Sprawdź które funkcje są dostępne dla tego konta")
    else:
        print("\n✅ Wszystkie testy zakończone sukcesem!")
        print("Konto wydaje się być aktywne")
    
    # Zapisz wyniki
    filename = f"fiserv_api_test_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    with open(filename, 'w') as f:
        json.dump({
            "test_time": datetime.now().isoformat(),
            "store_id": STORE_ID,
            "results": results
        }, f, indent=2)
    
    print(f"\nWyniki zapisane w: {filename}")

if __name__ == "__main__":
    test_api_connection()