#!/usr/bin/env python3
"""
Kompleksowy test płatności Fiserv z poprawkami Warsaw timezone
"""

import os
import sys
import requests
import hmac
import hashlib
import base64
from datetime import datetime
from zoneinfo import ZoneInfo
import time
import uuid

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app.utils.fiserv_ipg_client import fiserv_ipg_client

# Test configuration
FISERV_GATEWAY_URL = 'https://test.ipg-online.com/connect/gateway/processing'
STORE_ID = '760995999'
SHARED_SECRET = 'j}2W3P)Lwv'

def test_timestamp_generation():
    """Test that timestamp is generated correctly in Warsaw timezone"""
    print("\n=== Test 1: Timestamp Generation ===")
    
    warsaw_tz = ZoneInfo('Europe/Warsaw')
    now = datetime.now(warsaw_tz)
    txndatetime = now.strftime("%Y:%m:%d-%H:%M:%S")
    
    print(f"✓ Current Warsaw time: {txndatetime}")
    print(f"✓ Timezone: Europe/Warsaw")
    
    # Verify format
    parts = txndatetime.split('-')
    assert len(parts) == 2, "Invalid timestamp format"
    date_part, time_part = parts
    
    year, month, day = date_part.split(':')
    hour, minute, second = time_part.split(':')
    
    # Verify it's current (within last minute)
    dt = datetime(int(year), int(month), int(day), 
                 int(hour), int(minute), int(second))
    
    now_warsaw = datetime.now(warsaw_tz)
    time_diff = abs((now_warsaw.replace(tzinfo=None) - dt).total_seconds())
    
    assert time_diff < 60, f"Timestamp not current: {time_diff} seconds difference"
    print(f"✓ Timestamp is current (difference: {time_diff:.1f} seconds)")
    
    return True

def test_hash_generation():
    """Test hash generation with sample data"""
    print("\n=== Test 2: Hash Generation ===")
    
    # Sample parameters matching Fiserv requirements
    params = {
        'bemail': 'test@example.com',
        'bname': 'Jan Kowalski',
        'chargetotal': '50.00',
        'checkoutoption': 'combinedpage',
        'currency': '985',
        'hash_algorithm': 'HMACSHA256',
        'oid': f'TEST-{datetime.now().strftime("%Y%m%d%H%M%S")}',
        'responseFailURL': 'https://charity.ngrok.app/platnosc/test/status?result=failure',
        'responseSuccessURL': 'https://charity.ngrok.app/platnosc/test/status?result=success',
        'storename': STORE_ID,
        'timezone': 'Europe/Warsaw',
        'transactionNotificationURL': 'https://charity-webhook.ngrok.app/api/webhooks/fiserv',
        'txndatetime': datetime.now(ZoneInfo('Europe/Warsaw')).strftime("%Y:%m:%d-%H:%M:%S"),
        'txntype': 'sale'
    }
    
    # Generate hash using the same method as fiserv_ipg_client
    exclude_fields = {'hash', 'hashExtended', 'hash_algorithm'}
    sorted_params = sorted([
        (k, v) for k, v in params.items() 
        if k not in exclude_fields and v
    ])
    
    values_to_hash = '|'.join(str(v) for k, v in sorted_params)
    print(f"Hash input (first 100 chars): {values_to_hash[:100]}...")
    
    hash_value = hmac.new(
        SHARED_SECRET.encode('utf-8'),
        values_to_hash.encode('utf-8'),
        hashlib.sha256
    ).digest()
    
    hash_extended = base64.b64encode(hash_value).decode('utf-8')
    print(f"✓ Generated hash: {hash_extended[:30]}...")
    
    return params, hash_extended

def test_payment_form_creation():
    """Test creating payment form data"""
    print("\n=== Test 3: Payment Form Creation ===")
    
    amounts = [25.00, 50.00, 100.00]
    
    for amount in amounts:
        print(f"\nTesting amount: {amount:.2f} PLN")
        
        result = fiserv_ipg_client.create_payment_form_data(
            amount=amount,
            order_id=f'TEST-{uuid.uuid4().hex[:8]}-{int(time.time())}',
            description=f'Test payment {amount} PLN',
            success_url='https://charity.ngrok.app/platnosc/test/status?result=success',
            failure_url='https://charity.ngrok.app/platnosc/test/status?result=failure',
            notification_url='https://charity-webhook.ngrok.app/api/webhooks/fiserv',
            customer_info={
                'name': 'Test User',
                'email': 'test@example.com'
            }
        )
        
        form_fields = result['form_fields']
        
        # Validate required fields
        assert form_fields['storename'] == STORE_ID
        assert form_fields['timezone'] == 'Europe/Warsaw'
        assert form_fields['currency'] == '985'
        assert form_fields['chargetotal'] == f"{amount:.2f}"
        assert form_fields['checkoutoption'] == 'combinedpage'
        assert 'hashExtended' in form_fields
        assert 'txndatetime' in form_fields
        
        print(f"  ✓ Store ID: {form_fields['storename']}")
        print(f"  ✓ Timezone: {form_fields['timezone']}")
        print(f"  ✓ Amount: {form_fields['chargetotal']} PLN")
        print(f"  ✓ Timestamp: {form_fields['txndatetime']}")
        print(f"  ✓ Hash: {form_fields['hashExtended'][:20]}...")

def test_live_payment_submission():
    """Test submitting a payment to Fiserv test environment"""
    print("\n=== Test 4: Live Payment Submission ===")
    
    # Create payment form data
    payment_data = fiserv_ipg_client.create_payment_form_data(
        amount=10.00,  # Small test amount
        order_id=f'LIVE-TEST-{datetime.now().strftime("%Y%m%d%H%M%S")}',
        description='Live integration test',
        success_url='https://charity.ngrok.app/success',
        failure_url='https://charity.ngrok.app/failure',
        notification_url='https://charity-webhook.ngrok.app/webhook',
        customer_info={
            'name': 'Integration Test',
            'email': 'integration@test.com'
        }
    )
    
    form_fields = payment_data['form_fields']
    form_action = payment_data['form_action']
    
    print(f"Submitting to: {form_action}")
    print(f"Order ID: {form_fields['oid']}")
    print(f"Amount: {form_fields['chargetotal']} PLN")
    print(f"Timestamp: {form_fields['txndatetime']}")
    
    # Submit the form
    try:
        response = requests.post(form_action, data=form_fields, timeout=10)
        print(f"\n✓ Response Status: {response.status_code}")
        
        # Save response for analysis
        output_file = f"test_payment_response_{form_fields['oid']}.html"
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(response.text)
        print(f"✓ Response saved to: {output_file}")
        
        # Check for common error messages
        if 'Invalid timestamp' in response.text:
            print("✗ ERROR: Invalid timestamp")
            return False
        elif 'Invalid hash' in response.text:
            print("✗ ERROR: Invalid hash")
            return False
        elif 'Invalid store' in response.text:
            print("✗ ERROR: Invalid store configuration")
            return False
        elif 'payment' in response.text.lower() or 'card' in response.text.lower():
            print("✓ Payment form loaded successfully!")
            return True
        else:
            print("⚠ Check response file for details")
            return None
            
    except requests.exceptions.Timeout:
        print("✗ Request timed out")
        return False
    except Exception as e:
        print(f"✗ Error: {e}")
        return False

def test_blik_payment():
    """Test BLIK payment specifically"""
    print("\n=== Test 5: BLIK Payment ===")
    
    result = fiserv_ipg_client.create_payment_form_data(
        amount=15.00,
        order_id=f'BLIK-{datetime.now().strftime("%Y%m%d%H%M%S")}',
        description='BLIK payment test',
        success_url='https://charity.ngrok.app/blik/success',
        failure_url='https://charity.ngrok.app/blik/failure',
        payment_method='blik',
        customer_info={
            'name': 'BLIK Test User',
            'email': 'blik@test.com'
        }
    )
    
    form_fields = result['form_fields']
    
    assert 'blikPayment' in form_fields
    assert form_fields['blikPayment'] == 'true'
    
    print(f"✓ BLIK payment flag set: {form_fields['blikPayment']}")
    print(f"✓ Order ID: {form_fields['oid']}")
    print(f"✓ Amount: {form_fields['chargetotal']} PLN")
    
    return True

def main():
    """Run all tests"""
    print("="*60)
    print("FISERV PAYMENT INTEGRATION TESTS")
    print("="*60)
    
    tests = [
        ("Timestamp Generation", test_timestamp_generation),
        ("Hash Generation", test_hash_generation),
        ("Payment Form Creation", test_payment_form_creation),
        ("Live Payment Submission", test_live_payment_submission),
        ("BLIK Payment", test_blik_payment)
    ]
    
    results = []
    
    for test_name, test_func in tests:
        try:
            result = test_func()
            results.append((test_name, result))
        except Exception as e:
            print(f"\n✗ {test_name} failed: {e}")
            results.append((test_name, False))
    
    # Summary
    print("\n" + "="*60)
    print("TEST SUMMARY")
    print("="*60)
    
    for test_name, result in results:
        status = "✓ PASSED" if result else "✗ FAILED"
        print(f"{status}: {test_name}")
    
    passed = sum(1 for _, r in results if r)
    total = len(results)
    
    print(f"\nTotal: {passed}/{total} tests passed")
    
    if passed == total:
        print("\n🎉 All tests passed successfully!")
    else:
        print(f"\n⚠ {total - passed} test(s) failed")
    
    return passed == total

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)