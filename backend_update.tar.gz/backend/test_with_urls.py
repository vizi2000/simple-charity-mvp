#!/usr/bin/env python3
"""
Test z URL-ami - może to jest wymagane
"""

from datetime import datetime, timezone
import hmac
import hashlib
import base64

def test_with_urls():
    """Test z pełnymi URL-ami"""
    
    print("="*60)
    print("TEST Z URL-AMI ZWROTNYMI")
    print("="*60)
    
    shared_secret = "j}2W3P)Lwv"
    
    # Test z różnymi URL-ami
    tests = [
        {
            "name": "Z ngrok URL-ami",
            "urls": {
                'responseSuccessURL': 'https://yourapp.ngrok.app/api/payments/success',
                'responseFailURL': 'https://yourapp.ngrok.app/api/payments/failure',
                'transactionNotificationURL': 'https://yourapp.ngrok.app/api/payments/webhooks/fiserv'
            }
        },
        {
            "name": "Z przykładowymi URL-ami",
            "urls": {
                'responseSuccessURL': 'https://example.com/success',
                'responseFailURL': 'https://example.com/failure',
                'transactionNotificationURL': 'https://example.com/notification'
            }
        },
        {
            "name": "Bez URL-i (używa VT)",
            "urls": {}
        }
    ]
    
    html = f"""<!DOCTYPE html>
<html>
<head>
    <title>Test z URL-ami</title>
    <meta charset="UTF-8">
    <style>
        body {{ font-family: Arial, sans-serif; max-width: 1200px; margin: 20px auto; padding: 20px; }}
        .test {{ background: #f8f9fa; padding: 20px; margin: 20px 0; border-radius: 8px; }}
        button {{ background: #28a745; color: white; padding: 12px 24px; margin: 5px; border: none; cursor: pointer; }}
        .info {{ background: #e3f2fd; padding: 15px; margin: 20px 0; border-radius: 5px; }}
        .code {{ background: #f5f5f5; padding: 10px; font-family: monospace; margin: 10px 0; }}
    </style>
</head>
<body>
    <h1>🔗 Test z różnymi URL-ami</h1>
    
    <div class="info">
        <h3>ℹ️ Fiserv wspomniał:</h3>
        <p>"url'e zwrotne mogą być przesyłane w żądaniu lub być na stałe skonfigurowane za pośrednictwem Wirtualnego Terminala"</p>
    </div>
"""
    
    for test in tests:
        order_id = f"URL-TEST-{datetime.now().strftime('%Y%m%d%H%M%S%f')[:17]}"
        txn_datetime = datetime.now(timezone.utc).strftime("%Y:%m:%d-%H:%M:%S")
        
        # Podstawowe pola
        fields = {
            'storename': '760995999',
            'txntype': 'sale',
            'timezone': 'Europe/Warsaw',
            'txndatetime': txn_datetime,
            'chargetotal': '10.00',
            'currency': '985',
            'checkoutoption': 'combinedpage',
            'oid': order_id,
            'hash_algorithm': 'HMACSHA256'
        }
        
        # Dodaj URL-e jeśli są
        fields.update(test['urls'])
        
        # Oblicz hash
        hash_fields = {k: v for k, v in fields.items() if k not in ['hash_algorithm', 'hashExtended']}
        sorted_fields = sorted(hash_fields.items())
        hash_string = '|'.join(str(v) for k, v in sorted_fields)
        
        hash_bytes = hmac.new(
            shared_secret.encode('utf-8'),
            hash_string.encode('utf-8'),
            hashlib.sha256
        ).digest()
        hash_value = base64.b64encode(hash_bytes).decode('utf-8')
        
        fields['hashExtended'] = hash_value
        
        html += f"""
    <div class="test">
        <h3>{test['name']}</h3>
        
        <div class="code">
            Order ID: {order_id}<br>
            Hash: {hash_value[:40]}...
        </div>
        
        <form method="POST" action="https://test.ipg-online.com/connect/gateway/processing" target="_blank">
"""
        
        for k, v in fields.items():
            html += f'            <input type="hidden" name="{k}" value="{v}">\n'
            if k in test['urls']:
                html += f'            <!-- URL: {v} -->\n'
        
        html += f"""            <button type="submit">TEST: {test['name']}</button>
        </form>
    </div>
"""
    
    # Test minimalny
    html += """
    <div class="test">
        <h3>Test Minimalny (absolutne minimum)</h3>
        
        <form method="POST" action="https://test.ipg-online.com/connect/gateway/processing" target="_blank">
            <input type="hidden" name="storename" value="760995999">
            <input type="hidden" name="chargetotal" value="10.00">
            <input type="hidden" name="currency" value="985">
            <button type="submit">TEST MINIMALNY</button>
        </form>
    </div>
    
    <div class="info">
        <h3>💡 Możliwe przyczyny błędu:</h3>
        <ol>
            <li><strong>IPG Connect nie jest aktywny</strong> - mimo że VT działa</li>
            <li><strong>Brak konfiguracji Combined Page</strong> dla IPG Connect</li>
            <li><strong>Problem z datą/czasem</strong> - może format dla Warsaw jest inny?</li>
            <li><strong>Sesja/IP</strong> - może trzeba się zalogować do VT najpierw?</li>
            <li><strong>Konto testowe</strong> ma ograniczenia</li>
        </ol>
    </div>
</body>
</html>"""
    
    with open('test_with_urls.html', 'w', encoding='utf-8') as f:
        f.write(html)
    
    print(f"\n✅ Test zapisany jako: test_with_urls.html")
    print("\n🔍 Testy:")
    print("1. Z ngrok URL-ami")
    print("2. Z przykładowymi URL-ami")
    print("3. Bez URL-i")
    print("4. Minimalny (tylko wymagane pola)")
    
    import webbrowser
    import os
    webbrowser.open(f"file://{os.path.abspath('test_with_urls.html')}")

if __name__ == "__main__":
    test_with_urls()