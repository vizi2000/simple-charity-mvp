#!/usr/bin/env python3
"""
Debug validation error - test różnych wariantów
"""

import os
import hmac
import hashlib
import base64
from datetime import datetime, timedelta
import webbrowser
import urllib.parse

# Konfiguracja
STORE_ID = "760995999"
SHARED_SECRET = "j}2W3P)Lwv"
GATEWAY_URL = "https://test.ipg-online.com/connect/gateway/processing"

def generate_hash(secret, values_string):
    """Generuj hash dla danego secretu"""
    hash_bytes = hmac.new(
        secret.encode('utf-8'),
        values_string.encode('utf-8'),
        hashlib.sha256
    ).digest()
    return base64.b64encode(hash_bytes).decode('utf-8')

def test_validation_debug():
    """Test różnych wariantów aby zdebugować validation error"""
    
    # Timestamp - różne formaty
    now = datetime.utcnow()
    timestamps = {
        "Standard": (now + timedelta(seconds=30)).strftime("%Y:%m:%d-%H:%M:%S"),
        "Now": now.strftime("%Y:%m:%d-%H:%M:%S"),
        "Future5min": (now + timedelta(minutes=5)).strftime("%Y:%m:%d-%H:%M:%S"),
        "NoSeconds": now.strftime("%Y:%m:%d-%H:%M:00")
    }
    
    print("="*60)
    print("DEBUG VALIDATION ERROR")
    print("="*60)
    
    # Generuj HTML z debugiem
    html = f"""<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Debug Validation Error</title>
    <style>
        body {{ font-family: Arial, sans-serif; max-width: 1200px; margin: 0 auto; padding: 20px; }}
        .test-form {{ 
            background: #f8f9fa; 
            padding: 20px; 
            margin: 20px 0; 
            border-radius: 5px;
            border: 2px solid #dee2e6;
        }}
        .debug-info {{
            background: #e9ecef;
            padding: 15px;
            margin: 10px 0;
            font-family: monospace;
            font-size: 12px;
            overflow-x: auto;
        }}
        button {{ 
            background: #dc3545; 
            color: white; 
            border: none; 
            padding: 12px 24px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            font-weight: bold;
        }}
        button:hover {{ background: #c82333; }}
        .field-list {{
            background: #fff3cd;
            padding: 10px;
            margin: 10px 0;
        }}
    </style>
</head>
<body>
    <h1>🔍 Debug Validation Error</h1>
    
    <div style="background: #f8d7da; padding: 15px; border-radius: 5px; margin-bottom: 20px;">
        <strong>Problem:</strong> Otrzymujemy <code>validationError</code> zamiast strony płatności<br>
        <strong>Cel:</strong> Znaleźć dokładną przyczynę odrzucenia formularza
    </div>
"""
    
    # Test 1: Różne kolejności pól w hashu
    html += """
    <h2>Test 1: Kolejność pól w hashu</h2>
    <p>Dokumentacja mówi o sortowaniu alfabetycznym, ale może być inaczej...</p>
"""
    
    base_fields = {
        'storename': STORE_ID,
        'txntype': 'sale',
        'timezone': 'Europe/Berlin',
        'txndatetime': timestamps["Standard"],
        'chargetotal': '10.00',
        'currency': '985',
        'checkoutoption': 'combinedpage',
        'oid': f'DEBUG-{datetime.now().strftime("%Y%m%d%H%M%S")}'
    }
    
    # Wariant 1: Alfabetycznie (standard)
    sorted_alpha = sorted(base_fields.items())
    hash_string_alpha = '|'.join(str(v) for k, v in sorted_alpha)
    hash_alpha = generate_hash(SHARED_SECRET, hash_string_alpha)
    
    # Wariant 2: Kolejność jak w dokumentacji
    doc_order = ['chargetotal', 'checkoutoption', 'currency', 'oid', 'storename', 'timezone', 'txndatetime', 'txntype']
    hash_string_doc = '|'.join(str(base_fields[k]) for k in doc_order)
    hash_doc = generate_hash(SHARED_SECRET, hash_string_doc)
    
    # Wariant 3: Tylko niektóre pola
    minimal_fields = ['storename', 'txntype', 'chargetotal', 'currency']
    hash_string_minimal = '|'.join(str(base_fields[k]) for k in minimal_fields if k in base_fields)
    hash_minimal = generate_hash(SHARED_SECRET, hash_string_minimal)
    
    # Formularz 1: Standard alfabetyczny
    form_fields = base_fields.copy()
    form_fields['hash_algorithm'] = 'HMACSHA256'
    form_fields['hashExtended'] = hash_alpha
    
    html += f"""
    <div class="test-form">
        <h3>Wariant 1: Sortowanie alfabetyczne (standard)</h3>
        <div class="debug-info">
            Hash string: {hash_string_alpha}<br>
            Hash: {hash_alpha}
        </div>
        <div class="field-list">
            <strong>Pola w formularzu:</strong><br>
"""
    for k, v in sorted(form_fields.items()):
        html += f"            {k} = {v}<br>\n"
    
    html += f"""        </div>
        <form method="POST" action="{GATEWAY_URL}" target="_blank">
"""
    for k, v in form_fields.items():
        html += f'            <input type="hidden" name="{k}" value="{v}">\n'
    
    html += """            <button type="submit">Test: Alfabetycznie</button>
        </form>
    </div>
"""
    
    # Test 2: Różne pola hash
    html += """
    <h2>Test 2: Pole hash vs hashExtended</h2>
"""
    
    # Z polem 'hash' zamiast 'hashExtended'
    form_fields2 = base_fields.copy()
    form_fields2['hash_algorithm'] = 'HMACSHA256'
    form_fields2['hash'] = hash_alpha  # użyj 'hash' zamiast 'hashExtended'
    
    html += f"""
    <div class="test-form">
        <h3>Wariant 2: Pole 'hash' (nie Extended)</h3>
        <div class="debug-info">
            Używa pola 'hash' zamiast 'hashExtended'<br>
            Hash: {hash_alpha}
        </div>
        <form method="POST" action="{GATEWAY_URL}" target="_blank">
"""
    for k, v in form_fields2.items():
        html += f'            <input type="hidden" name="{k}" value="{v}">\n'
    
    html += """            <button type="submit">Test: Pole 'hash'</button>
        </form>
    </div>
"""
    
    # Test 3: Bez hash_algorithm
    form_fields3 = base_fields.copy()
    form_fields3['hashExtended'] = hash_alpha
    # NIE dodawaj hash_algorithm
    
    html += f"""
    <div class="test-form">
        <h3>Wariant 3: Bez pola hash_algorithm</h3>
        <div class="debug-info">
            Może hash_algorithm jest dodawany automatycznie?<br>
            Hash: {hash_alpha}
        </div>
        <form method="POST" action="{GATEWAY_URL}" target="_blank">
"""
    for k, v in form_fields3.items():
        html += f'            <input type="hidden" name="{k}" value="{v}">\n'
    
    html += """            <button type="submit">Test: Bez hash_algorithm</button>
        </form>
    </div>
"""
    
    # Test 4: SHA1 zamiast SHA256
    hash_sha1 = base64.b64encode(
        hmac.new(
            SHARED_SECRET.encode('utf-8'),
            hash_string_alpha.encode('utf-8'),
            hashlib.sha1
        ).digest()
    ).decode('utf-8')
    
    form_fields4 = base_fields.copy()
    form_fields4['hash_algorithm'] = 'HMACSHA1'
    form_fields4['hashExtended'] = hash_sha1
    
    html += f"""
    <div class="test-form">
        <h3>Wariant 4: SHA1 zamiast SHA256</h3>
        <div class="debug-info">
            Może konto używa SHA1?<br>
            Hash: {hash_sha1}
        </div>
        <form method="POST" action="{GATEWAY_URL}" target="_blank">
"""
    for k, v in form_fields4.items():
        html += f'            <input type="hidden" name="{k}" value="{v}">\n'
    
    html += """            <button type="submit">Test: SHA1</button>
        </form>
    </div>
"""
    
    # Test 5: Różne timestampy
    html += """
    <h2>Test 3: Różne formaty timestamp</h2>
"""
    
    for ts_name, ts_value in timestamps.items():
        temp_fields = base_fields.copy()
        temp_fields['txndatetime'] = ts_value
        
        sorted_temp = sorted(temp_fields.items())
        hash_string_temp = '|'.join(str(v) for k, v in sorted_temp)
        hash_temp = generate_hash(SHARED_SECRET, hash_string_temp)
        
        form_fields_ts = temp_fields.copy()
        form_fields_ts['hash_algorithm'] = 'HMACSHA256'
        form_fields_ts['hashExtended'] = hash_temp
        
        html += f"""
    <div class="test-form">
        <h3>Timestamp: {ts_name}</h3>
        <div class="debug-info">
            txndatetime: {ts_value}<br>
            Hash: {hash_temp[:40]}...
        </div>
        <form method="POST" action="{GATEWAY_URL}" target="_blank">
"""
        for k, v in form_fields_ts.items():
            html += f'            <input type="hidden" name="{k}" value="{v}">\n'
        
        html += f"""            <button type="submit">Test: {ts_name}</button>
        </form>
    </div>
"""
    
    # Sekcja z czystym hashem
    html += f"""
    <h2>🔐 Informacje do debugowania</h2>
    <div class="debug-info">
        <strong>Store ID:</strong> {STORE_ID}<br>
        <strong>Shared Secret:</strong> {SHARED_SECRET}<br>
        <strong>Gateway URL:</strong> {GATEWAY_URL}<br><br>
        
        <strong>Przykładowy hash string (alfabetycznie):</strong><br>
        {hash_string_alpha}<br><br>
        
        <strong>Wynikowy hash (SHA256 + Base64):</strong><br>
        {hash_alpha}<br><br>
        
        <strong>URL błędu zawiera:</strong><br>
        - validationError = błąd walidacji formularza<br>
        - jsessionid = sesja została utworzona<br>
        - k = zakodowany adres IP serwera
    </div>
"""
    
    html += """
    <div style="margin-top: 30px; padding: 15px; background: #d1ecf1; border-radius: 5px;">
        <strong>💡 Co sprawdzić:</strong><br>
        1. Czy któryś wariant przechodzi dalej niż validationError?<br>
        2. Czy zmienia się komunikat błędu?<br>
        3. Czy URL przekierowania jest inny?<br><br>
        
        <strong>🎯 Najbardziej prawdopodobne przyczyny:</strong><br>
        - Nieprawidłowy Shared Secret<br>
        - Błędna kolejność pól w hashu<br>
        - Nieprawidłowy algorytm (SHA1 vs SHA256)<br>
        - Problem z polem hash vs hashExtended
    </div>
</body>
</html>"""
    
    filename = "test_debug_validation.html"
    with open(filename, 'w', encoding='utf-8') as f:
        f.write(html)
    
    print(f"✅ Test zapisany jako: {filename}")
    print("\nURL błędu wskazuje na 'validationError' - formularz jest odrzucany!")
    print("Sprawdź każdy wariant i zobacz czy coś się zmienia.")
    
    return filename

if __name__ == "__main__":
    filename = test_validation_debug()
    webbrowser.open(f"file://{os.path.abspath(filename)}")