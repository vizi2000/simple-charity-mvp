#!/usr/bin/env python3
"""
Test HMAC-SHA256 hash generation for Fiserv
"""

import hashlib
import hmac
from datetime import datetime
from zoneinfo import ZoneInfo

def generate_hmac_sha256(storename, txndatetime, chargetotal, currency, shared_secret):
    """
    Generate HMAC-SHA256 hash correctly:
    1. Data string: storename + txndatetime + chargetotal + currency (NO sharedSecret!)
    2. Use sharedSecret as HMAC key
    """
    # Create the data to sign (WITHOUT sharedSecret!)
    data_to_sign = f"{storename}{txndatetime}{chargetotal}{currency}"
    
    print(f"Data to sign: {data_to_sign}")
    print(f"HMAC key (shared secret): {shared_secret}")
    
    # Use HMAC-SHA256 with sharedSecret as the key
    hash_obj = hmac.new(
        shared_secret.encode('utf-8'),  # Key
        data_to_sign.encode('utf-8'),   # Data
        hashlib.sha256
    )
    
    # Get hex digest
    hash_value = hash_obj.hexdigest()
    
    print(f"Generated HMAC-SHA256 hash: {hash_value}")
    
    return hash_value

def main():
    # Configuration
    shared_secret = 'j}2W3P)Lwv'
    store_id = '760995999'
    
    # Get current Warsaw time
    warsaw_tz = ZoneInfo('Europe/Warsaw')
    now = datetime.now(warsaw_tz)
    txn_datetime = now.strftime('%Y:%m:%d-%H:%M:%S')
    
    # Test data
    amount = '10.00'
    currency = '985'
    
    print("=" * 60)
    print("HMAC-SHA256 Hash Generation Test")
    print("=" * 60)
    print(f"Store ID: {store_id}")
    print(f"Transaction DateTime: {txn_datetime}")
    print(f"Amount: {amount}")
    print(f"Currency: {currency}")
    print(f"Shared Secret: {shared_secret}")
    print("=" * 60)
    
    # Generate hash
    hash_value = generate_hmac_sha256(
        storename=store_id,
        txndatetime=txn_datetime,
        chargetotal=amount,
        currency=currency,
        shared_secret=shared_secret
    )
    
    # Create test HTML form
    order_id = f"TEST-{now.strftime('%Y%m%d%H%M%S')}"
    
    html = f'''<!DOCTYPE html>
<html>
<head>
    <title>HMAC-SHA256 Test Form</title>
    <meta charset="UTF-8">
</head>
<body>
    <h1>Fiserv Payment Test - HMAC-SHA256</h1>
    <form method="POST" action="https://test.ipg-online.com/connect/gateway/processing">
        <input type="hidden" name="txntype" value="sale"/>
        <input type="hidden" name="timezone" value="Europe/Warsaw"/>
        <input type="hidden" name="txndatetime" value="{txn_datetime}"/>
        <input type="hidden" name="hash_algorithm" value="HMACSHA256"/>
        <input type="hidden" name="hash" value="{hash_value}"/>
        <input type="hidden" name="storename" value="{store_id}"/>
        <input type="hidden" name="chargetotal" value="{amount}"/>
        <input type="hidden" name="currency" value="{currency}"/>
        <input type="hidden" name="oid" value="{order_id}"/>
        <input type="hidden" name="responseSuccessURL" value="https://borgtools.ddns.net/bramkamvp/payment/success"/>
        <input type="hidden" name="responseFailURL" value="https://borgtools.ddns.net/bramkamvp/payment/failure"/>
        <input type="hidden" name="transactionNotificationURL" value="https://borgtools.ddns.net/bramkamvp/api/payments/webhooks/fiserv/s2s"/>
        
        <h2>Payment Details:</h2>
        <ul>
            <li>Order ID: {order_id}</li>
            <li>Amount: {amount} PLN</li>
            <li>DateTime: {txn_datetime}</li>
        </ul>
        
        <button type="submit" style="padding: 10px 20px; font-size: 16px; background: #4CAF50; color: white; border: none; cursor: pointer;">
            Test Payment with HMAC-SHA256
        </button>
    </form>
    
    <hr>
    <h3>Generated Hash Details:</h3>
    <pre>
Data String (for signing): {store_id}{txn_datetime}{amount}{currency}
HMAC Key: {shared_secret}
Algorithm: HMAC-SHA256
Hash: {hash_value}
    </pre>
</body>
</html>'''
    
    with open('test_hmac_form.html', 'w') as f:
        f.write(html)
    
    print(f"\nTest form saved to: test_hmac_form.html")
    print("Open this file in a browser to test the payment.")

if __name__ == "__main__":
    main()