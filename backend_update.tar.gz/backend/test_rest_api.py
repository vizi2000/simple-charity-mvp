#!/usr/bin/env python3
"""
Test Fiserv REST API - zupełnie inna integracja!
"""

import requests
import json
import base64
from datetime import datetime
import uuid

# Klucze do REST API
API_KEY = "xWdewnCcYTy8G0s4oS1r5GAOmcdVRYQn"
API_SECRET = "aGOkU61VoIl5AWApLL7avcCpIVZxVGG6jYGVQib8xuG"

# Endpoint REST API (inny niż Connect!)
BASE_URL = "https://test.ipg-online.com/api/v1"

def test_rest_api():
    """Test podstawowego połączenia z REST API"""
    
    print("="*60)
    print("TEST FISERV REST API")
    print("="*60)
    
    # Basic Auth
    credentials = f"{API_KEY}:{API_SECRET}"
    encoded_credentials = base64.b64encode(credentials.encode()).decode()
    
    headers = {
        "Authorization": f"Basic {encoded_credentials}",
        "Content-Type": "application/json",
        "Accept": "application/json"
    }
    
    # Test 1: Sprawdź połączenie
    print("\n1. Test połączenia...")
    try:
        # Próba utworzenia payment session
        payment_data = {
            "amount": {
                "total": "10.00",
                "currency": "PLN"
            },
            "transactionType": "SALE",
            "paymentMethod": {
                "type": "PAYMENT_CARD"
            },
            "merchantTransactionId": f"REST-TEST-{datetime.now().strftime('%Y%m%d%H%M%S')}"
        }
        
        response = requests.post(
            f"{BASE_URL}/payments",
            headers=headers,
            json=payment_data,
            timeout=10
        )
        
        print(f"Status Code: {response.status_code}")
        print(f"Response: {response.text[:500]}")
        
        if response.status_code in [200, 201]:
            print("\n✅ REST API DZIAŁA!")
            data = response.json()
            
            # Jeśli działa, możemy przejść na REST API
            if 'paymentUrl' in data:
                print(f"Payment URL: {data['paymentUrl']}")
            if 'sessionId' in data:
                print(f"Session ID: {data['sessionId']}")
                
            return True
        else:
            print("\n❌ REST API zwraca błąd")
            
    except Exception as e:
        print(f"\n❌ Błąd połączenia: {e}")
        
    # Test 2: Inne endpointy
    print("\n2. Test innych endpointów...")
    test_endpoints = [
        "/payment-methods",
        "/currencies",
        "/stores"
    ]
    
    for endpoint in test_endpoints:
        try:
            print(f"\nEndpoint: {endpoint}")
            response = requests.get(
                f"{BASE_URL}{endpoint}",
                headers=headers,
                timeout=5
            )
            print(f"Status: {response.status_code}")
            if response.status_code == 200:
                print(f"Response: {response.text[:200]}...")
        except Exception as e:
            print(f"Error: {e}")
    
    return False

def create_rest_payment():
    """Utwórz płatność przez REST API"""
    
    print("\n" + "="*60)
    print("TWORZENIE PŁATNOŚCI PRZEZ REST API")
    print("="*60)
    
    credentials = f"{API_KEY}:{API_SECRET}"
    encoded_credentials = base64.b64encode(credentials.encode()).decode()
    
    headers = {
        "Authorization": f"Basic {encoded_credentials}",
        "Content-Type": "application/json",
        "Accept": "application/json"
    }
    
    # Dane płatności
    payment_request = {
        "amount": {
            "total": "50.00",
            "currency": "PLN"
        },
        "transactionType": "SALE",
        "paymentMethod": {
            "type": "PAYMENT_CARD",
            "card": {
                "number": "4005550000000019",
                "expiryDate": {
                    "month": "12",
                    "year": "25"
                },
                "securityCode": "111"
            }
        },
        "merchantTransactionId": str(uuid.uuid4()),
        "customer": {
            "email": "test@example.com",
            "name": "Test User"
        }
    }
    
    try:
        response = requests.post(
            f"{BASE_URL}/payments",
            headers=headers,
            json=payment_request,
            timeout=15
        )
        
        print(f"\nStatus Code: {response.status_code}")
        print(f"Headers: {dict(response.headers)}")
        print(f"\nResponse Body:")
        print(json.dumps(response.json(), indent=2) if response.status_code == 200 else response.text)
        
        if response.status_code in [200, 201]:
            print("\n✅ Płatność utworzona przez REST API!")
            return response.json()
            
    except Exception as e:
        print(f"\n❌ Błąd: {e}")
        
    return None

if __name__ == "__main__":
    # Test podstawowy
    api_works = test_rest_api()
    
    if api_works:
        print("\n" + "="*60)
        print("REST API DZIAŁA! Możemy przejść na tę integrację.")
        print("="*60)
        
        # Spróbuj utworzyć płatność
        create_rest_payment()
    else:
        print("\n" + "="*60)
        print("REST API nie działa z tymi kluczami.")
        print("Prawdopodobnie potrzebujemy prawidłowych danych do IPG Connect.")
        print("="*60)