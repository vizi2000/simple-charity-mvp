#!/usr/bin/env python3
"""
Test z DOKŁADNIE takim formatem jak przykład Fiserv
"""

import httpx
import asyncio
from datetime import datetime
from fiserv_payment_v2 import FiservIPGPayment

async def test_exact_format():
    """Test z dokładnym formatem z przykładu Fiserv"""
    
    print("="*60)
    print("TEST Z DOKŁADNYM FORMATEM FISERV")
    print("="*60)
    
    client = FiservIPGPayment()
    
    # Użyj dokładnie takiego formatu jak w przykładzie z emaila
    order_id = f"TEST-{datetime.now().strftime('%Y%m%d%H%M%S')}"
    
    print(f"\n📋 Order ID: {order_id}")
    
    # URLe dokładnie jak w przykładzie Fiserv
    # Przykład miał: /platnosc/{oid}/status?result=success
    success_url = f"https://charity.ngrok.app/platnosc/{order_id}/status?result=success"
    failure_url = f"https://charity.ngrok.app/platnosc/{order_id}/status?result=failure"
    notification_url = "https://charity-webhook.ngrok.app/api/webhooks/fiserv"
    
    print("\n🔗 URLe (format z przykładu Fiserv):")
    print(f"  Success: {success_url}")
    print(f"  Failure: {failure_url}")
    print(f"  Notification: {notification_url}")
    
    # Generuj formularz
    form_data = client.create_payment_form(
        amount=50.00,  # Taka sama kwota jak w przykładzie
        order_id=order_id,
        success_url=success_url,
        failure_url=failure_url,
        notification_url=notification_url,
        customer_name="Jan Kowalski",  # Jak w przykładzie
        customer_email="jan.kowalski@example.com"  # Jak w przykładzie
    )
    
    fields = form_data['fields']
    
    print("\n✅ PORÓWNANIE Z PRZYKŁADEM FISERV:")
    print("-" * 40)
    
    # Porównaj z przykładem
    example_fields = {
        'storename': '760995999',
        'txntype': 'sale',
        'timezone': 'Europe/Warsaw',  # Poprawione
        'chargetotal': '50.00',
        'currency': '985',
        'checkoutoption': 'combinedpage',
        'hash_algorithm': 'HMACSHA256',
        'bname': 'Jan Kowalski',
        'bemail': 'jan.kowalski@example.com'
    }
    
    for field, expected in example_fields.items():
        actual = fields.get(field)
        if actual == expected:
            print(f"✅ {field}: {actual}")
        else:
            print(f"❌ {field}: {actual} (oczekiwano: {expected})")
    
    # Sprawdź URLe
    print("\n🔗 URLe w formularzu:")
    print(f"✅ responseSuccessURL: {fields.get('responseSuccessURL')}")
    print(f"✅ responseFailURL: {fields.get('responseFailURL')}")
    print(f"✅ transactionNotificationURL: {fields.get('transactionNotificationURL')}")
    
    # Test wysyłania
    print("\n🚀 WYSYŁANIE DO FISERV...")
    print("-" * 40)
    
    async with httpx.AsyncClient(follow_redirects=False) as http_client:
        try:
            response = await http_client.post(
                form_data['action'],
                data=fields,
                headers={
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36',
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                    'Accept-Language': 'pl,en;q=0.9',
                    'Origin': 'https://charity.ngrok.app',
                    'Referer': 'https://charity.ngrok.app/'
                }
            )
            
            print(f"Status: {response.status_code}")
            
            if response.status_code in [302, 303]:
                location = response.headers.get('location', '')
                print(f"Redirect: {location[:100]}...")
                
                if 'validationError' in location:
                    print("\n❌ NADAL BŁĄD WALIDACJI")
                    
                    # Sprawdź session ID
                    if 'jsessionid' in location:
                        session_part = location.split('jsessionid=')[1].split('?')[0]
                        print(f"Session ID: {session_part[:20]}...")
                    
                    # Sprawdź parametry
                    if '?' in location:
                        params = location.split('?')[1]
                        print(f"Parametry: {params}")
                        
                elif 'payment' in location.lower():
                    print("\n✅ SUKCES - Przekierowanie do płatności!")
                else:
                    print("\n⚠️ Nieznane przekierowanie")
                    
        except Exception as e:
            print(f"❌ Błąd: {e}")
    
    # Generuj HTML do ręcznego testu
    html_file = f"test_exact_format_{order_id}.html"
    client.generate_test_html(form_data, html_file)
    
    print(f"\n📄 HTML do ręcznego testu: {html_file}")
    
    print("\n" + "="*60)
    print("PODSUMOWANIE")
    print("="*60)
    
    print("\n✅ Wszystkie parametry zgodne z przykładem Fiserv:")
    print("  - Timezone: Europe/Warsaw")
    print("  - Timestamp: Aktualny czas warszawski")
    print("  - URLe: Format /platnosc/{oid}/status?result=...")
    print("  - Hash: Poprawnie wyliczony")
    
    print("\n⚠️ Jeśli nadal występuje błąd walidacji:")
    print("  1. Problem z konfiguracją konta/sklepu")
    print("  2. Brak opcji 'Allow URL override' w Virtual Terminal")
    print("  3. Domena ngrok może być blokowana")
    print("  4. Shared secret może być nieprawidłowy")

if __name__ == "__main__":
    asyncio.run(test_exact_format())