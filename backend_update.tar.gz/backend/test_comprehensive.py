#!/usr/bin/env python3
"""
Comprehensive test suite for Fiserv IPG payment integration
"""

import asyncio
import json
import httpx
from datetime import datetime
import hmac
import hashlib
import base64
from typing import Dict, Any

# Test configuration
BASE_URL = "http://localhost:8001"
HEADERS = {"Content-Type": "application/json"}

# Test data
TEST_PAYMENTS = [
    {
        "name": "Card Payment Test",
        "data": {
            "goal_id": "church",
            "amount": 100.50,
            "donor_name": "Jan Kowalski",
            "donor_email": "jan.kowalski@example.com",
            "payment_method": "card",
            "message": "Test card payment"
        }
    },
    {
        "name": "BLIK Payment Test",
        "data": {
            "goal_id": "poor",
            "amount": 50.00,
            "donor_name": "Anna Nowak",
            "donor_email": "anna.nowak@example.com",
            "payment_method": "blik",
            "message": "Test BLIK payment"
        }
    },
    {
        "name": "Anonymous Payment Test",
        "data": {
            "goal_id": "homeless",
            "amount": 200.00,
            "payment_method": "card"
        }
    }
]

class PaymentTester:
    def __init__(self):
        self.client = httpx.AsyncClient(base_url=BASE_URL)
        self.test_results = []
        
    async def close(self):
        await self.client.aclose()
        
    def log_result(self, test_name: str, success: bool, details: str = ""):
        result = {
            "test": test_name,
            "success": success,
            "details": details,
            "timestamp": datetime.utcnow().isoformat()
        }
        self.test_results.append(result)
        
        # Print result
        status = "✅ PASS" if success else "❌ FAIL"
        print(f"{status} - {test_name}")
        if details:
            print(f"    Details: {details}")
            
    async def test_health_check(self):
        """Test if API is running"""
        try:
            response = await self.client.get("/health")
            self.log_result("Health Check", response.status_code == 200, f"Status: {response.status_code}")
        except Exception as e:
            self.log_result("Health Check", False, str(e))
            
    async def test_payment_initiation(self, payment_data: Dict[str, Any]) -> Dict[str, Any]:
        """Test payment initiation"""
        test_name = payment_data["name"]
        
        try:
            response = await self.client.post(
                "/api/payments/initiate",
                json=payment_data["data"],
                headers=HEADERS
            )
            
            if response.status_code == 200:
                result = response.json()
                self.log_result(
                    f"Payment Initiation - {test_name}",
                    True,
                    f"Payment ID: {result.get('payment_id')}"
                )
                return result
            else:
                self.log_result(
                    f"Payment Initiation - {test_name}",
                    False,
                    f"Status: {response.status_code}, Response: {response.text}"
                )
                return {}
                
        except Exception as e:
            self.log_result(f"Payment Initiation - {test_name}", False, str(e))
            return {}
            
    async def test_form_data_generation(self, payment_id: str):
        """Test form data generation and hash validation"""
        try:
            response = await self.client.get(f"/api/payments/{payment_id}/form-data")
            
            if response.status_code == 200:
                form_data = response.json()
                
                # Validate required fields
                required_fields = ["form_action", "form_fields"]
                has_required = all(field in form_data for field in required_fields)
                
                if has_required:
                    fields = form_data["form_fields"]
                    
                    # Check essential form fields
                    essential_fields = [
                        "storename", "txntype", "txndatetime", "chargetotal",
                        "currency", "oid", "hash", "hash_algorithm"
                    ]
                    
                    missing_fields = [f for f in essential_fields if f not in fields]
                    
                    if not missing_fields:
                        # Validate hash format
                        hash_valid = len(fields.get("hash", "")) > 20
                        
                        self.log_result(
                            f"Form Data Generation - {payment_id}",
                            hash_valid,
                            f"Hash: {fields.get('hash', '')[:20]}..., Store: {fields.get('storename')}"
                        )
                        return form_data
                    else:
                        self.log_result(
                            f"Form Data Generation - {payment_id}",
                            False,
                            f"Missing fields: {missing_fields}"
                        )
                else:
                    self.log_result(
                        f"Form Data Generation - {payment_id}",
                        False,
                        "Missing form_action or form_fields"
                    )
            else:
                self.log_result(
                    f"Form Data Generation - {payment_id}",
                    False,
                    f"Status: {response.status_code}"
                )
                
        except Exception as e:
            self.log_result(f"Form Data Generation - {payment_id}", False, str(e))
            
        return {}
        
    async def test_payment_status(self, payment_id: str):
        """Test payment status endpoint"""
        try:
            response = await self.client.get(f"/api/payments/{payment_id}/status")
            
            if response.status_code == 200:
                status_data = response.json()
                
                # Check required fields
                required_fields = ["payment_id", "status", "amount"]
                has_required = all(field in status_data for field in required_fields)
                
                self.log_result(
                    f"Payment Status Check - {payment_id}",
                    has_required,
                    f"Status: {status_data.get('status')}, Amount: {status_data.get('amount')}"
                )
                return status_data
            else:
                self.log_result(
                    f"Payment Status Check - {payment_id}",
                    False,
                    f"Status: {response.status_code}"
                )
                
        except Exception as e:
            self.log_result(f"Payment Status Check - {payment_id}", False, str(e))
            
        return {}
        
    async def test_webhook_signature(self):
        """Test webhook signature verification"""
        # Simulate webhook payload
        webhook_data = {
            "transactionId": "TEST-TXN-001",
            "orderId": "TEST-ORDER-001",
            "transactionStatus": "APPROVED",
            "amount": 100.00,
            "currency": "PLN",
            "timestamp": datetime.utcnow().isoformat()
        }
        
        # Create signature (simplified for testing)
        timestamp = str(int(datetime.utcnow().timestamp()))
        payload = json.dumps(webhook_data, separators=(",", ":"))
        
        try:
            response = await self.client.post(
                "/api/webhooks/fiserv",
                content=payload,
                headers={
                    "Content-Type": "application/json",
                    "Timestamp": timestamp
                }
            )
            
            # We expect 401 without proper signature, but 200 means endpoint exists
            endpoint_exists = response.status_code in [200, 401]
            
            self.log_result(
                "Webhook Endpoint Test",
                endpoint_exists,
                f"Status: {response.status_code}"
            )
            
        except Exception as e:
            self.log_result("Webhook Endpoint Test", False, str(e))
            
    async def test_mock_payment_processing(self, payment_id: str):
        """Test mock payment processing"""
        try:
            response = await self.client.post(
                f"/api/payments/{payment_id}/process-mock",
                json={"payment_method": "card"},
                headers=HEADERS
            )
            
            if response.status_code == 200:
                result = response.json()
                self.log_result(
                    f"Mock Payment Processing - {payment_id}",
                    result.get("status") == "success",
                    f"Payment method: {result.get('payment_method')}"
                )
            else:
                self.log_result(
                    f"Mock Payment Processing - {payment_id}",
                    False,
                    f"Status: {response.status_code}"
                )
                
        except Exception as e:
            self.log_result(f"Mock Payment Processing - {payment_id}", False, str(e))
            
    async def test_hash_calculation(self):
        """Test hash calculation for IPG Connect"""
        from app.utils.fiserv_ipg_client import fiserv_ipg_client
        
        try:
            # Test parameters
            test_params = {
                'storename': '760995999',
                'txndatetime': '2025:07:28-19:00:00',
                'chargetotal': '100.00',
                'currency': '985'
            }
            
            # Generate hash
            hash_value = fiserv_ipg_client._generate_hash(test_params)
            
            # Validate hash format (base64 encoded)
            is_valid = len(hash_value) > 20 and all(
                c in 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=' 
                for c in hash_value
            )
            
            self.log_result(
                "Hash Calculation Test",
                is_valid,
                f"Hash: {hash_value[:20]}..."
            )
            
        except Exception as e:
            self.log_result("Hash Calculation Test", False, str(e))
            
    async def test_error_scenarios(self):
        """Test various error scenarios"""
        # Test invalid goal ID
        try:
            response = await self.client.post(
                "/api/payments/initiate",
                json={
                    "goal_id": "invalid_goal",
                    "amount": 50,
                    "payment_method": "card"
                },
                headers=HEADERS
            )
            
            self.log_result(
                "Error Handling - Invalid Goal",
                response.status_code == 404,
                f"Status: {response.status_code}"
            )
            
        except Exception as e:
            self.log_result("Error Handling - Invalid Goal", False, str(e))
            
        # Test invalid payment amount
        try:
            response = await self.client.post(
                "/api/payments/initiate",
                json={
                    "goal_id": "church",
                    "amount": -50,  # Negative amount
                    "payment_method": "card"
                },
                headers=HEADERS
            )
            
            self.log_result(
                "Error Handling - Invalid Amount",
                response.status_code == 422,
                f"Status: {response.status_code}"
            )
            
        except Exception as e:
            self.log_result("Error Handling - Invalid Amount", False, str(e))
            
        # Test non-existent payment status
        try:
            response = await self.client.get("/api/payments/non-existent-id/status")
            
            self.log_result(
                "Error Handling - Non-existent Payment",
                response.status_code == 404,
                f"Status: {response.status_code}"
            )
            
        except Exception as e:
            self.log_result("Error Handling - Non-existent Payment", False, str(e))
            
    async def run_all_tests(self):
        """Run all tests"""
        print("\n" + "="*60)
        print("FISERV PAYMENT INTEGRATION - COMPREHENSIVE TEST SUITE")
        print("="*60 + "\n")
        
        # 1. Health check
        await self.test_health_check()
        
        # 2. Test payment initiation for different methods
        payment_ids = []
        for payment_test in TEST_PAYMENTS:
            result = await self.test_payment_initiation(payment_test)
            if result.get("payment_id"):
                payment_ids.append(result["payment_id"])
                
        # 3. Test form data generation
        for payment_id in payment_ids[:2]:  # Test first two
            await self.test_form_data_generation(payment_id)
            
        # 4. Test payment status
        for payment_id in payment_ids[:2]:
            await self.test_payment_status(payment_id)
            
        # 5. Test webhook endpoint
        await self.test_webhook_signature()
        
        # 6. Test mock payment processing
        if payment_ids:
            await self.test_mock_payment_processing(payment_ids[0])
            
        # 7. Test hash calculation
        await self.test_hash_calculation()
        
        # 8. Test error scenarios
        await self.test_error_scenarios()
        
        # Summary
        print("\n" + "="*60)
        print("TEST SUMMARY")
        print("="*60)
        
        total_tests = len(self.test_results)
        passed_tests = sum(1 for r in self.test_results if r["success"])
        failed_tests = total_tests - passed_tests
        
        print(f"\nTotal Tests: {total_tests}")
        print(f"✅ Passed: {passed_tests}")
        print(f"❌ Failed: {failed_tests}")
        print(f"Success Rate: {(passed_tests/total_tests*100):.1f}%\n")
        
        # Show failed tests
        if failed_tests > 0:
            print("Failed Tests:")
            for result in self.test_results:
                if not result["success"]:
                    print(f"  - {result['test']}: {result['details']}")
                    
        # Save detailed results
        with open("test_results.json", "w") as f:
            json.dump(self.test_results, f, indent=2, default=str)
            print(f"\nDetailed results saved to test_results.json")


async def main():
    tester = PaymentTester()
    try:
        await tester.run_all_tests()
    finally:
        await tester.close()


if __name__ == "__main__":
    asyncio.run(main())