#!/usr/bin/env python3
"""Test hash calculation for Fiserv IPG"""

import hmac
import hashlib
import base64
from datetime import datetime

# Test credentials
store_id = "760995999"
shared_secret = "j}2W3P)Lwv"

# Test transaction data
txndatetime = "2025:07:28-19:30:00"
chargetotal = "100.00"
currency = "985"

# Method 1: With pipes (original)
string_with_pipes = f"{store_id}|{txndatetime}|{chargetotal}|{currency}"
hash_with_pipes = base64.b64encode(
    hmac.new(
        shared_secret.encode('utf-8'),
        string_with_pipes.encode('utf-8'),
        hashlib.sha256
    ).digest()
).decode('utf-8')

# Method 2: Without pipes
string_no_pipes = f"{store_id}{txndatetime}{chargetotal}{currency}"
hash_no_pipes = base64.b64encode(
    hmac.new(
        shared_secret.encode('utf-8'),
        string_no_pipes.encode('utf-8'),
        hashlib.sha256
    ).digest()
).decode('utf-8')

# Method 3: SHA256 (not HMAC) - some gateways use this
sha256_hash = hashlib.sha256(
    (string_no_pipes + shared_secret).encode('utf-8')
).hexdigest()

print("Hash Calculation Test Results:")
print("="*60)
print(f"Store ID: {store_id}")
print(f"Datetime: {txndatetime}")
print(f"Amount: {chargetotal}")
print(f"Currency: {currency}")
print(f"Shared Secret: {shared_secret}")
print("\nHash Results:")
print(f"1. HMAC-SHA256 with pipes: {hash_with_pipes}")
print(f"2. HMAC-SHA256 no pipes: {hash_no_pipes}")
print(f"3. SHA256 concat: {sha256_hash}")

# Test the actual form generation
from app.utils.fiserv_ipg_client import fiserv_ipg_client

form_data = fiserv_ipg_client.create_payment_form_data(
    amount=100.00,
    order_id="TEST-001",
    description="Test payment"
)

print("\nGenerated Form Data:")
print(f"Hash: {form_data['form_fields']['hash']}")
print(f"Algorithm: {form_data['form_fields']['hash_algorithm']}")

# Additional test with exact Fiserv format
# According to some Fiserv docs, the format might be different
alt_string = f"{store_id}{chargetotal}{currency}"
alt_hash = base64.b64encode(
    hmac.new(
        shared_secret.encode('utf-8'),
        alt_string.encode('utf-8'),
        hashlib.sha256
    ).digest()
).decode('utf-8')

print(f"\n4. Alternative format (store+amount+currency): {alt_hash}")