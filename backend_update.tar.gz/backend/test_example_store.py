#!/usr/bin/env python3
"""
Test z przykładowym Store ID z dokumentacji Fiserv
"""

import os
import hmac
import hashlib
import base64
from datetime import datetime, timedelta
import webbrowser

# Przykładowe dane z dokumentacji Fiserv
EXAMPLE_STORES = [
    {
        "name": "Documentation Example 1",
        "store_id": "10123456789",
        "shared_secret": "sharedsecret"
    },
    {
        "name": "Documentation Example 2", 
        "store_id": "120995000",
        "shared_secret": "Test1234"
    },
    {
        "name": "Common Test Store",
        "store_id": "3344556677",
        "shared_secret": "mysecret"
    }
]

GATEWAY_URL = "https://test.ipg-online.com/connect/gateway/processing"

def generate_hash(secret, values_string):
    """Generuj hash dla danego secretu"""
    hash_bytes = hmac.new(
        secret.encode('utf-8'),
        values_string.encode('utf-8'),
        hashlib.sha256
    ).digest()
    return base64.b64encode(hash_bytes).decode('utf-8')

def test_example_stores():
    """Test z przykładowymi Store ID z dokumentacji"""
    
    # Timestamp
    now = datetime.utcnow() + timedelta(seconds=30)
    txndatetime = now.strftime("%Y:%m:%d-%H:%M:%S")
    
    print("="*60)
    print("TEST Z PRZYKŁADOWYMI STORE ID Z DOKUMENTACJI")
    print("="*60)
    print(f"\nTimestamp: {txndatetime}\n")
    
    # Generuj HTML
    html = f"""<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Test Example Stores</title>
    <style>
        body {{ font-family: Arial, sans-serif; max-width: 1200px; margin: 0 auto; padding: 20px; }}
        .test-form {{ 
            background: #f0f8ff; 
            padding: 20px; 
            margin: 20px 0; 
            border-radius: 5px;
            border: 2px solid #4169e1;
        }}
        .our-form {{
            background: #f8f9fa;
            border: 2px solid #6c757d;
        }}
        h3 {{ margin-top: 0; color: #495057; }}
        button {{ 
            background: #4169e1; 
            color: white; 
            border: none; 
            padding: 12px 24px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            font-weight: bold;
        }}
        button:hover {{ background: #1e90ff; }}
        .store-info {{ 
            font-family: monospace; 
            background: #e9ecef; 
            padding: 10px;
            margin: 10px 0;
            border-radius: 3px;
        }}
        .warning {{
            background: #fff3cd;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            border: 1px solid #ffc107;
        }}
    </style>
</head>
<body>
    <h1>🧪 Test z Przykładowymi Store ID</h1>
    
    <div class="warning">
        <strong>⚠️ Uwaga:</strong> To są przykładowe Store ID z dokumentacji Fiserv. 
        Jeśli któryś z nich działa, oznacza to, że problem jest z konfiguracją Twojego konta.
    </div>
"""
    
    # Test każdego przykładowego store
    for i, store in enumerate(EXAMPLE_STORES, 1):
        # Podstawowe parametry
        base_params = {
            'storename': store['store_id'],
            'txntype': 'sale',
            'timezone': 'Europe/Berlin',
            'txndatetime': txndatetime,
            'chargetotal': '10.00',
            'currency': '978',  # EUR - często używane w przykładach
            'checkoutoption': 'combinedpage',
            'oid': f'EXAMPLE-TEST-{i}-{datetime.now().strftime("%Y%m%d%H%M%S")}'
        }
        
        # Sortuj i generuj hash
        sorted_params = sorted(base_params.items())
        values_to_hash = '|'.join(str(v) for k, v in sorted_params)
        hash_value = generate_hash(store['shared_secret'], values_to_hash)
        
        print(f"{i}. {store['name']}:")
        print(f"   Store ID: {store['store_id']}")
        print(f"   Shared Secret: {store['shared_secret']}")
        print(f"   Hash: {hash_value[:40]}...")
        print()
        
        params = base_params.copy()
        params['hash_algorithm'] = 'HMACSHA256'
        params['hashExtended'] = hash_value
        
        html += f"""
    <div class="test-form">
        <h3>Test {i}: {store['name']}</h3>
        <div class="store-info">
            Store ID: {store['store_id']}<br>
            Shared Secret: {store['shared_secret']}<br>
            Currency: EUR (978)<br>
            Order ID: {params['oid']}
        </div>
        <form method="POST" action="{GATEWAY_URL}" target="_blank">
"""
        for k, v in params.items():
            html += f'            <input type="hidden" name="{k}" value="{v}">\n'
        
        html += f"""            <button type="submit">🚀 Testuj Store: {store['store_id']}</button>
        </form>
    </div>
"""
    
    # Dodaj też test z naszymi danymi dla porównania
    our_store = {
        'storename': '760995999',
        'txntype': 'sale',
        'timezone': 'Europe/Berlin',
        'txndatetime': txndatetime,
        'chargetotal': '10.00',
        'currency': '985',  # PLN
        'checkoutoption': 'combinedpage',
        'oid': f'OUR-TEST-{datetime.now().strftime("%Y%m%d%H%M%S")}'
    }
    
    sorted_params = sorted(our_store.items())
    values_to_hash = '|'.join(str(v) for k, v in sorted_params)
    
    # Test z różnymi secretami
    our_secrets = [
        ("Original", "j}2W3P)Lwv"),
        ("Alternative", "c7dP/$5PBx")
    ]
    
    html += """
    <hr style="margin: 40px 0;">
    <h2>📌 Nasze Konto (dla porównania)</h2>
"""
    
    for name, secret in our_secrets:
        hash_value = generate_hash(secret, values_to_hash)
        params = our_store.copy()
        params['hash_algorithm'] = 'HMACSHA256'
        params['hashExtended'] = hash_value
        
        html += f"""
    <div class="test-form our-form">
        <h3>Nasze Konto - Secret: {name}</h3>
        <div class="store-info">
            Store ID: 760995999<br>
            Shared Secret: {secret}<br>
            Currency: PLN (985)<br>
            Order ID: {params['oid']}
        </div>
        <form method="POST" action="{GATEWAY_URL}" target="_blank">
"""
        for k, v in params.items():
            html += f'            <input type="hidden" name="{k}" value="{v}">\n'
        
        html += f"""            <button type="submit">🔄 Testuj Nasze Konto ({name})</button>
        </form>
    </div>
"""
    
    # Test minimalnych pól
    html += """
    <hr style="margin: 40px 0;">
    <h2>🔬 Test Absolutnie Minimalny</h2>
    <p>Tylko obowiązkowe pola według dokumentacji:</p>
"""
    
    minimal_params = {
        'storename': '10123456789',  # Example store
        'txntype': 'sale',
        'chargetotal': '10.00',
        'currency': '978'
    }
    
    # Hash tylko z tych pól
    sorted_minimal = sorted(minimal_params.items())
    minimal_hash_string = '|'.join(str(v) for k, v in sorted_minimal)
    minimal_hash = generate_hash('sharedsecret', minimal_hash_string)
    
    minimal_params['hash_algorithm'] = 'HMACSHA256'
    minimal_params['hashExtended'] = minimal_hash
    
    html += f"""
    <div class="test-form">
        <h3>Minimal Test - Example Store</h3>
        <div class="store-info">
            Tylko pola: storename, txntype, chargetotal, currency<br>
            Hash z: {minimal_hash_string}
        </div>
        <form method="POST" action="{GATEWAY_URL}" target="_blank">
"""
    for k, v in minimal_params.items():
        html += f'            <input type="hidden" name="{k}" value="{v}">\n'
    
    html += """            <button type="submit">🔬 Test Minimalny</button>
        </form>
    </div>
"""
    
    html += """
    <div style="margin-top: 30px; padding: 15px; background: #d1ecf1; border-radius: 5px;">
        <strong>📊 Interpretacja wyników:</strong><br>
        1. Jeśli przykładowe store działają → Problem z konfiguracją Twojego konta<br>
        2. Jeśli przykładowe store też nie działają → Problem z kodem/integracją<br>
        3. Jeśli wszystko nie działa → Możliwy problem z całym środowiskiem testowym<br><br>
        
        <strong>🎯 Najbardziej prawdopodobne Store ID z dokumentacji:</strong><br>
        - 10123456789 (najczęściej używany w przykładach)<br>
        - 120995000 (alternatywny przykład)
    </div>
</body>
</html>"""
    
    filename = "test_example_stores.html"
    with open(filename, 'w', encoding='utf-8') as f:
        f.write(html)
    
    print(f"✅ Test zapisany jako: {filename}")
    print("\n🎯 Jeśli przykładowe store działają, oznacza to że:")
    print("   - Twój Shared Secret jest nieprawidłowy")
    print("   - Lub Twoje konto nie ma aktywnego IPG Connect")
    
    return filename

if __name__ == "__main__":
    filename = test_example_stores()
    webbrowser.open(f"file://{os.path.abspath(filename)}")