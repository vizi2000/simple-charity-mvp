import webbrowser
from pathlib import Path
import os
import uuid

# Adjust import path if needed: currently assumes backend is a package root with app.utils.fiserv_connect
from app.utils.fiserv_connect import (
    build_combined_page_payload,
    finalize_payload_with_hash,
)


def main():
    # Inputs (read from env or fallback)
    storename = os.getenv("FISERV_STORE_ID", "760995999")
    shared_secret = os.getenv("FISERV_SHARED_SECRET", "j}2W3P)Lwv")  # TEST SECRET PER SUPPORT
    base_public = os.getenv("PUBLIC_BASE_URL", "https://example-ngrok-domain.ngrok-free.app")
    frontend_base = os.getenv("FRONTEND_BASE_URL", f"{base_public}")

    # Compose URLs (public https)
    oid = f"DEBUG-{uuid.uuid4()}"
    success_url = f"{frontend_base}/success"
    fail_url = f"{frontend_base}/failure"
    notify_url = f"{base_public}/api/webhooks/fiserv"

    # Build payload with correct timezone and current Warsaw time
    payload = build_combined_page_payload(
        storename=storename,
        oid=oid,
        chargetotal=os.getenv("CHARGE_TOTAL", "50.00"),
        success_url=success_url,
        fail_url=fail_url,
        notify_url=notify_url,
        currency=os.getenv("FISERV_CURRENCY", "985"),
        checkoutoption="combinedpage",
        txntype="sale",
        timezone="Europe/Warsaw",
        hash_algorithm="HMACSHA256",
        bname=os.getenv("BILL_NAME", "TEST USER"),
        bemail=os.getenv("BILL_EMAIL", "test@example.com"),
    )

    # Validate + sign
    signed = finalize_payload_with_hash(payload, shared_secret)

    # Create an HTML auto-submit form next to this script for manual test
    html_path = Path(__file__).with_suffix(".html")
    html_path.write_text(render_html_form(signed), encoding="utf-8")

    print("Prepared OID:", oid)
    print("txndatetime:", signed.get("txndatetime"))
    print("timezone:", signed.get("timezone"))
    print("responseSuccessURL:", signed.get("responseSuccessURL"))
    print("responseFailURL:", signed.get("responseFailURL"))
    print("transactionNotificationURL:", signed.get("transactionNotificationURL"))
    print("hashExtended:", signed.get("hashExtended"))

    # Open the HTML file to allow submit to Fiserv Connect gateway
    webbrowser.open(html_path.as_uri())


def render_html_form(fields: dict) -> str:
    # Endpoint for Fiserv IPG Connect Combined Page (test)
    action = os.getenv(
        "FISERV_CONNECT_ENDPOINT",
        "https://test.ipg-online.com/connect/gateway/processing",
    )
    inputs = "\n".join(
        '<input type="hidden" name="{k}" value="{v}"/>'.format(
            k=k, v=escape_html(str(v))
        )
        for k, v in fields.items()
    )
    # Build HTML string without nested f-strings to avoid quoting issues
    html = []
    html.append("<!DOCTYPE html>")
    html.append('<html lang="pl">')
    html.append("<head>")
    html.append('<meta charset="utf-8"/>')
    html.append("<title>Fiserv Combined Page Test</title>")
    html.append("<style>")
    html.append(
        "body{font-family: system-ui, -apple-system, Segoe UI, Roboto, Ubuntu, "
        "Cantarell, 'Helvetica Neue', Arial, 'Noto Sans', 'Apple Color Emoji', 'Segoe UI Emoji'; margin:2rem;}"
    )
    html.append("pre{background:#f6f8fa;border:1px solid #e1e4e8;padding:1rem;border-radius:6px;overflow:auto;}")
    html.append("button{padding:.6rem 1rem;font-size:1rem}")
    html.append("</style>")
    html.append("</head>")
    html.append("<body>")
    html.append("<h1>Fiserv Combined Page – auto-submit form</h1>")
    html.append("<p>Formularz zawiera aktualny czas Europe/Warsaw, komplet trzech URL-i i podpis hashExtended (HMACSHA256). Strona auto-wyśle formularz po załadowaniu.</p>")
    html.append('<form id="payform" method="post" action="{action}">'.format(action=action))
    html.append(inputs)
    html.append('  <button type="submit">Wyślij ręcznie</button>')
    html.append("</form>")
    html.append("<h2>Debug fields</h2>")
    html.append("<pre>{}</pre>".format(escape_html(str(fields))))
    html.append("<script>")
    html.append("  // auto-submit shortly after load to allow seeing fields if needed")
    html.append("  setTimeout(function() {")
    html.append("    document.getElementById('payform').submit();")
    html.append("  }, 500);")
    html.append("</script>")
    html.append("</body>")
    html.append("</html>")
    return "\n".join(html)


def escape_html(x: str) -> str:
    # Strict HTML escaping – correct entities (FIX)
    x = x.replace("&", "&")
    x = x.replace("<", "<")
    x = x.replace(">", ">")
    x = x.replace('"', """)
    x = x.replace("'", "&#39;")
    return x


if __name__ == "__main__":
    main()
