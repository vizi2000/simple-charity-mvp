#!/usr/bin/env python3
"""
Test z secretem z .env
"""

import os
from datetime import datetime
from dotenv import load_dotenv

# Załaduj .env
load_dotenv()

# Import klienta
import sys
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from app.utils.fiserv_ipg_client import FiservIPGClient

def test_payment():
    """Test płatności z aktualnym secretem z .env"""
    
    print("="*60)
    print("TEST Z AKTUALNYM SHARED SECRET Z .ENV")
    print("="*60)
    
    # Pokaż który secret używamy
    secret = os.getenv('FISERV_SHARED_SECRET')
    print(f"\nUżywany Shared Secret: {secret}")
    print(f"Store ID: {os.getenv('FISERV_STORE_ID')}")
    
    # Utwórz klienta
    client = FiservIPGClient()
    
    # Przygotuj dane
    order_id = f"ENV-TEST-{datetime.now().strftime('%Y%m%d%H%M%S')}"
    amount = 25.00
    
    # Generuj formularz
    form_data = client.create_payment_form_data(
        amount=amount,
        order_id=order_id,
        description="Test payment",
        success_url="https://example.com/success",
        failure_url="https://example.com/failure"
    )
    
    print(f"\nOrder ID: {order_id}")
    print(f"Amount: {amount} PLN")
    
    # Rozpakuj form_data
    action_url = form_data['form_action']
    fields = form_data['form_fields']
    
    print(f"\nForm fields:")
    for key, value in sorted(fields.items()):
        if key == 'hashExtended':
            print(f"  {key}: {value[:40]}...")
        else:
            print(f"  {key}: {value}")
    
    # Generuj HTML
    html = f"""<!DOCTYPE html>
<html>
<head>
    <title>Test with ENV Secret</title>
    <style>
        body {{ 
            font-family: Arial, sans-serif; 
            max-width: 800px; 
            margin: 50px auto; 
            padding: 20px;
            background: #f5f5f5;
        }}
        .container {{
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }}
        .secret-info {{
            background: #e3f2fd;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            font-family: monospace;
        }}
        button {{
            background: #2196F3;
            color: white;
            border: none;
            padding: 15px 30px;
            font-size: 16px;
            border-radius: 5px;
            cursor: pointer;
            width: 100%;
        }}
        button:hover {{
            background: #1976D2;
        }}
    </style>
</head>
<body>
    <div class="container">
        <h1>🔑 Test z Shared Secret z .env</h1>
        
        <div class="secret-info">
            <strong>Używany Secret:</strong> {secret}<br>
            <strong>Store ID:</strong> {os.getenv('FISERV_STORE_ID')}<br>
            <strong>Order ID:</strong> {order_id}<br>
            <strong>Amount:</strong> {amount} PLN
        </div>
        
        <form method="POST" action="{action_url}">
"""
    
    for key, value in fields.items():
        html += f'            <input type="hidden" name="{key}" value="{value}">\n'
    
    html += """            <button type="submit">🚀 Testuj Płatność</button>
        </form>
    </div>
</body>
</html>"""
    
    # Zapisz
    filename = "test_env_secret.html"
    with open(filename, 'w') as f:
        f.write(html)
    
    print(f"\n✅ Test zapisany jako: {filename}")
    print("\nAby zmienić secret:")
    print("1. Edytuj plik .env")
    print("2. Odkomentuj inny FISERV_SHARED_SECRET")
    print("3. Uruchom ten skrypt ponownie")
    
    return filename

if __name__ == "__main__":
    import webbrowser
    filename = test_payment()
    webbrowser.open(f"file://{os.path.abspath(filename)}")