#!/usr/bin/env python3
"""
Test prostego datetime dla Warsaw timezone
"""

from datetime import datetime
import hmac
import hashlib
import base64

def test_datetime():
    shared_secret = "j}2W3P)Lwv"
    
    # Przykład - testuj bez txndatetime
    order_id = f"NO-DATE-{datetime.now().strftime('%Y%m%d%H%M%S')}"
    
    fields = {
        'storename': '760995999',
        'txntype': 'sale',
        'timezone': 'Europe/Warsaw',
        'chargetotal': '10.00',
        'currency': '985',
        'checkoutoption': 'combinedpage',
        'oid': order_id,
        'hash_algorithm': 'HMACSHA256'
    }
    
    # NIE dodawaj txndatetime - może to jest problem
    
    # Oblicz hash
    hash_fields = {k: v for k, v in fields.items() if k not in ['hash_algorithm', 'hashExtended']}
    sorted_fields = sorted(hash_fields.items())
    hash_string = '|'.join(str(v) for k, v in sorted_fields)
    
    hash_bytes = hmac.new(
        shared_secret.encode('utf-8'),
        hash_string.encode('utf-8'),
        hashlib.sha256
    ).digest()
    hash_value = base64.b64encode(hash_bytes).decode('utf-8')
    
    fields['hashExtended'] = hash_value
    
    print("Test BEZ txndatetime:")
    print(f"Order ID: {order_id}")
    print(f"Hash: {hash_value}")
    
    # Generuj HTML
    html = f"""<!DOCTYPE html>
<html>
<head>
    <title>Test bez txndatetime</title>
</head>
<body>
    <h1>Test BEZ txndatetime</h1>
    <p>Może txndatetime powoduje problem z Europe/Warsaw?</p>
    
    <form method="POST" action="https://test.ipg-online.com/connect/gateway/processing" target="_blank">
"""
    
    for k, v in fields.items():
        html += f'        <input type="hidden" name="{k}" value="{v}">\n'
    
    html += """        <button type="submit">TEST BEZ DATY</button>
    </form>
</body>
</html>"""
    
    with open('test_no_date.html', 'w') as f:
        f.write(html)
    
    print("\nTest zapisany jako: test_no_date.html")
    
    import webbrowser
    import os
    webbrowser.open(f"file://{os.path.abspath('test_no_date.html')}")

if __name__ == "__main__":
    test_datetime()