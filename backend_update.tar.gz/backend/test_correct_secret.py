#!/usr/bin/env python3
"""
Test z PRAWIDŁOWYM shared secret z pliku .env
"""

import requests
from datetime import datetime
from zoneinfo import ZoneInfo
import hmac
import hashlib
import base64
from collections import OrderedDict
import os

print("="*70)
print("TEST Z RÓŻNYMI SHARED SECRETS Z .ENV")
print("="*70)

# Secrets z pliku .env
secrets_to_test = [
    ("Alternatywny z .env", "c7dP/$5PBx"),
    ("REST API Secret", "aGOkU61VoIl5AWApLL7avcCpIVZxVGG6jYGVQib8xuG"),
    ("Oryginalny", "j}2W3P)Lwv")
]

store_id = "760995999"
gateway_url = "https://test.ipg-online.com/connect/gateway/processing"

# Warszawa timezone
warsaw_tz = ZoneInfo("Europe/Warsaw")
now_warsaw = datetime.now(warsaw_tz)
txndatetime = now_warsaw.strftime("%Y:%m:%d-%H:%M:%S")

print(f"\n📅 Timestamp warszawski: {txndatetime}")
print(f"🏪 Store ID: {store_id}")

for name, secret in secrets_to_test:
    print(f"\n{'='*60}")
    print(f"TEST: {name}")
    print(f"Secret: {secret}")
    print(f"{'='*60}")
    
    # Przygotuj formularz
    form_fields = OrderedDict([
        ('storename', store_id),
        ('txntype', 'sale'),
        ('timezone', 'Europe/Warsaw'),
        ('txndatetime', txndatetime),
        ('hash_algorithm', 'HMACSHA256'),
        ('chargetotal', '10.00'),
        ('currency', '985'),
        ('checkoutoption', 'combinedpage')
    ])
    
    # Oblicz hash
    exclude_fields = {'hash_algorithm', 'hashExtended', 'hash'}
    fields_for_hash = {k: v for k, v in form_fields.items() if k not in exclude_fields}
    sorted_fields = OrderedDict(sorted(fields_for_hash.items()))
    hash_string = '|'.join(str(v) for v in sorted_fields.values())
    
    print(f"\n🔗 Hash string: {hash_string[:80]}...")
    
    hash_bytes = hmac.new(
        secret.encode('utf-8'),
        hash_string.encode('utf-8'),
        hashlib.sha256
    ).digest()
    
    hash_value = base64.b64encode(hash_bytes).decode('utf-8')
    form_fields['hashExtended'] = hash_value
    
    print(f"🔐 Hash: {hash_value}")
    
    # Wyślij request
    print(f"\n📡 Wysyłanie...")
    
    response = requests.post(
        gateway_url,
        data=form_fields,
        headers={'Content-Type': 'application/x-www-form-urlencoded'},
        allow_redirects=False,
        timeout=10
    )
    
    print(f"Status: {response.status_code}")
    
    if response.status_code in [302, 303]:
        location = response.headers.get('location', '')
        
        if 'validationError' not in location:
            print(f"✅✅✅ SUKCES! DZIAŁAJĄCY SECRET: {secret}")
            print(f"Redirect: {location[:100]}...")
            
            # Zapisz działający secret
            with open('WORKING_SECRET.txt', 'w') as f:
                f.write(f"DZIAŁAJĄCY SECRET: {secret}\n")
                f.write(f"Nazwa: {name}\n")
                f.write(f"Timestamp testu: {datetime.now()}\n")
            
            # Generuj HTML do testu
            html = f"""<!DOCTYPE html>
<html>
<head>
    <title>DZIAŁAJĄCY TEST FISERV</title>
    <meta charset="UTF-8">
    <style>
        body {{ font-family: Arial; padding: 40px; background: #e8f5e9; }}
        .success {{ background: #4caf50; color: white; padding: 20px; border-radius: 10px; }}
        button {{ background: #4caf50; color: white; padding: 15px 30px; border: none; font-size: 18px; }}
    </style>
</head>
<body>
    <div class="success">
        <h1>✅ ZNALEZIONO DZIAŁAJĄCY SECRET!</h1>
        <p>Secret: {secret}</p>
        <p>Nazwa: {name}</p>
    </div>
    
    <h2>Test płatności:</h2>
    <form method="POST" action="{gateway_url}">
"""
            for k, v in form_fields.items():
                html += f'        <input type="hidden" name="{k}" value="{v}">\n'
            
            html += """
        <button type="submit">🎉 PRZETESTUJ PŁATNOŚĆ</button>
    </form>
</body>
</html>"""
            
            with open('WORKING_TEST.html', 'w') as f:
                f.write(html)
            
            print(f"\n🎉 Zapisano działający test do: WORKING_TEST.html")
            break
            
        else:
            print(f"❌ Błąd walidacji")
            print(f"Location: {location[:100]}...")
    else:
        print(f"⚠️ Nieoczekiwany status")

print("\n" + "="*70)
print("PODSUMOWANIE")
print("="*70)

# Sprawdź czy znaleźliśmy działający
if os.path.exists('WORKING_SECRET.txt'):
    with open('WORKING_SECRET.txt', 'r') as f:
        print(f"\n✅ {f.read()}")
else:
    print("\n❌ Żaden secret nie zadziałał.")
    print("Możliwe przyczyny:")
    print("1. Konto nie jest aktywne")
    print("2. Store ID nie jest skonfigurowany")
    print("3. Wszystkie secrets są nieprawidłowe")