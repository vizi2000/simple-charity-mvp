#!/usr/bin/env python3
"""
Test Fiserv Developer Portal API - inne URL!
"""

import requests
import json
import base64
from datetime import datetime

# Klucze
API_KEY = "xWdewnCcYTy8G0s4oS1r5GAOmcdVRYQn"
API_SECRET = "aGOkU61VoIl5AWApLL7avcCpIVZxVGG6jYGVQib8xuG"

# Różne możliwe URL-e Fiserv
ENDPOINTS = [
    "https://api.test.fiservapps.com",
    "https://sandbox.api.fiservapps.com", 
    "https://cert.api.firstdata.com/gateway/v2",
    "https://api-cert.payeezy.com/v1",
    "https://api.demo.fiserv.com"
]

def test_endpoints():
    """Test różnych endpointów Fiserv"""
    
    print("="*60)
    print("SZUKANIE DZIAŁAJĄCEGO ENDPOINTU FISERV")
    print("="*60)
    
    # Headers
    credentials = f"{API_KEY}:{API_SECRET}"
    encoded_credentials = base64.b64encode(credentials.encode()).decode()
    
    headers = {
        "Authorization": f"Basic {encoded_credentials}",
        "Content-Type": "application/json",
        "Accept": "application/json",
        "Api-Key": API_KEY  # Niektóre API wymagają tego
    }
    
    working_endpoints = []
    
    for base_url in ENDPOINTS:
        print(f"\n[Testing: {base_url}]")
        
        # Test różnych ścieżek
        test_paths = [
            "/payments",
            "/v1/payments", 
            "/v2/payments",
            "/api/v1/payments",
            "/transactions",
            "/v1/transactions"
        ]
        
        for path in test_paths:
            try:
                url = f"{base_url}{path}"
                print(f"  Trying: {url}...", end=" ")
                
                # GET request
                response = requests.get(
                    url,
                    headers=headers,
                    timeout=5
                )
                
                print(f"Status: {response.status_code}")
                
                if response.status_code in [200, 401, 403]:
                    # 401/403 oznacza że endpoint istnieje, ale auth może być inny
                    working_endpoints.append({
                        "url": url,
                        "status": response.status_code,
                        "response": response.text[:100]
                    })
                    print(f"    ✓ Endpoint exists!")
                    
                    # Spróbuj POST
                    if response.status_code != 200:
                        test_payment_data = {
                            "amount": "10.00",
                            "currency": "PLN",
                            "payment_method": {"card": {
                                "number": "4005550000000019",
                                "exp_month": "12",
                                "exp_year": "25",
                                "cvc": "111"
                            }}
                        }
                        
                        post_response = requests.post(
                            url,
                            headers=headers,
                            json=test_payment_data,
                            timeout=5
                        )
                        print(f"    POST Status: {post_response.status_code}")
                        if post_response.status_code != 404:
                            print(f"    Response: {post_response.text[:200]}")
                            
            except requests.exceptions.Timeout:
                print("Timeout")
            except requests.exceptions.ConnectionError:
                print("Connection Error")
            except Exception as e:
                print(f"Error: {type(e).__name__}")
    
    print("\n" + "="*60)
    print("PODSUMOWANIE")
    print("="*60)
    
    if working_endpoints:
        print("\n✅ Znalezione działające endpointy:")
        for ep in working_endpoints:
            print(f"\nURL: {ep['url']}")
            print(f"Status: {ep['status']}")
            print(f"Response: {ep['response']}...")
    else:
        print("\n❌ Nie znaleziono działających endpointów")
        print("\nMożliwe przyczyny:")
        print("1. Klucze są do innego środowiska")
        print("2. Wymagana jest inna metoda autoryzacji")
        print("3. Konto sandbox nie jest aktywne")
    
    # Test docs.fiserv.dev endpoint
    print("\n" + "="*60)
    print("TEST DOKUMENTACJI API")
    print("="*60)
    
    # Według dokumentacji z linku
    doc_url = "https://connect.fiservapis.com/cq/v1/payments"
    
    print(f"\nURL z dokumentacji: {doc_url}")
    
    try:
        # Inny format auth dla tego API
        headers_v2 = {
            "Api-Key": API_KEY,
            "Secret": API_SECRET,
            "Content-Type": "application/json"
        }
        
        response = requests.get(
            doc_url,
            headers=headers_v2,
            timeout=5
        )
        
        print(f"Status: {response.status_code}")
        print(f"Response: {response.text[:300]}")
        
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    test_endpoints()