#!/usr/bin/env python3
"""
Test trybu Classic - skoro Combined Page nie działa
"""

from datetime import datetime, timedelta
import hmac
import hashlib
import base64

def test_classic_mode():
    """Test z classic checkout"""
    
    print("="*60)
    print("TEST CLASSIC MODE")
    print("="*60)
    
    shared_secret = "j}2W3P)Lwv"
    warsaw_now = datetime.utcnow() + timedelta(hours=1)
    
    print("\n✅ ODKRYCIE: combinedpage powoduje błąd!")
    print("❌ Combined Page nie jest aktywna dla Store 760995999")
    print("🔄 Testujemy tryb Classic...")
    
    html = f"""<!DOCTYPE html>
<html>
<head>
    <title>Test Classic Mode</title>
    <meta charset="UTF-8">
    <style>
        body {{ font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }}
        .test {{ background: white; padding: 20px; margin: 15px 0; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }}
        .success {{ background: #d4edda; border-left: 4px solid #28a745; }}
        .error {{ background: #ffebee; border-left: 4px solid #f44336; }}
        .warning {{ background: #fff3e0; border-left: 4px solid #ff9800; }}
        button {{ background: #4caf50; color: white; padding: 12px 24px; border: none; cursor: pointer; margin: 5px; font-size: 16px; }}
        code {{ background: #f5f5f5; padding: 2px 5px; font-family: monospace; }}
    </style>
</head>
<body>
    <h1>🎯 Test Classic Mode</h1>
    
    <div class="test error">
        <h3>❌ Problem zidentyfikowany!</h3>
        <p><strong>checkoutoption=combinedpage</strong> powoduje błąd</p>
        <p>Combined Page NIE jest aktywna dla Store ID 760995999</p>
    </div>
    
    <div class="test success">
        <h3>✅ Rozwiązanie: Użyj Classic</h3>
        <p>Zmień <code>checkoutoption</code> z <code>combinedpage</code> na <code>classic</code></p>
    </div>
"""
    
    # Test 1: Classic bez hash
    html += """
    <div class="test">
        <h3>Test 1: Classic bez hash</h3>
        <form method="POST" action="https://test.ipg-online.com/connect/gateway/processing" target="_blank">
            <input type="hidden" name="storename" value="760995999">
            <input type="hidden" name="chargetotal" value="10.00">
            <input type="hidden" name="currency" value="985">
            <input type="hidden" name="txntype" value="sale">
            <input type="hidden" name="checkoutoption" value="classic">
            <button type="submit">TEST CLASSIC BEZ HASH</button>
        </form>
    </div>
"""
    
    # Test 2: Classic z pełną konfiguracją
    classic_fields = {
        'storename': '760995999',
        'txntype': 'sale',
        'timezone': 'Europe/Warsaw',
        'txndatetime': warsaw_now.strftime("%Y:%m:%d-%H:%M:%S"),
        'chargetotal': '10.00',
        'currency': '985',
        'checkoutoption': 'classic',  # ZMIANA!
        'oid': f'CLASSIC{warsaw_now.strftime("%Y%m%d%H%M%S")}',
        'hash_algorithm': 'HMACSHA256'
    }
    
    # Oblicz hash
    hash_fields = {k: v for k, v in classic_fields.items() if k not in ['hash_algorithm', 'hashExtended']}
    sorted_fields = sorted(hash_fields.items())
    hash_string = '|'.join(str(v) for k, v in sorted_fields)
    hash_value = base64.b64encode(
        hmac.new(shared_secret.encode('utf-8'), hash_string.encode('utf-8'), hashlib.sha256).digest()
    ).decode('utf-8')
    classic_fields['hashExtended'] = hash_value
    
    html += f"""
    <div class="test">
        <h3>Test 2: Classic z pełną konfiguracją i hashem</h3>
        <p>Hash string: <code>{hash_string[:60]}...</code></p>
        <form method="POST" action="https://test.ipg-online.com/connect/gateway/processing" target="_blank">
"""
    
    for k, v in classic_fields.items():
        html += f'            <input type="hidden" name="{k}" value="{v}">\n'
    
    html += """            <button type="submit">TEST CLASSIC Z HASHEM</button>
        </form>
    </div>
    
    <div class="test warning">
        <h3>⚠️ Ważne!</h3>
        <p>W Virtual Terminal widziałeś że:</p>
        <ul>
            <li>Combined Page = SKONFIGUROWANA</li>
            <li>Classic = PUSTA</li>
        </ul>
        <p>Mimo to, Combined Page nie działa przez IPG Connect!</p>
        <p>To sugeruje że konfiguracja w VT nie jest zsynchronizowana z IPG Connect.</p>
    </div>
    
    <div class="test">
        <h3>📝 Do zrobienia:</h3>
        <ol>
            <li>Zmień w kodzie <code>checkoutoption</code> na <code>classic</code></li>
            <li>Jeśli Classic też nie działa - problem z hashem/secretem</li>
            <li>Poinformuj Fiserv że Combined Page nie działa mimo ich zaleceń</li>
        </ol>
    </div>
</body>
</html>"""
    
    with open('test_classic_mode.html', 'w', encoding='utf-8') as f:
        f.write(html)
    
    print(f"\n✅ Test zapisany jako: test_classic_mode.html")
    
    # Aktualizuj plik konfiguracyjny
    print("\n📝 ZMIANA W KODZIE:")
    print("W pliku fiserv_ipg_client.py zmień:")
    print("  'checkoutoption': 'combinedpage',")
    print("na:")
    print("  'checkoutoption': 'classic',")
    
    import webbrowser
    import os
    webbrowser.open(f"file://{os.path.abspath('test_classic_mode.html')}")

if __name__ == "__main__":
    test_classic_mode()