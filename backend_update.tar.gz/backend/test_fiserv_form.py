#!/usr/bin/env python3
"""
Test script to generate and verify Fiserv payment form data
Based on working examples from documentation
"""

import hashlib
import hmac
import base64
from datetime import datetime
import pytz

def generate_hash(params: dict, shared_secret: str) -> str:
    """Generate HMAC-SHA256 hash for Fiserv payment"""
    # Sort parameters alphabetically by key
    sorted_keys = sorted(params.keys())
    
    # Create string to sign by joining values with pipe separator
    values = [str(params[key]) for key in sorted_keys]
    string_to_sign = '|'.join(values)
    
    print(f"String to sign: {string_to_sign}")
    
    # Generate HMAC-SHA256
    signature = hmac.new(
        shared_secret.encode('utf-8'),
        string_to_sign.encode('utf-8'),
        hashlib.sha256
    ).digest()
    
    # Encode in Base64
    hash_value = base64.b64encode(signature).decode('utf-8')
    print(f"Generated hash: {hash_value}")
    
    return hash_value

def test_payment_form():
    """Test payment form generation with all possible required fields"""
    
    # Configuration
    shared_secret = 'j}2W3P)Lwv'
    store_id = '760995999'
    
    # Get current Warsaw time
    warsaw_tz = pytz.timezone('Europe/Warsaw')
    now = datetime.now(warsaw_tz)
    txn_datetime = now.strftime('%Y:%m:%d-%H:%M:%S')
    
    # Generate unique order ID
    order_id = f"TEST-{now.strftime('%Y%m%d-%H%M%S')}"
    
    # Base URL for callbacks
    base_url = 'https://borgtools.ddns.net/bramkamvp'
    
    # Test 1: Minimal required fields according to Fiserv docs
    print("=" * 50)
    print("TEST 1: MINIMAL REQUIRED FIELDS")
    print("=" * 50)
    
    params_minimal = {
        'chargetotal': '10.00',
        'currency': '985',
        'oid': order_id,
        'storename': store_id,
        'timezone': 'Europe/Warsaw',
        'txndatetime': txn_datetime,
        'txntype': 'sale',
        'hash_algorithm': 'HMACSHA256'
    }
    
    hash1 = generate_hash(params_minimal, shared_secret)
    print(f"\nMinimal form data:")
    for k, v in params_minimal.items():
        print(f"  {k}: {v}")
    print(f"  hashExtended: {hash1}")
    
    # Test 2: With response URLs (commonly required)
    print("\n" + "=" * 50)
    print("TEST 2: WITH RESPONSE URLS")
    print("=" * 50)
    
    params_with_urls = {
        'chargetotal': '10.00',
        'currency': '985',
        'hash_algorithm': 'HMACSHA256',
        'oid': order_id,
        'responseFailURL': f'{base_url}/payment/failure?oid={order_id}',
        'responseSuccessURL': f'{base_url}/payment/success?oid={order_id}',
        'storename': store_id,
        'timezone': 'Europe/Warsaw',
        'txndatetime': txn_datetime,
        'txntype': 'sale'
    }
    
    hash2 = generate_hash(params_with_urls, shared_secret)
    
    # Add transactionNotificationURL AFTER hash generation
    full_form_data = params_with_urls.copy()
    full_form_data['hashExtended'] = hash2
    full_form_data['transactionNotificationURL'] = f'{base_url}/api/payments/webhooks/fiserv/s2s'
    
    print(f"\nForm data with URLs:")
    for k, v in full_form_data.items():
        print(f"  {k}: {v}")
    
    # Test 3: Full form with all options we use
    print("\n" + "=" * 50)
    print("TEST 3: FULL FORM WITH ALL OPTIONS")
    print("=" * 50)
    
    params_full = {
        'chargetotal': '10.00',
        'checkoutoption': 'combinedpage',
        'currency': '985',
        'hash_algorithm': 'HMACSHA256',
        'oid': order_id,
        'paymentMethod': 'M',
        'responseFailURL': f'{base_url}/payment/failure?oid={order_id}',
        'responseSuccessURL': f'{base_url}/payment/success?oid={order_id}',
        'storename': store_id,
        'timezone': 'Europe/Warsaw',
        'txndatetime': txn_datetime,
        'txntype': 'sale'
    }
    
    hash3 = generate_hash(params_full, shared_secret)
    
    # Create full form data
    full_form_complete = params_full.copy()
    full_form_complete['hashExtended'] = hash3
    full_form_complete['transactionNotificationURL'] = f'{base_url}/api/payments/webhooks/fiserv/s2s'
    
    print(f"\nComplete form data:")
    for k, v in full_form_complete.items():
        print(f"  {k}: {v}")
    
    # Generate HTML form for testing
    print("\n" + "=" * 50)
    print("HTML FORM FOR MANUAL TESTING")
    print("=" * 50)
    
    html = f'''<!DOCTYPE html>
<html>
<head>
    <title>Fiserv Payment Test</title>
    <meta charset="UTF-8">
</head>
<body>
    <h1>Test Payment Form</h1>
    <form method="POST" action="https://test.ipg-online.com/connect/gateway/processing">
'''
    
    for key, value in full_form_complete.items():
        html += f'        <input type="hidden" name="{key}" value="{value}"/>\n'
    
    html += '''        <button type="submit">Submit Payment</button>
    </form>
    <hr>
    <h2>Form Data:</h2>
    <pre>'''
    
    for key, value in full_form_complete.items():
        html += f'{key}: {value}\n'
    
    html += '''</pre>
</body>
</html>'''
    
    # Save HTML file
    with open('test_payment_form.html', 'w') as f:
        f.write(html)
    
    print("\nHTML form saved to: test_payment_form.html")
    print("Open this file in a browser to test the payment flow manually.")
    
    return full_form_complete

if __name__ == "__main__":
    test_payment_form()