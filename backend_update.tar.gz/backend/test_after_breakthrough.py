#!/usr/bin/env python3
"""
Test po przełomie - wiemy że 'classic' przechodzi walidację!
"""

import os
import hmac
import hashlib
import base64
from datetime import datetime, timedelta
import webbrowser

# Konfiguracja
STORE_ID = "760995999"
SHARED_SECRET = "j}2W3P)Lwv"  # Ten secret działa!
GATEWAY_URL = "https://test.ipg-online.com/connect/gateway/processing"

def generate_hash(secret, values_string):
    """Generuj hash dla danego secretu"""
    hash_bytes = hmac.new(
        secret.encode('utf-8'),
        values_string.encode('utf-8'),
        hashlib.sha256
    ).digest()
    return base64.b64encode(hash_bytes).decode('utf-8')

def test_after_breakthrough():
    """Test różnych wariantów po odkryciu że 'classic' działa"""
    
    # Timestamp
    now = datetime.utcnow() + timedelta(seconds=30)
    txndatetime = now.strftime("%Y:%m:%d-%H:%M:%S")
    
    print("="*60)
    print("TEST PO PRZEŁOMIE - 'classic' przechodzi walidację!")
    print("="*60)
    print(f"\nTimestamp: {txndatetime}\n")
    
    # Generuj HTML
    html = f"""<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Test After Breakthrough</title>
    <style>
        body {{ font-family: Arial, sans-serif; max-width: 1200px; margin: 0 auto; padding: 20px; }}
        .test-form {{ 
            background: #d4edda; 
            padding: 20px; 
            margin: 20px 0; 
            border-radius: 5px;
            border: 2px solid #28a745;
        }}
        h3 {{ margin-top: 0; color: #155724; }}
        button {{ 
            background: #28a745; 
            color: white; 
            border: none; 
            padding: 12px 24px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            font-weight: bold;
        }}
        button:hover {{ background: #218838; }}
        .info {{ 
            font-family: monospace; 
            background: #c3e6cb; 
            padding: 10px;
            margin: 10px 0;
            border-radius: 3px;
        }}
        .success-info {{
            background: #b8daff;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            border: 1px solid #004085;
        }}
    </style>
</head>
<body>
    <h1>🎉 Przełom! Test z 'classic' przeszedł walidację!</h1>
    
    <div class="success-info">
        <strong>✅ Co wiemy:</strong><br>
        - checkoutoption='classic' przechodzi walidację<br>
        - Hash jest obliczany POPRAWNIE<br>
        - Shared Secret jest POPRAWNY<br>
        - Otrzymaliśmy ID transakcji: 5060ddab-5851-44ad-8358-66440593731d<br>
        - Błąd jest na etapie PRZETWARZANIA, nie walidacji
    </div>
"""
    
    tests = []
    
    # Test 1: Classic z EUR
    test1 = {
        'storename': STORE_ID,
        'txntype': 'sale',
        'timezone': 'Europe/Berlin',
        'txndatetime': txndatetime,
        'chargetotal': '10.00',
        'currency': '978',  # EUR!
        'checkoutoption': 'classic',
        'oid': f'CLASSIC-EUR-{datetime.now().strftime("%Y%m%d%H%M%S")}'
    }
    tests.append(("Classic + EUR", test1))
    
    # Test 2: Classic z USD
    test2 = {
        'storename': STORE_ID,
        'txntype': 'sale',
        'timezone': 'Europe/Berlin',
        'txndatetime': txndatetime,
        'chargetotal': '10.00',
        'currency': '840',  # USD!
        'checkoutoption': 'classic',
        'oid': f'CLASSIC-USD-{datetime.now().strftime("%Y%m%d%H%M%S")}'
    }
    tests.append(("Classic + USD", test2))
    
    # Test 3: Classic z małą kwotą
    test3 = {
        'storename': STORE_ID,
        'txntype': 'sale',
        'timezone': 'Europe/Berlin',
        'txndatetime': txndatetime,
        'chargetotal': '1.00',  # Mała kwota
        'currency': '985',  # PLN
        'checkoutoption': 'classic',
        'oid': f'CLASSIC-1PLN-{datetime.now().strftime("%Y%m%d%H%M%S")}'
    }
    tests.append(("Classic + 1 PLN", test3))
    
    # Test 4: Classic bez 3DS
    test4 = {
        'storename': STORE_ID,
        'txntype': 'sale',
        'timezone': 'Europe/Berlin',
        'txndatetime': txndatetime,
        'chargetotal': '10.00',
        'currency': '985',
        'checkoutoption': 'classic',
        'authenticateTransaction': 'false',  # Wyłącz 3DS
        'oid': f'CLASSIC-NO3DS-{datetime.now().strftime("%Y%m%d%H%M%S")}'
    }
    tests.append(("Classic + No 3DS", test4))
    
    # Test 5: Classic z paymentMethod
    test5 = {
        'storename': STORE_ID,
        'txntype': 'sale',
        'timezone': 'Europe/Berlin',
        'txndatetime': txndatetime,
        'chargetotal': '10.00',
        'currency': '985',
        'checkoutoption': 'classic',
        'paymentMethod': 'M',  # Mastercard
        'oid': f'CLASSIC-MC-{datetime.now().strftime("%Y%m%d%H%M%S")}'
    }
    tests.append(("Classic + Mastercard", test5))
    
    # Test 6: Spróbuj combinedpage z EUR
    test6 = {
        'storename': STORE_ID,
        'txntype': 'sale',
        'timezone': 'Europe/Berlin',
        'txndatetime': txndatetime,
        'chargetotal': '10.00',
        'currency': '978',  # EUR
        'checkoutoption': 'combinedpage',  # Wróć do combined
        'oid': f'COMBINED-EUR-{datetime.now().strftime("%Y%m%d%H%M%S")}'
    }
    tests.append(("CombinedPage + EUR", test6))
    
    # Test 7: Classic z response URLs
    test7 = {
        'storename': STORE_ID,
        'txntype': 'sale',
        'timezone': 'Europe/Berlin',
        'txndatetime': txndatetime,
        'chargetotal': '10.00',
        'currency': '985',
        'checkoutoption': 'classic',
        'responseSuccessURL': 'https://example.com/success',
        'responseFailURL': 'https://example.com/failure',
        'oid': f'CLASSIC-URLS-{datetime.now().strftime("%Y%m%d%H%M%S")}'
    }
    tests.append(("Classic + Response URLs", test7))
    
    # Test 8: Classic z minimalnym zestawem pól
    test8 = {
        'storename': STORE_ID,
        'txntype': 'sale',
        'chargetotal': '10.00',
        'currency': '985',
        'checkoutoption': 'classic',
    }
    tests.append(("Classic Minimal", test8))
    
    # Generuj formularze
    for i, (name, params) in enumerate(tests, 1):
        # Sortuj i generuj hash
        sorted_params = sorted(params.items())
        values_to_hash = '|'.join(str(v) for k, v in sorted_params)
        hash_value = generate_hash(SHARED_SECRET, values_to_hash)
        
        print(f"{i}. {name}:")
        if 'oid' in params:
            print(f"   Order ID: {params['oid']}")
        print(f"   Currency: {params.get('currency', '985')}")
        print()
        
        # Dodaj hash do parametrów
        form_params = params.copy()
        form_params['hash_algorithm'] = 'HMACSHA256'
        form_params['hashExtended'] = hash_value
        
        html += f"""
    <div class="test-form">
        <h3>Test {i}: {name}</h3>
        <div class="info">
"""
        for k, v in params.items():
            if k != 'oid' or len(v) < 50:  # Nie pokazuj długich OID
                html += f"            {k}: {v}<br>\n"
        html += f"""        </div>
        <form method="POST" action="{GATEWAY_URL}" target="_blank">
"""
        for k, v in form_params.items():
            html += f'            <input type="hidden" name="{k}" value="{v}">\n'
        
        html += f"""            <button type="submit">🚀 Testuj: {name}</button>
        </form>
    </div>
"""
    
    html += """
    <div style="margin-top: 30px; padding: 15px; background: #cce5ff; border-radius: 5px;">
        <strong>🎯 Strategia testowania:</strong><br>
        1. <strong>Zmień walutę</strong> - może PLN nie jest obsługiwane<br>
        2. <strong>Zmniejsz kwotę</strong> - może są limity<br>
        3. <strong>Wyłącz 3DS</strong> - upraszcza proces<br>
        4. <strong>Dodaj paymentMethod</strong> - może być wymagane dla 'classic'<br><br>
        
        <strong>📝 Zapisz ID transakcji!</strong><br>
        Jeśli otrzymasz błąd aplikacji, zapisz ID transakcji do wysłania supportowi.
    </div>
    
    <div style="margin-top: 20px; padding: 15px; background: #f8d7da; border-radius: 5px;">
        <strong>⚠️ Jeśli nadal otrzymujesz błąd aplikacji:</strong><br>
        To oznacza że konto testowe nie jest w pełni skonfigurowane.<br>
        Wyślij do supportu wszystkie ID transakcji z błędami.
    </div>
</body>
</html>"""
    
    filename = "test_after_breakthrough.html"
    with open(filename, 'w', encoding='utf-8') as f:
        f.write(html)
    
    print(f"✅ Test zapisany jako: {filename}")
    print("\n🎉 PRZEŁOM: Wiemy że 'classic' przechodzi walidację!")
    print("Teraz testuj różne waluty i konfiguracje.")
    
    return filename

if __name__ == "__main__":
    filename = test_after_breakthrough()
    webbrowser.open(f"file://{os.path.abspath(filename)}")