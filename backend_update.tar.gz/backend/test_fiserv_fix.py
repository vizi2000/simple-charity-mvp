#!/usr/bin/env python3
"""Test script to verify Fiserv payment integration fixes"""

import os
import sys
from datetime import datetime
from zoneinfo import ZoneInfo

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app.utils.fiserv_ipg_client import fiserv_ipg_client

def test_timezone_and_timestamp():
    """Test that timezone and timestamp are correctly generated"""
    
    print("Testing Fiserv IPG Client fixes...")
    print("="*60)
    
    # Test payment creation
    result = fiserv_ipg_client.create_payment_form_data(
        amount=50.00,
        order_id='TEST-' + datetime.now().strftime('%Y%m%d%H%M%S'),
        description='Test payment',
        success_url='https://charity.ngrok.app/platnosc/test/status?result=success',
        failure_url='https://charity.ngrok.app/platnosc/test/status?result=failure',
        notification_url='https://charity-webhook.ngrok.app/api/webhooks/fiserv',
        customer_info={
            'name': 'Jan Kowalski',
            'email': 'jan.kowalski@example.com'
        }
    )
    
    form_fields = result['form_fields']
    
    # Check timezone
    print(f"✓ Timezone: {form_fields['timezone']}")
    assert form_fields['timezone'] == 'Europe/Warsaw', "Timezone should be Europe/Warsaw"
    
    # Check timestamp format and value
    txndatetime = form_fields['txndatetime']
    print(f"✓ Timestamp: {txndatetime}")
    
    # Parse timestamp to verify it's in correct format
    try:
        timestamp_parts = txndatetime.split('-')
        date_part = timestamp_parts[0]
        time_part = timestamp_parts[1]
        
        # Verify format YYYY:MM:DD-HH:MM:SS
        year, month, day = date_part.split(':')
        hour, minute, second = time_part.split(':')
        
        # Create datetime object to verify it's valid
        dt = datetime(int(year), int(month), int(day), 
                     int(hour), int(minute), int(second))
        
        # Get current Warsaw time
        warsaw_tz = ZoneInfo('Europe/Warsaw')
        now_warsaw = datetime.now(warsaw_tz)
        
        # Check that timestamp is current (within last minute)
        time_diff = abs((now_warsaw.replace(tzinfo=None) - dt).total_seconds())
        assert time_diff < 60, f"Timestamp should be current, but difference is {time_diff} seconds"
        
        print(f"✓ Timestamp is current (within {time_diff:.0f} seconds)")
        print(f"✓ Current Warsaw time: {now_warsaw.strftime('%Y:%m:%d-%H:%M:%S')}")
        
    except Exception as e:
        print(f"✗ Error parsing timestamp: {e}")
        raise
    
    # Check other critical fields
    print(f"✓ Store ID: {form_fields['storename']}")
    print(f"✓ Currency: {form_fields['currency']} (PLN)")
    print(f"✓ Amount: {form_fields['chargetotal']}")
    print(f"✓ Checkout option: {form_fields['checkoutoption']}")
    
    # Check hash is generated
    assert 'hashExtended' in form_fields, "Hash should be generated"
    print(f"✓ Hash generated: {form_fields['hashExtended'][:20]}...")
    
    print("\n" + "="*60)
    print("All tests passed! ✓")
    print("\nForm fields ready for submission:")
    for key, value in sorted(form_fields.items()):
        if key != 'hashExtended':
            print(f"  {key}: {value}")
    print(f"  hashExtended: {form_fields['hashExtended'][:30]}...")
    
    return True

if __name__ == "__main__":
    try:
        test_timezone_and_timestamp()
        print("\n✅ Fiserv integration fixes verified successfully!")
    except AssertionError as e:
        print(f"\n❌ Test failed: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Unexpected error: {e}")
        sys.exit(1)