#!/usr/bin/env python3
"""
FINALNY TEST Z WSZYSTKIMI ODKRYCIAMI
- Poprawny timezone: Europe/Warsaw
- Poprawny timestamp: aktualny czas warszawski
- Poprawna metoda generowania hasha
"""

import httpx
import asyncio
import json
from datetime import datetime
from zoneinfo import ZoneInfo
import hmac
import hashlib
import base64
from collections import OrderedDict


class FiservFinalTest:
    """Finalny test z poprawnymi parametrami"""
    
    def __init__(self):
        self.store_id = "760995999"
        self.shared_secret = "j}2W3P)Lwv"
        self.gateway_url = "https://test.ipg-online.com/connect/gateway/processing"
        
    def generate_warsaw_timestamp(self):
        """Generuj POPRAWNY timestamp warszawski"""
        warsaw_tz = ZoneInfo("Europe/Warsaw")
        now_warsaw = datetime.now(warsaw_tz)
        timestamp = now_warsaw.strftime("%Y:%m:%d-%H:%M:%S")
        
        print(f"✅ Wygenerowany timestamp warszawski: {timestamp}")
        print(f"   Aktualny czas: {now_warsaw.strftime('%Y-%m-%d %H:%M:%S %Z')}")
        
        return timestamp
    
    def calculate_hash(self, form_fields):
        """Oblicz hash dokładnie jak oczekuje Fiserv"""
        # Pola które NIE wchodzą do hasha
        exclude_fields = {'hash_algorithm', 'hashExtended', 'hash'}
        
        # Filtruj pola do hasha
        fields_for_hash = {
            k: v for k, v in form_fields.items() 
            if k not in exclude_fields and v is not None and v != ''
        }
        
        # KRYTYCZNE: Sortuj alfabetycznie po KLUCZU
        sorted_fields = OrderedDict(sorted(fields_for_hash.items()))
        
        print("\n📝 Pola do hasha (alfabetycznie):")
        for i, (k, v) in enumerate(sorted_fields.items(), 1):
            print(f"   {i:2}. {k}: {v[:50]}...")
        
        # String do hasha: TYLKO WARTOŚCI, separator |
        hash_string = '|'.join(str(v) for v in sorted_fields.values())
        
        print(f"\n🔗 String do hasha (pierwsze 150 znaków):")
        print(f"   {hash_string[:150]}...")
        
        # Oblicz HMAC-SHA256
        hash_bytes = hmac.new(
            self.shared_secret.encode('utf-8'),
            hash_string.encode('utf-8'),
            hashlib.sha256
        ).digest()
        
        # Zakoduj w Base64
        hash_value = base64.b64encode(hash_bytes).decode('utf-8')
        
        print(f"\n🔐 Wygenerowany hash: {hash_value}")
        
        return hash_value
    
    def create_payment_form(self):
        """Stwórz formularz płatności z WSZYSTKIMI poprawnymi parametrami"""
        
        print("="*70)
        print("TWORZENIE FORMULARZA Z POPRAWNYMI PARAMETRAMI")
        print("="*70)
        
        # Generuj aktualny timestamp warszawski
        txndatetime = self.generate_warsaw_timestamp()
        
        # Unikalny order ID
        order_id = f"FINAL-TEST-{datetime.now().strftime('%Y%m%d%H%M%S')}"
        
        # Przygotuj pola formularza
        form_fields = OrderedDict([
            ('storename', self.store_id),
            ('txntype', 'sale'),
            ('timezone', 'Europe/Warsaw'),  # ✅ POPRAWNE
            ('txndatetime', txndatetime),    # ✅ Czas warszawski
            ('hash_algorithm', 'HMACSHA256'),
            ('chargetotal', '25.00'),
            ('currency', '985'),
            ('checkoutoption', 'combinedpage'),
            ('oid', order_id),
            ('responseSuccessURL', f'https://charity.ngrok.app/platnosc/{order_id}/status?result=success'),
            ('responseFailURL', f'https://charity.ngrok.app/platnosc/{order_id}/status?result=failure'),
            ('transactionNotificationURL', 'https://charity-webhook.ngrok.app/api/webhooks/fiserv'),
            ('bname', 'Jan Kowalski'),
            ('bemail', 'jan.kowalski@example.com')
        ])
        
        # Oblicz hash
        hash_value = self.calculate_hash(form_fields)
        form_fields['hashExtended'] = hash_value
        
        print("\n✅ WSZYSTKIE POLA FORMULARZA:")
        print("-" * 50)
        for key, value in form_fields.items():
            if key == 'hashExtended':
                print(f"{key:30} = {value[:30]}...")
            else:
                print(f"{key:30} = {value}")
        
        return form_fields, order_id
    
    async def test_submission(self, form_fields):
        """Wyślij formularz do Fiserv"""
        
        print("\n" + "="*70)
        print("WYSYŁANIE DO FISERV")
        print("="*70)
        
        async with httpx.AsyncClient(follow_redirects=False, timeout=30.0) as client:
            try:
                response = await client.post(
                    self.gateway_url,
                    data=form_fields,
                    headers={
                        'Content-Type': 'application/x-www-form-urlencoded',
                        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36',
                        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                        'Accept-Language': 'pl-PL,pl;q=0.9,en;q=0.8',
                        'Accept-Encoding': 'gzip, deflate, br',
                        'Origin': 'https://charity.ngrok.app',
                        'Referer': 'https://charity.ngrok.app/'
                    }
                )
                
                print(f"📡 Status: {response.status_code}")
                print(f"📍 Headers: {dict(response.headers)}")
                
                if response.status_code in [302, 303]:
                    location = response.headers.get('location', '')
                    print(f"\n🔄 Redirect to: {location[:100]}...")
                    
                    if 'validationError' in location:
                        print("\n❌ VALIDATION ERROR")
                        
                        # Analizuj parametry
                        if '?' in location:
                            params = location.split('?')[1]
                            print(f"   Parametry: {params}")
                            
                            # Dekoduj parametry
                            if 'k=' in params:
                                k_value = params.split('k=')[1].split('&')[0]
                                try:
                                    import base64
                                    decoded = base64.b64decode(k_value).decode('utf-8')
                                    print(f"   Dekodowany parametr k: {decoded}")
                                except:
                                    pass
                                    
                    elif 'payment' in location.lower() or 'checkout' in location.lower():
                        print("\n✅ SUKCES! Przekierowanie do strony płatności")
                        return True
                    else:
                        print("\n⚠️ Nieznane przekierowanie")
                        
                elif response.status_code == 200:
                    # Sprawdź treść odpowiedzi
                    content = response.text
                    if 'error' in content.lower():
                        print("\n❌ Odpowiedź zawiera błąd")
                        # Znajdź komunikat błędu
                        import re
                        errors = re.findall(r'error[^>]*>([^<]+)', content, re.IGNORECASE)
                        if errors:
                            print(f"   Błędy: {errors}")
                    else:
                        print("\n📄 Otrzymano stronę (200 OK)")
                        
            except Exception as e:
                print(f"\n❌ Błąd połączenia: {e}")
                return False
                
        return False
    
    def generate_html(self, form_fields, order_id):
        """Generuj HTML do ręcznego testu"""
        
        html = f"""<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Finalny Test Fiserv - {order_id}</title>
    <style>
        body {{ font-family: Arial, sans-serif; padding: 40px; background: #f5f5f5; }}
        .container {{ max-width: 800px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }}
        h1 {{ color: #333; }}
        .success {{ background: #d4edda; color: #155724; padding: 15px; border-radius: 5px; margin: 20px 0; }}
        .field {{ margin: 10px 0; padding: 10px; background: #f8f9fa; border-left: 3px solid #007bff; }}
        .critical {{ border-left-color: #28a745; background: #d4edda; }}
        button {{ background: #007bff; color: white; padding: 15px 30px; border: none; border-radius: 5px; font-size: 18px; cursor: pointer; }}
        button:hover {{ background: #0056b3; }}
        .test-card {{ background: #fff3cd; padding: 15px; border-radius: 5px; margin: 20px 0; }}
    </style>
</head>
<body>
    <div class="container">
        <h1>🧪 Finalny Test Płatności Fiserv</h1>
        
        <div class="success">
            <h3>✅ Wszystkie parametry poprawne:</h3>
            <ul>
                <li>Timezone: Europe/Warsaw ✅</li>
                <li>Timestamp: {form_fields.get('txndatetime')} (czas warszawski) ✅</li>
                <li>Hash: Poprawnie obliczony ✅</li>
            </ul>
        </div>
        
        <h3>📋 Parametry transakcji:</h3>
        <div class="field critical">Order ID: {order_id}</div>
        <div class="field critical">Timezone: {form_fields.get('timezone')}</div>
        <div class="field critical">Timestamp: {form_fields.get('txndatetime')}</div>
        <div class="field">Kwota: {form_fields.get('chargetotal')} PLN</div>
        <div class="field">Store: {form_fields.get('storename')}</div>
        
        <div class="test-card">
            <h3>💳 Karta testowa:</h3>
            <strong>Numer:</strong> 4012 0010 3714 1112<br>
            <strong>Data:</strong> 12/26<br>
            <strong>CVV:</strong> 123
        </div>
        
        <form method="POST" action="{self.gateway_url}">
"""
        
        for key, value in form_fields.items():
            html += f'            <input type="hidden" name="{key}" value="{value}">\n'
        
        html += """
            <button type="submit">🚀 Wyślij do Fiserv</button>
        </form>
        
        <p style="margin-top: 30px; color: #666; font-size: 12px;">
            Wygenerowano: """ + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + """
        </p>
    </div>
</body>
</html>"""
        
        filename = f"final_test_{order_id}.html"
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(html)
        
        print(f"\n📄 HTML zapisany do: {filename}")
        return filename


async def run_final_test():
    """Uruchom finalny test z wszystkimi poprawkami"""
    
    print("="*70)
    print("FINALNY TEST PŁATNOŚCI FISERV")
    print("="*70)
    print("\n🎯 Test z wszystkimi odkryciami i poprawkami\n")
    
    tester = FiservFinalTest()
    
    # Stwórz formularz
    form_fields, order_id = tester.create_payment_form()
    
    # Test wysyłania
    success = await tester.test_submission(form_fields)
    
    # Generuj HTML
    html_file = tester.generate_html(form_fields, order_id)
    
    # Zapisz raport
    report = {
        'timestamp': datetime.now().isoformat(),
        'order_id': order_id,
        'timezone': form_fields.get('timezone'),
        'txndatetime': form_fields.get('txndatetime'),
        'success': success,
        'form_fields': dict(form_fields)
    }
    
    report_file = f"final_test_report_{order_id}.json"
    with open(report_file, 'w') as f:
        json.dump(report, f, indent=2)
    
    print(f"\n📊 Raport zapisany do: {report_file}")
    
    print("\n" + "="*70)
    print("PODSUMOWANIE")
    print("="*70)
    
    if success:
        print("\n✅ SUKCES! Płatność przeszła do strony Fiserv")
    else:
        print("\n❌ Nadal występuje błąd walidacji")
        print("\nMOŻLIWE PRZYCZYNY:")
        print("1. Konfiguracja konta - brak 'Allow URL override'")
        print("2. Nieprawidłowy shared secret")
        print("3. Domena ngrok jest blokowana")
        print("4. Konto testowe ma ograniczenia")
        
    print(f"\n🎯 Możesz też ręcznie przetestować otwierając: {html_file}")
    
    return success


if __name__ == "__main__":
    asyncio.run(run_final_test())