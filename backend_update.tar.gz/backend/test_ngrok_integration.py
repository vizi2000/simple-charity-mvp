#!/usr/bin/env python3
"""
Comprehensive test suite for Fiserv payment integration with ngrok
"""

import asyncio
import json
import httpx
from datetime import datetime
import time
import os
from typing import Dict, Any, List

# Configuration
BASE_URL = "http://localhost:8001"
NGROK_URL = os.getenv("WEBHOOK_BASE_URL", "https://77597ddbcc37.ngrok-free.app")

class PaymentIntegrationTester:
    def __init__(self):
        self.client = httpx.AsyncClient(base_url=BASE_URL, timeout=30.0)
        self.test_results = []
        self.payment_ids = []
        
    async def close(self):
        await self.client.aclose()
        
    def log_result(self, test_name: str, success: bool, details: str = "", data: Dict = None):
        result = {
            "test": test_name,
            "success": success,
            "details": details,
            "timestamp": datetime.utcnow().isoformat(),
            "data": data or {}
        }
        self.test_results.append(result)
        
        # Print result
        status = "✅ PASS" if success else "❌ FAIL"
        print(f"{status} - {test_name}")
        if details:
            print(f"    Details: {details}")
            
    async def test_ngrok_connectivity(self):
        """Test if ngrok is properly configured"""
        try:
            # Test local backend
            local_response = await self.client.get("/health")
            local_ok = local_response.status_code == 200
            
            # Test ngrok URL
            async with httpx.AsyncClient() as ngrok_client:
                ngrok_response = await ngrok_client.get(f"{NGROK_URL}/health")
                ngrok_ok = ngrok_response.status_code == 200
                
            self.log_result(
                "Ngrok Connectivity",
                local_ok and ngrok_ok,
                f"Local: {local_ok}, Ngrok: {ngrok_ok}, URL: {NGROK_URL}"
            )
            return ngrok_ok
            
        except Exception as e:
            self.log_result("Ngrok Connectivity", False, str(e))
            return False
            
    async def test_payment_with_webhook(self, payment_method: str = "card", amount: float = 50.00):
        """Test payment creation with public webhook URL"""
        test_name = f"Payment with Webhook - {payment_method.upper()}"
        
        try:
            # Create payment
            payment_data = {
                "goal_id": "church",
                "amount": amount,
                "donor_name": f"Test {payment_method}",
                "donor_email": f"{payment_method}@test.com",
                "payment_method": payment_method,
                "message": f"Test payment via {payment_method}"
            }
            
            response = await self.client.post(
                "/api/payments/initiate",
                json=payment_data,
                headers={"Content-Type": "application/json"}
            )
            
            if response.status_code == 200:
                result = response.json()
                payment_id = result.get("payment_id")
                self.payment_ids.append(payment_id)
                
                # Get form data
                form_response = await self.client.get(f"/api/payments/{payment_id}/form-data")
                form_data = form_response.json()
                
                # Check webhook URL
                webhook_url = form_data["form_fields"].get("transactionNotificationURL")
                has_public_webhook = webhook_url and "ngrok" in webhook_url
                
                self.log_result(
                    test_name,
                    True,
                    f"Payment ID: {payment_id}, Webhook: {webhook_url}",
                    {
                        "payment_id": payment_id,
                        "amount": amount,
                        "webhook_url": webhook_url,
                        "hash": form_data["form_fields"].get("hash", "")[:20] + "..."
                    }
                )
                
                return payment_id, form_data
            else:
                self.log_result(test_name, False, f"Status: {response.status_code}")
                return None, None
                
        except Exception as e:
            self.log_result(test_name, False, str(e))
            return None, None
            
    async def test_form_data_validation(self, payment_id: str):
        """Validate form data structure and content"""
        try:
            response = await self.client.get(f"/api/payments/{payment_id}/form-data")
            
            if response.status_code == 200:
                form_data = response.json()
                fields = form_data.get("form_fields", {})
                
                # Required fields
                required_fields = [
                    "storename", "txntype", "timezone", "txndatetime",
                    "chargetotal", "currency", "oid", "hash", "hash_algorithm"
                ]
                
                missing_fields = [f for f in required_fields if f not in fields]
                
                # Validate webhook URL
                webhook_url = fields.get("transactionNotificationURL", "")
                has_ngrok = "ngrok" in webhook_url or not webhook_url
                
                # Validate hash
                hash_valid = len(fields.get("hash", "")) > 20
                
                all_valid = not missing_fields and has_ngrok and hash_valid
                
                self.log_result(
                    f"Form Data Validation - {payment_id[:8]}",
                    all_valid,
                    f"Missing fields: {missing_fields}, Ngrok webhook: {has_ngrok}, Hash valid: {hash_valid}",
                    {
                        "form_action": form_data.get("form_action"),
                        "store_id": fields.get("storename"),
                        "amount": fields.get("chargetotal"),
                        "currency": fields.get("currency"),
                        "hash_length": len(fields.get("hash", ""))
                    }
                )
                
                return all_valid
            else:
                self.log_result(
                    f"Form Data Validation - {payment_id[:8]}",
                    False,
                    f"Status: {response.status_code}"
                )
                return False
                
        except Exception as e:
            self.log_result(f"Form Data Validation - {payment_id[:8]}", False, str(e))
            return False
            
    async def test_webhook_simulation(self, payment_id: str):
        """Simulate a webhook from Fiserv"""
        try:
            webhook_data = {
                "transactionId": f"FISERV-{payment_id[:8]}",
                "orderId": payment_id,
                "transactionStatus": "APPROVED",
                "amount": 50.00,
                "currency": "PLN",
                "timestamp": datetime.utcnow().isoformat(),
                "responseCode": "000",
                "responseMessage": "Approved"
            }
            
            # Send to ngrok URL
            async with httpx.AsyncClient() as webhook_client:
                response = await webhook_client.post(
                    f"{NGROK_URL}/api/webhooks/fiserv",
                    json=webhook_data,
                    headers={"Content-Type": "application/json"}
                )
                
                webhook_ok = response.status_code == 200
                
                # Check if payment status was updated
                await asyncio.sleep(1)  # Wait for processing
                
                status_response = await self.client.get(f"/api/payments/{payment_id}/status")
                if status_response.status_code == 200:
                    status_data = status_response.json()
                    status_updated = status_data.get("status") == "completed"
                else:
                    status_updated = False
                    
                self.log_result(
                    f"Webhook Simulation - {payment_id[:8]}",
                    webhook_ok,
                    f"Webhook response: {response.status_code}, Status updated: {status_updated}",
                    {
                        "webhook_url": f"{NGROK_URL}/api/webhooks/fiserv",
                        "response_code": response.status_code,
                        "payment_status": status_data.get("status") if status_response.status_code == 200 else "unknown"
                    }
                )
                
                return webhook_ok
                
        except Exception as e:
            self.log_result(f"Webhook Simulation - {payment_id[:8]}", False, str(e))
            return False
            
    async def test_payment_methods(self):
        """Test different payment methods"""
        methods = ["card", "blik"]
        results = []
        
        for method in methods:
            payment_id, form_data = await self.test_payment_with_webhook(method, 25.00)
            if payment_id and form_data:
                fields = form_data.get("form_fields", {})
                
                # Check method-specific fields
                if method == "blik":
                    has_blik = fields.get("blikPayment") == "true"
                    results.append(("BLIK fields", has_blik))
                    
                results.append((f"{method.upper()} payment", True))
            else:
                results.append((f"{method.upper()} payment", False))
                
        return results
        
    async def test_hash_calculation(self):
        """Test hash calculation consistency"""
        try:
            # Create two identical payments
            payment_data = {
                "goal_id": "church",
                "amount": 100.00,
                "donor_name": "Hash Test",
                "donor_email": "hash@test.com",
                "payment_method": "card"
            }
            
            # First payment
            resp1 = await self.client.post("/api/payments/initiate", json=payment_data, headers={"Content-Type": "application/json"})
            if resp1.status_code == 200:
                id1 = resp1.json()["payment_id"]
                form1 = await self.client.get(f"/api/payments/{id1}/form-data")
                hash1 = form1.json()["form_fields"]["hash"]
                
                # Second payment
                await asyncio.sleep(1)  # Different timestamp
                resp2 = await self.client.post("/api/payments/initiate", json=payment_data, headers={"Content-Type": "application/json"})
                if resp2.status_code == 200:
                    id2 = resp2.json()["payment_id"]
                    form2 = await self.client.get(f"/api/payments/{id2}/form-data")
                    hash2 = form2.json()["form_fields"]["hash"]
                    
                    # Hashes should be different (different timestamps and order IDs)
                    hashes_different = hash1 != hash2
                    
                    self.log_result(
                        "Hash Calculation Consistency",
                        hashes_different,
                        f"Hash 1: {hash1[:20]}..., Hash 2: {hash2[:20]}...",
                        {
                            "hash1_length": len(hash1),
                            "hash2_length": len(hash2),
                            "different": hashes_different
                        }
                    )
                    
                    return hashes_different
                    
        except Exception as e:
            self.log_result("Hash Calculation Consistency", False, str(e))
            return False
            
    async def test_error_handling(self):
        """Test error scenarios"""
        tests = [
            {
                "name": "Invalid Goal",
                "data": {"goal_id": "invalid", "amount": 50, "payment_method": "card"},
                "expected_status": 404
            },
            {
                "name": "Negative Amount",
                "data": {"goal_id": "church", "amount": -50, "payment_method": "card"},
                "expected_status": 422
            },
            {
                "name": "Zero Amount",
                "data": {"goal_id": "church", "amount": 0, "payment_method": "card"},
                "expected_status": 422
            }
        ]
        
        for test in tests:
            try:
                response = await self.client.post(
                    "/api/payments/initiate",
                    json=test["data"],
                    headers={"Content-Type": "application/json"}
                )
                
                success = response.status_code == test["expected_status"]
                
                self.log_result(
                    f"Error Handling - {test['name']}",
                    success,
                    f"Status: {response.status_code}, Expected: {test['expected_status']}"
                )
                
            except Exception as e:
                self.log_result(f"Error Handling - {test['name']}", False, str(e))
                
    async def run_all_tests(self):
        """Run comprehensive test suite"""
        print("\n" + "="*60)
        print("FISERV PAYMENT INTEGRATION TEST SUITE (WITH NGROK)")
        print("="*60)
        print(f"Backend URL: {BASE_URL}")
        print(f"Ngrok URL: {NGROK_URL}")
        print("="*60 + "\n")
        
        # 1. Test ngrok connectivity
        ngrok_ok = await self.test_ngrok_connectivity()
        
        if not ngrok_ok:
            print("\n⚠️  WARNING: Ngrok connectivity failed. Some tests may not work properly.")
            
        # 2. Test payment creation with webhook
        print("\n--- Testing Payment Creation ---")
        payment_id, form_data = await self.test_payment_with_webhook("card", 100.00)
        
        # 3. Validate form data
        if payment_id:
            print("\n--- Testing Form Data Validation ---")
            await self.test_form_data_validation(payment_id)
            
        # 4. Test webhook simulation
        if payment_id and ngrok_ok:
            print("\n--- Testing Webhook Handling ---")
            await self.test_webhook_simulation(payment_id)
            
        # 5. Test different payment methods
        print("\n--- Testing Payment Methods ---")
        await self.test_payment_methods()
        
        # 6. Test hash calculation
        print("\n--- Testing Hash Calculation ---")
        await self.test_hash_calculation()
        
        # 7. Test error handling
        print("\n--- Testing Error Handling ---")
        await self.test_error_handling()
        
        # Summary
        self.print_summary()
        
    def print_summary(self):
        """Print test summary"""
        print("\n" + "="*60)
        print("TEST SUMMARY")
        print("="*60)
        
        total_tests = len(self.test_results)
        passed_tests = sum(1 for r in self.test_results if r["success"])
        failed_tests = total_tests - passed_tests
        
        print(f"\nTotal Tests: {total_tests}")
        print(f"✅ Passed: {passed_tests}")
        print(f"❌ Failed: {failed_tests}")
        print(f"Success Rate: {(passed_tests/total_tests*100):.1f}%")
        
        # Ngrok status
        ngrok_test = next((r for r in self.test_results if "Ngrok" in r["test"]), None)
        if ngrok_test:
            print(f"\nNgrok Status: {'✅ Connected' if ngrok_test['success'] else '❌ Not Connected'}")
            
        # Payment IDs created
        if self.payment_ids:
            print(f"\nPayment IDs Created: {len(self.payment_ids)}")
            for pid in self.payment_ids[:3]:
                print(f"  - {pid}")
                
        # Failed tests details
        if failed_tests > 0:
            print("\nFailed Tests:")
            for result in self.test_results:
                if not result["success"]:
                    print(f"  - {result['test']}: {result['details']}")
                    
        # Save results
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"test_results_ngrok_{timestamp}.json"
        
        with open(filename, "w") as f:
            json.dump({
                "test_run": timestamp,
                "ngrok_url": NGROK_URL,
                "summary": {
                    "total": total_tests,
                    "passed": passed_tests,
                    "failed": failed_tests,
                    "success_rate": f"{(passed_tests/total_tests*100):.1f}%"
                },
                "results": self.test_results
            }, f, indent=2, default=str)
            
        print(f"\nDetailed results saved to: {filename}")
        print("\nNgrok dashboard: http://localhost:4040")


async def main():
    tester = PaymentIntegrationTester()
    try:
        await tester.run_all_tests()
    finally:
        await tester.close()


if __name__ == "__main__":
    asyncio.run(main())