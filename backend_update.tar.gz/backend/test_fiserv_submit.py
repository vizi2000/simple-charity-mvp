#!/usr/bin/env python3
"""
Test automatycznego wysłania formularza do Fiserv
"""

import httpx
import json
import sys
import os
from datetime import datetime
from zoneinfo import ZoneInfo

sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from app.utils.fiserv_ipg_client import FiservIPGClient

async def test_fiserv_submission():
    """Test wysłania formularza bezpośrednio do Fiserv"""
    
    print("="*60)
    print("TEST AUTOMATYCZNY FISERV")
    print("="*60)
    
    # Generuj dane
    test_order_id = f"AUTO-TEST-{datetime.now().strftime('%Y%m%d%H%M%S')}"
    
    print(f"\n📋 Generowanie formularza dla: {test_order_id}")
    
    client = FiservIPGClient()
    form_data = client.create_payment_form_data(
        amount=10.00,
        order_id=test_order_id,
        description="Automatyczny test płatności",
        success_url="https://charity.ngrok.app/success",
        failure_url="https://charity.ngrok.app/failure",
        notification_url="https://charity-webhook.ngrok.app/webhook",
        customer_info={
            "name": "Test Automatyczny",
            "email": "test@auto.com"
        }
    )
    
    fields = form_data['form_fields']
    gateway_url = form_data['form_action']
    
    print("\n✅ DANE FORMULARZA:")
    print(f"   Gateway URL: {gateway_url}")
    print(f"   Timezone: {fields.get('timezone')}")
    print(f"   Timestamp: {fields.get('txndatetime')}")
    print(f"   Store: {fields.get('storename')}")
    print(f"   Amount: {fields.get('chargetotal')} PLN")
    
    # Wyślij POST do Fiserv
    print("\n🚀 Wysyłanie do Fiserv...")
    
    async with httpx.AsyncClient(follow_redirects=False) as client:
        try:
            response = await client.post(
                gateway_url,
                data=fields,
                headers={
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36',
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'Accept-Language': 'pl-PL,pl;q=0.9,en;q=0.8',
                    'Origin': 'https://charity.ngrok.app',
                    'Referer': 'https://charity.ngrok.app/'
                }
            )
            
            print(f"\n📡 Status odpowiedzi: {response.status_code}")
            
            # Zapisz odpowiedź
            result_file = f"fiserv_response_{test_order_id}.json"
            with open(result_file, 'w') as f:
                json.dump({
                    "timestamp": datetime.now().isoformat(),
                    "order_id": test_order_id,
                    "status_code": response.status_code,
                    "headers": dict(response.headers),
                    "location": response.headers.get('location', ''),
                    "content_length": len(response.content),
                    "content_preview": response.text[:500] if response.text else ""
                }, f, indent=2)
            
            print(f"💾 Odpowiedź zapisana do: {result_file}")
            
            # Analiza odpowiedzi
            if response.status_code == 302 or response.status_code == 303:
                location = response.headers.get('location', '')
                print(f"\n✅ Przekierowanie do: {location[:100]}...")
                
                if 'error' in location.lower() or 'fail' in location.lower():
                    print("⚠️  Możliwy błąd - sprawdź URL przekierowania")
                elif 'payment' in location.lower() or 'checkout' in location.lower():
                    print("✅ Wygląda na poprawne przekierowanie do strony płatności")
                    
            elif response.status_code == 200:
                content = response.text
                
                # Sprawdź czy to strona płatności
                if 'payment' in content.lower() or 'card number' in content.lower():
                    print("✅ Otrzymano stronę płatności")
                    
                    # Zapisz HTML
                    html_file = f"fiserv_payment_page_{test_order_id}.html"
                    with open(html_file, 'w') as f:
                        f.write(content)
                    print(f"📄 Strona płatności zapisana do: {html_file}")
                    
                # Sprawdź błędy
                elif 'error' in content.lower() or 'błąd' in content.lower():
                    print("❌ Odpowiedź zawiera błąd")
                    
                    # Znajdź komunikat błędu
                    import re
                    error_patterns = [
                        r'<div[^>]*error[^>]*>(.*?)</div>',
                        r'<span[^>]*error[^>]*>(.*?)</span>',
                        r'Error: (.*?)<',
                        r'Błąd: (.*?)<'
                    ]
                    
                    for pattern in error_patterns:
                        matches = re.findall(pattern, content, re.IGNORECASE | re.DOTALL)
                        if matches:
                            print(f"   Komunikat: {matches[0][:200]}")
                            break
                            
            else:
                print(f"⚠️  Nieoczekiwany status: {response.status_code}")
                
            # Pokaż nagłówki diagnostyczne
            print("\n📊 NAGŁÓWKI ODPOWIEDZI:")
            for key in ['X-Error-Code', 'X-Error-Message', 'X-Transaction-Id']:
                if key.lower() in [h.lower() for h in response.headers.keys()]:
                    print(f"   {key}: {response.headers.get(key)}")
                    
        except Exception as e:
            print(f"\n❌ Błąd podczas wysyłania: {e}")
            return False
    
    print("\n" + "="*60)
    print("TEST ZAKOŃCZONY")
    print("="*60)
    
    # Podsumowanie
    warsaw_tz = ZoneInfo('Europe/Warsaw')
    print(f"\nPodsumowanie testu o {datetime.now(warsaw_tz).strftime('%H:%M:%S')} czasu warszawskiego:")
    print(f"  • Order ID: {test_order_id}")
    print(f"  • Timezone w żądaniu: {fields.get('timezone')}")
    print(f"  • Timestamp w żądaniu: {fields.get('txndatetime')}")
    print(f"  • Status odpowiedzi: {response.status_code}")
    
    return True

if __name__ == "__main__":
    import asyncio
    asyncio.run(test_fiserv_submission())