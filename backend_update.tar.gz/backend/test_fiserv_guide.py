#!/usr/bin/env python3
"""
Skrypt testowy dla implementacji Fiserv zgodnie z przewodnikiem
"""

import hashlib
import hmac
from datetime import datetime
import pytz
import requests
from urllib.parse import urlencode

# Konfiguracja z przewodnika
CONFIG = {
    "storename": "760995999",
    "shared_secret": "j}2W3P)Lwv",
    "gateway_url": "https://test.ipg-online.com/connect/gateway/processing",
}


def generate_hash(storename: str, txndatetime: str, chargetotal: str, currency: str, shared_secret: str) -> str:
    """Generuje hash zgodnie z dokumentacją"""
    # Ciąg do hashowania
    string_to_hash = f"{storename}{txndatetime}{chargetotal}{currency}{shared_secret}"
    
    print(f"\n1. Ciąg danych do hashowania:")
    print(f"   {string_to_hash}")
    
    # Konwertowanie shared_secret na hex
    secret_hex = shared_secret.encode('utf-8').hex()
    print(f"\n2. Shared secret w hex:")
    print(f"   {secret_hex}")
    
    # HMAC-SHA256
    hash_value = hmac.new(
        bytes.fromhex(secret_hex),
        string_to_hash.encode('utf-8'),
        hashlib.sha256
    ).hexdigest()
    
    print(f"\n3. Wygenerowany hash:")
    print(f"   {hash_value}")
    
    return hash_value


def test_hash_generation():
    """Test generowania hash z przykładowymi danymi"""
    print("="*60)
    print("TEST GENEROWANIA HASH")
    print("="*60)
    
    # Przykładowe dane
    warsaw_tz = pytz.timezone('Europe/Warsaw')
    now = datetime.now(warsaw_tz)
    txndatetime = now.strftime("%Y:%m:%d-%H:%M:%S")
    
    params = {
        "storename": CONFIG["storename"],
        "txndatetime": txndatetime,
        "chargetotal": "15.50",
        "currency": "985"
    }
    
    print(f"\nParametry testowe:")
    print(f"  storename: {params['storename']}")
    print(f"  txndatetime: {params['txndatetime']}")
    print(f"  chargetotal: {params['chargetotal']}")
    print(f"  currency: {params['currency']}")
    print(f"  shared_secret: {CONFIG['shared_secret']}")
    
    hash_value = generate_hash(
        params["storename"],
        params["txndatetime"],
        params["chargetotal"],
        params["currency"],
        CONFIG["shared_secret"]
    )
    
    return hash_value


def create_test_form():
    """Tworzy testowy formularz HTML"""
    print("\n" + "="*60)
    print("TWORZENIE FORMULARZA TESTOWEGO")
    print("="*60)
    
    # Generowanie parametrów
    warsaw_tz = pytz.timezone('Europe/Warsaw')
    now = datetime.now(warsaw_tz)
    txndatetime = now.strftime("%Y:%m:%d-%H:%M:%S")
    order_id = f"TEST-{now.strftime('%Y%m%d%H%M%S')}"
    
    params = {
        "txntype": "sale",
        "timezone": "Europe/Warsaw",
        "txndatetime": txndatetime,
        "hash_algorithm": "HMACSHA256",
        "storename": CONFIG["storename"],
        "chargetotal": "10.00",
        "currency": "985",
        "oid": order_id,
        "responseSuccessURL": "https://example.com/success",
        "responseFailURL": "https://example.com/fail",
        "transactionNotificationURL": "https://example.com/notify"
    }
    
    # Generowanie hash
    hash_value = generate_hash(
        params["storename"],
        params["txndatetime"],
        params["chargetotal"],
        params["currency"],
        CONFIG["shared_secret"]
    )
    params["hash"] = hash_value
    
    print(f"\nParametry formularza:")
    for key, value in params.items():
        print(f"  {key}: {value}")
    
    # Tworzenie HTML
    form_fields = "\\n    ".join([
        f'<input type="hidden" name="{key}" value="{value}">'
        for key, value in params.items()
    ])
    
    html = f"""<!DOCTYPE html>
<html>
<head>
    <title>Test Fiserv Payment</title>
    <meta charset="UTF-8">
    <style>
        body {{
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background: #f5f5f5;
        }}
        .container {{
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }}
        h1 {{
            color: #333;
        }}
        .params {{
            background: #f9f9f9;
            padding: 15px;
            border-radius: 5px;
            margin: 20px 0;
            font-family: monospace;
            font-size: 12px;
        }}
        button {{
            background: #4CAF50;
            color: white;
            padding: 15px 30px;
            border: none;
            border-radius: 5px;
            font-size: 18px;
            cursor: pointer;
        }}
        button:hover {{
            background: #45a049;
        }}
        .info {{
            background: #e3f2fd;
            padding: 15px;
            border-radius: 5px;
            margin-top: 20px;
        }}
    </style>
</head>
<body>
    <div class="container">
        <h1>Test Płatności Fiserv</h1>
        
        <div class="info">
            <h3>Dane testowe:</h3>
            <p><strong>Store ID:</strong> {params['storename']}</p>
            <p><strong>Order ID:</strong> {params['oid']}</p>
            <p><strong>Kwota:</strong> {params['chargetotal']} PLN</p>
            <p><strong>Data/czas:</strong> {params['txndatetime']}</p>
        </div>
        
        <div class="params">
            <h3>Parametry wysyłane do Fiserv:</h3>
            <pre>{json.dumps(params, indent=2)}</pre>
        </div>
        
        <form action="{CONFIG['gateway_url']}" method="POST">
    {form_fields}
            <button type="submit">Przejdź do bramki płatniczej Fiserv</button>
        </form>
        
        <div class="info" style="background: #fff3e0;">
            <h3>Karty testowe:</h3>
            <p><strong>DEBIT (APPROVED):</strong> 4410947715337430, 12/26, CVV: 287</p>
            <p><strong>CREDIT (DECLINED):</strong> 5575233623260024, 12/26, CVV: 123</p>
            <p><strong>BLIK (APPROVED):</strong> 777777</p>
        </div>
    </div>
</body>
</html>"""
    
    # Zapisz do pliku
    filename = f"test_form_{order_id}.html"
    with open(filename, "w", encoding="utf-8") as f:
        f.write(html)
    
    print(f"\n✅ Formularz testowy zapisany jako: {filename}")
    print(f"   Otwórz ten plik w przeglądarce i kliknij przycisk aby przetestować płatność")
    
    return filename


def verify_hash_with_example():
    """Weryfikuje hash z przykładem z dokumentacji"""
    print("\n" + "="*60)
    print("WERYFIKACJA Z PRZYKŁADEM Z PRZEWODNIKA")
    print("="*60)
    
    # Przykład z przewodnika
    example = {
        "storename": "760995999",
        "txndatetime": "2025:08:10-11:44:00",
        "chargetotal": "15.50",
        "currency": "985",
        "shared_secret": "j}2W3P)Lwv"
    }
    
    print(f"\nPrzykład z przewodnika:")
    print(f"  Ciąg: 7609959992025:08:10-11:44:0015.50985j}}2W3P)Lwv")
    
    hash_value = generate_hash(
        example["storename"],
        example["txndatetime"],
        example["chargetotal"],
        example["currency"],
        example["shared_secret"]
    )
    
    print(f"\n✅ Hash wygenerowany pomyślnie")


if __name__ == "__main__":
    import json
    
    print("TESTY IMPLEMENTACJI FISERV/POLCARD")
    print("="*60)
    
    # Test 1: Weryfikacja z przykładem
    verify_hash_with_example()
    
    # Test 2: Generowanie hash z aktualnymi danymi
    test_hash_generation()
    
    # Test 3: Tworzenie formularza testowego
    form_file = create_test_form()
    
    print("\n" + "="*60)
    print("NASTĘPNE KROKI:")
    print("="*60)
    print("1. Uruchom serwer: python fiserv_simple.py")
    print("2. Otwórz http://localhost:8001 w przeglądarce")
    print(f"3. Lub otwórz wygenerowany formularz: {form_file}")
    print("4. Przetestuj płatność używając kart testowych")
    print("\n⚠️  Upewnij się, że adresy URL zwrotne są dostępne z internetu!")
    print("   Możesz użyć ngrok: ngrok http 8001")