#!/usr/bin/env python3
"""
Test desperacki - może hash nie jest wymagany w testach?
"""

import os
from datetime import datetime
from app.utils.fiserv_ipg_client import FiservIPGClient
import webbrowser

def test_without_hash():
    """Test bez hash - może nie jest wymagany?"""
    
    print("="*60)
    print("TEST BEZ HASH")
    print("="*60)
    
    client = FiservIPGClient()
    
    # HTML
    html = f"""<!DOCTYPE html>
<html>
<head>
    <title>Test Bez Hash</title>
    <style>
        body {{ 
            font-family: Arial, sans-serif; 
            max-width: 1200px; 
            margin: 20px auto; 
            padding: 20px;
            background: #f5f5f5;
        }}
        .test-section {{
            background: white;
            padding: 20px;
            margin: 15px 0;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }}
        .warning {{
            background: #fff3cd;
            border: 2px solid #ffc107;
            padding: 15px;
            margin: 20px 0;
        }}
        button {{
            background: #dc3545;
            color: white;
            border: none;
            padding: 12px 24px;
            margin: 5px;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
        }}
        button:hover {{ background: #c82333; }}
    </style>
</head>
<body>
    <h1>🔍 Test Desperacki - Bez Hash</h1>
    
    <div class="warning">
        <h3>⚠️ Test ostatniej szansy:</h3>
        <p>Może w środowisku testowym hash nie jest wymagany?</p>
        <p>Albo jest obliczany automatycznie?</p>
    </div>
"""
    
    # Test 1: Bez hash w ogóle - Combined Page
    html += """
    <div class="test-section">
        <h3>Test 1: Combined Page - Bez Hash</h3>
        <form method="POST" action="{}" target="_blank">
            <input type="hidden" name="storename" value="760995999">
            <input type="hidden" name="txntype" value="sale">
            <input type="hidden" name="chargetotal" value="10.00">
            <input type="hidden" name="currency" value="985">
            <input type="hidden" name="checkoutoption" value="combinedpage">
            <input type="hidden" name="oid" value="NO-HASH-COMBINED-{}">
            <button type="submit">Test Combined Page BEZ HASH</button>
        </form>
    </div>
""".format(client.gateway_url, datetime.now().strftime("%Y%m%d%H%M%S"))
    
    # Test 2: Bez hash - Classic
    html += """
    <div class="test-section">
        <h3>Test 2: Classic - Bez Hash</h3>
        <form method="POST" action="{}" target="_blank">
            <input type="hidden" name="storename" value="760995999">
            <input type="hidden" name="txntype" value="sale">
            <input type="hidden" name="chargetotal" value="10.00">
            <input type="hidden" name="currency" value="985">
            <input type="hidden" name="checkoutoption" value="classic">
            <input type="hidden" name="oid" value="NO-HASH-CLASSIC-{}">
            <button type="submit">Test Classic BEZ HASH</button>
        </form>
    </div>
""".format(client.gateway_url, datetime.now().strftime("%Y%m%d%H%M%S"))
    
    # Test 3: Minimalne pola
    html += """
    <div class="test-section">
        <h3>Test 3: Absolutne Minimum - Bez Hash</h3>
        <form method="POST" action="{}" target="_blank">
            <input type="hidden" name="storename" value="760995999">
            <input type="hidden" name="chargetotal" value="10.00">
            <button type="submit">Test MINIMUM BEZ HASH</button>
        </form>
    </div>
""".format(client.gateway_url)
    
    # Test 4: Z pustym hashem
    html += """
    <div class="test-section">
        <h3>Test 4: Z Pustym Hash</h3>
        <form method="POST" action="{}" target="_blank">
            <input type="hidden" name="storename" value="760995999">
            <input type="hidden" name="txntype" value="sale">
            <input type="hidden" name="chargetotal" value="10.00">
            <input type="hidden" name="currency" value="985">
            <input type="hidden" name="checkoutoption" value="combinedpage">
            <input type="hidden" name="oid" value="EMPTY-HASH-{}">
            <input type="hidden" name="hash_algorithm" value="HMACSHA256">
            <input type="hidden" name="hashExtended" value="">
            <button type="submit">Test z PUSTYM HASH</button>
        </form>
    </div>
""".format(client.gateway_url, datetime.now().strftime("%Y%m%d%H%M%S"))
    
    # Info
    html += """
    <div class="warning">
        <h3>📝 Co może się stać:</h3>
        <ul>
            <li><strong>Zadziała</strong> - hash nie jest wymagany w testach</li>
            <li><strong>Inny błąd</strong> - może wskaże na problem</li>
            <li><strong>Ten sam błąd</strong> - hash jest wymagany</li>
        </ul>
        
        <h3>🔍 Gdzie jeszcze szukać Shared Secret:</h3>
        <ul>
            <li>Email powitalny od Fiserv</li>
            <li>Dokumentacja PDF którą masz</li>
            <li>Kontakt z osobą która zakładała konto</li>
            <li>Support Fiserv - tylko oni mogą zresetować/podać secret</li>
        </ul>
    </div>
</body>
</html>"""
    
    filename = "test_without_hash.html"
    with open(filename, 'w') as f:
        f.write(html)
    
    print(f"\n✅ Test zapisany jako: {filename}")
    print("\n🎯 Test ostatniej szansy - może hash nie jest wymagany?")
    
    # Otwórz w przeglądarce
    webbrowser.open(f"file://{os.path.abspath(filename)}")

if __name__ == "__main__":
    test_without_hash()