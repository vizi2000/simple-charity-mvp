#!/usr/bin/env python3
"""
End-to-end test that simulates the complete payment flow
"""

import asyncio
import httpx
import json
from datetime import datetime

# Configuration
BASE_URL = "http://localhost:8001"

async def test_complete_payment_flow():
    """Test the complete payment flow from start to finish"""
    
    async with httpx.AsyncClient(base_url=BASE_URL) as client:
        print("\n" + "="*60)
        print("END-TO-END PAYMENT FLOW TEST")
        print("="*60 + "\n")
        
        # Step 1: Get organization info
        print("1. Getting organization information...")
        org_response = await client.get("/api/organization")
        assert org_response.status_code == 200
        org_data = org_response.json()
        print(f"   ✅ Organization: {org_data['name']}")
        print(f"   ✅ Location: {org_data['location']}")
        
        # Step 2: Get specific goal
        print("\n2. Getting goal information...")
        goal_response = await client.get("/api/organization/goal/church")
        assert goal_response.status_code == 200
        goal_data = goal_response.json()
        print(f"   ✅ Goal: {goal_data['name']}")
        print(f"   ✅ Target: {goal_data['target_amount']} PLN")
        print(f"   ✅ Collected: {goal_data['collected_amount']} PLN")
        
        # Step 3: Initiate payment
        print("\n3. Initiating payment...")
        payment_data = {
            "goal_id": "church",
            "amount": 100.00,
            "donor_name": "Test E2E User",
            "donor_email": "e2e@test.com",
            "payment_method": "card",
            "message": "E2E test donation"
        }
        
        payment_response = await client.post(
            "/api/payments/initiate",
            json=payment_data,
            headers={"Content-Type": "application/json"}
        )
        assert payment_response.status_code == 200
        payment_result = payment_response.json()
        payment_id = payment_result["payment_id"]
        print(f"   ✅ Payment ID: {payment_id}")
        print(f"   ✅ Amount: {payment_result['amount']} PLN")
        print(f"   ✅ Goal: {payment_result['goal']}")
        
        # Step 4: Get form data for Fiserv
        print("\n4. Getting Fiserv form data...")
        form_response = await client.get(f"/api/payments/{payment_id}/form-data")
        assert form_response.status_code == 200
        form_data = form_response.json()
        print(f"   ✅ Form action: {form_data['form_action']}")
        print(f"   ✅ Store ID: {form_data['form_fields']['storename']}")
        print(f"   ✅ Transaction type: {form_data['form_fields']['txntype']}")
        print(f"   ✅ Amount: {form_data['form_fields']['chargetotal']} PLN")
        print(f"   ✅ Hash: {form_data['form_fields']['hash'][:20]}...")
        
        # Step 5: Simulate form submission (show what would be sent)
        print("\n5. Form data that would be submitted to Fiserv:")
        print("   Form fields:")
        for key, value in sorted(form_data['form_fields'].items()):
            if key in ['hash', 'responseSuccessURL', 'responseFailURL', 'transactionNotificationURL']:
                print(f"     - {key}: {value[:50]}...")
            else:
                print(f"     - {key}: {value}")
                
        # Step 6: Check payment status
        print("\n6. Checking payment status...")
        status_response = await client.get(f"/api/payments/{payment_id}/status")
        assert status_response.status_code == 200
        status_data = status_response.json()
        print(f"   ✅ Status: {status_data['status']}")
        print(f"   ✅ Amount: {status_data['amount']} PLN")
        
        # Step 7: Simulate webhook from Fiserv
        print("\n7. Simulating webhook from Fiserv...")
        webhook_data = {
            "transactionId": f"FISERV-{payment_id[:8]}",
            "orderId": payment_id,
            "transactionStatus": "APPROVED",
            "amount": 100.00,
            "currency": "PLN",
            "timestamp": datetime.utcnow().isoformat()
        }
        
        webhook_response = await client.post(
            "/api/webhooks/fiserv",
            json=webhook_data,
            headers={"Content-Type": "application/json"}
        )
        print(f"   ✅ Webhook response: {webhook_response.status_code}")
        
        # Step 8: Process mock payment (for testing)
        print("\n8. Processing mock payment...")
        mock_response = await client.post(
            f"/api/payments/{payment_id}/process-mock",
            json={"payment_method": "card"},
            headers={"Content-Type": "application/json"}
        )
        assert mock_response.status_code == 200
        mock_result = mock_response.json()
        print(f"   ✅ Mock processing: {mock_result['status']}")
        
        # Step 9: Final status check
        print("\n9. Final payment status check...")
        final_status_response = await client.get(f"/api/payments/{payment_id}/status")
        assert final_status_response.status_code == 200
        final_status = final_status_response.json()
        print(f"   ✅ Final status: {final_status['status']}")
        
        # Step 10: Verify goal update
        print("\n10. Verifying goal amount was updated...")
        updated_goal_response = await client.get("/api/organization/goal/church")
        assert updated_goal_response.status_code == 200
        updated_goal = updated_goal_response.json()
        print(f"   ✅ New collected amount: {updated_goal['collected_amount']} PLN")
        
        print("\n" + "="*60)
        print("✅ E2E TEST COMPLETED SUCCESSFULLY!")
        print("="*60 + "\n")
        
        # Summary
        print("PAYMENT FLOW SUMMARY:")
        print(f"1. Payment initiated with ID: {payment_id}")
        print(f"2. Form data generated with hash authentication")
        print(f"3. Payment would be submitted to: {form_data['form_action']}")
        print(f"4. Success URL: {form_data['form_fields']['responseSuccessURL']}")
        print(f"5. Webhook URL: {form_data['form_fields']['transactionNotificationURL']}")
        print(f"6. Payment processed successfully (mock)")
        
        # Test different payment methods
        print("\n\nTESTING OTHER PAYMENT METHODS:")
        
        # Test BLIK
        print("\n- Testing BLIK payment...")
        blik_payment = await client.post(
            "/api/payments/initiate",
            json={
                "goal_id": "poor",
                "amount": 50.00,
                "payment_method": "blik",
                "donor_name": "BLIK Test"
            },
            headers={"Content-Type": "application/json"}
        )
        if blik_payment.status_code == 200:
            blik_result = blik_payment.json()
            blik_form = await client.get(f"/api/payments/{blik_result['payment_id']}/form-data")
            blik_form_data = blik_form.json()
            print(f"  ✅ BLIK payment initiated: {blik_result['payment_id']}")
            print(f"  ✅ BLIK mode: {blik_form_data['form_fields'].get('blikPayment', 'Not set')}")
        
        print("\n✅ ALL TESTS COMPLETED!\n")


if __name__ == "__main__":
    asyncio.run(test_complete_payment_flow())