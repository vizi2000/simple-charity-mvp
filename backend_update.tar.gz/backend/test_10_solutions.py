#!/usr/bin/env python3
"""
Test 10 różnych rozwiązań problemu z Fiserv
"""

import requests
from datetime import datetime
from zoneinfo import ZoneInfo
import hmac
import hashlib
import base64
from collections import OrderedDict
import time
import urllib.parse

class FiservMultiSolutionTester:
    def __init__(self):
        self.gateway_url = "https://test.ipg-online.com/connect/gateway/processing"
        self.base_store_id = "760995999"
        self.base_secret = "j}2W3P)Lwv"
        self.results = []
        
    def get_warsaw_timestamp(self):
        """Generuj timestamp warszawski"""
        warsaw_tz = ZoneInfo("Europe/Warsaw")
        now_warsaw = datetime.now(warsaw_tz)
        return now_warsaw.strftime("%Y:%m:%d-%H:%M:%S")
    
    def calculate_hash(self, fields, secret, method='standard'):
        """Różne metody obliczania hasha"""
        exclude = {'hash_algorithm', 'hashExtended', 'hash'}
        fields_for_hash = {k: v for k, v in fields.items() if k not in exclude and v}
        sorted_fields = OrderedDict(sorted(fields_for_hash.items()))
        
        if method == 'standard':
            # Metoda 1: Tylko wartości
            hash_string = '|'.join(str(v) for v in sorted_fields.values())
        elif method == 'with_keys':
            # Metoda 2: klucz=wartość
            hash_string = '|'.join(f"{k}={v}" for k, v in sorted_fields.items())
        elif method == 'key_value_separate':
            # Metoda 3: klucz|wartość
            parts = []
            for k, v in sorted_fields.items():
                parts.extend([k, v])
            hash_string = '|'.join(str(p) for p in parts)
        elif method == 'with_secret_suffix':
            # Metoda 4: Z secret na końcu
            hash_string = '|'.join(str(v) for v in sorted_fields.values()) + '|' + secret
            secret = ''  # Nie używaj secret w HMAC
        else:
            hash_string = '|'.join(str(v) for v in sorted_fields.values())
        
        # Generuj hash
        if secret:
            hash_bytes = hmac.new(
                secret.encode('utf-8'),
                hash_string.encode('utf-8'),
                hashlib.sha256
            ).digest()
        else:
            hash_bytes = hashlib.sha256(hash_string.encode('utf-8')).digest()
        
        return base64.b64encode(hash_bytes).decode('utf-8')
    
    def test_solution(self, test_num, name, form_fields, description=""):
        """Test pojedynczego rozwiązania"""
        print(f"\n{'='*60}")
        print(f"TEST #{test_num}: {name}")
        print(f"{'='*60}")
        if description:
            print(f"📝 {description}")
        
        # Wyświetl kluczowe parametry
        print(f"🔑 Store: {form_fields.get('storename', 'N/A')}")
        print(f"🔐 Hash: {form_fields.get('hashExtended', 'N/A')[:30]}...")
        
        try:
            response = requests.post(
                self.gateway_url,
                data=form_fields,
                headers={'Content-Type': 'application/x-www-form-urlencoded'},
                allow_redirects=False,
                timeout=10
            )
            
            success = False
            location = response.headers.get('location', '')
            
            if response.status_code in [302, 303]:
                if 'validationError' not in location:
                    success = True
                    print(f"✅ SUKCES! Przekierowanie bez błędu")
                else:
                    print(f"❌ Błąd walidacji")
            else:
                print(f"⚠️ Status: {response.status_code}")
            
            self.results.append({
                'test': test_num,
                'name': name,
                'success': success,
                'status': response.status_code,
                'details': description
            })
            
            return success
            
        except Exception as e:
            print(f"❌ Błąd: {e}")
            self.results.append({
                'test': test_num,
                'name': name,
                'success': False,
                'error': str(e)
            })
            return False
    
    def run_all_tests(self):
        """Uruchom wszystkie 10 testów"""
        
        print("🚀 ROZPOCZYNAM TESTY 10 RÓŻNYCH ROZWIĄZAŃ")
        print("="*60)
        
        # TEST 1: Różne warianty shared secret
        print("\n" + "="*60)
        print("GRUPA 1: WARIANTY SHARED SECRET")
        print("="*60)
        
        secrets = [
            ("Oryginalny", "j}2W3P)Lwv"),
            ("URL encoded", "j%7D2W3P%29Lwv"),
            ("Bez znaków specjalnych", "j2W3PLwv"),
            ("Escaped backslash", "j\\}2W3P\\)Lwv")
        ]
        
        for idx, (desc, secret) in enumerate(secrets, 1):
            timestamp = self.get_warsaw_timestamp()
            fields = OrderedDict([
                ('storename', self.base_store_id),
                ('txntype', 'sale'),
                ('timezone', 'Europe/Warsaw'),
                ('txndatetime', timestamp),
                ('hash_algorithm', 'HMACSHA256'),
                ('chargetotal', '10.00'),
                ('currency', '985'),
                ('checkoutoption', 'combinedpage')
            ])
            
            fields['hashExtended'] = self.calculate_hash(fields, secret)
            
            if self.test_solution(idx, f"Secret: {desc}", fields, f"Testowanie secret: {secret}"):
                print("🎉 ZNALEZIONO DZIAŁAJĄCE ROZWIĄZANIE!")
                break
        
        # TEST 2: Różne algorytmy hasha
        print("\n" + "="*60)
        print("GRUPA 2: RÓŻNE ALGORYTMY HASHA")
        print("="*60)
        
        timestamp = self.get_warsaw_timestamp()
        
        # SHA1
        fields = OrderedDict([
            ('storename', self.base_store_id),
            ('txntype', 'sale'),
            ('timezone', 'Europe/Warsaw'),
            ('txndatetime', timestamp),
            ('hash_algorithm', 'HMACSHA1'),
            ('chargetotal', '10.00'),
            ('currency', '985'),
            ('checkoutoption', 'combinedpage')
        ])
        
        # Dla SHA1
        sorted_fields = OrderedDict(sorted(fields.items()))
        hash_string = '|'.join(str(v) for v in sorted_fields.values() if v)
        hash_bytes = hmac.new(
            self.base_secret.encode('utf-8'),
            hash_string.encode('utf-8'),
            hashlib.sha1
        ).digest()
        fields['hashExtended'] = base64.b64encode(hash_bytes).decode('utf-8')
        
        self.test_solution(5, "Algorytm SHA1", fields, "Używanie HMACSHA1 zamiast SHA256")
        
        # TEST 3: Różne metody generowania hash string
        print("\n" + "="*60)
        print("GRUPA 3: METODY GENEROWANIA HASH STRING")
        print("="*60)
        
        methods = [
            ('with_keys', 'Format: klucz=wartość'),
            ('key_value_separate', 'Format: klucz|wartość'),
            ('with_secret_suffix', 'Secret na końcu stringa')
        ]
        
        for idx, (method, desc) in enumerate(methods, 6):
            timestamp = self.get_warsaw_timestamp()
            fields = OrderedDict([
                ('storename', self.base_store_id),
                ('txntype', 'sale'),
                ('timezone', 'Europe/Warsaw'),
                ('txndatetime', timestamp),
                ('hash_algorithm', 'HMACSHA256'),
                ('chargetotal', '10.00'),
                ('currency', '985'),
                ('checkoutoption', 'combinedpage')
            ])
            
            fields['hashExtended'] = self.calculate_hash(fields, self.base_secret, method)
            
            if self.test_solution(idx, f"Hash method: {method}", fields, desc):
                print("🎉 ZNALEZIONO DZIAŁAJĄCE ROZWIĄZANIE!")
                break
        
        # TEST 4: Dodatkowe pola
        print("\n" + "="*60)
        print("GRUPA 4: DODATKOWE POLA")
        print("="*60)
        
        timestamp = self.get_warsaw_timestamp()
        fields = OrderedDict([
            ('storename', self.base_store_id),
            ('txntype', 'sale'),
            ('timezone', 'Europe/Warsaw'),
            ('txndatetime', timestamp),
            ('hash_algorithm', 'HMACSHA256'),
            ('chargetotal', '10.00'),
            ('currency', '985'),
            ('checkoutoption', 'combinedpage'),
            ('language', 'pl_PL'),
            ('customerid', 'CUST001'),
            ('invoicenumber', 'INV001')
        ])
        
        fields['hashExtended'] = self.calculate_hash(fields, self.base_secret)
        
        self.test_solution(9, "Z dodatkowymi polami", fields, "Dodano language, customerid, invoicenumber")
        
        # TEST 5: Inna kolejność pól
        print("\n" + "="*60)
        print("GRUPA 5: INNA KOLEJNOŚĆ PÓL")
        print("="*60)
        
        timestamp = self.get_warsaw_timestamp()
        fields = OrderedDict([
            ('txntype', 'sale'),
            ('storename', self.base_store_id),  # Store jako drugie
            ('chargetotal', '10.00'),
            ('currency', '985'),
            ('timezone', 'Europe/Warsaw'),
            ('txndatetime', timestamp),
            ('hash_algorithm', 'HMACSHA256'),
            ('checkoutoption', 'combinedpage')
        ])
        
        fields['hashExtended'] = self.calculate_hash(fields, self.base_secret)
        
        self.test_solution(10, "Zmieniona kolejność pól", fields, "Store jako drugie pole, amount jako trzecie")
        
        # PODSUMOWANIE
        print("\n" + "="*60)
        print("📊 PODSUMOWANIE TESTÓW")
        print("="*60)
        
        successful = [r for r in self.results if r.get('success')]
        failed = [r for r in self.results if not r.get('success')]
        
        print(f"\n✅ Udane: {len(successful)}")
        print(f"❌ Nieudane: {len(failed)}")
        
        if successful:
            print("\n🎉 DZIAŁAJĄCE ROZWIĄZANIA:")
            for r in successful:
                print(f"   - Test #{r['test']}: {r['name']}")
        else:
            print("\n⚠️ Żadne rozwiązanie nie zadziałało.")
            print("Prawdopodobne przyczyny:")
            print("1. Nieprawidłowy shared secret")
            print("2. Nieaktywne konto testowe")
            print("3. Brak konfiguracji store ID")
            print("\n📞 KONIECZNY KONTAKT Z FISERV SUPPORT")
        
        return successful

if __name__ == "__main__":
    tester = FiservMultiSolutionTester()
    successful = tester.run_all_tests()
    
    # Zapisz raport
    import json
    with open('test_10_solutions_report.json', 'w') as f:
        json.dump(tester.results, f, indent=2)
    
    print(f"\n💾 Raport zapisany do: test_10_solutions_report.json")