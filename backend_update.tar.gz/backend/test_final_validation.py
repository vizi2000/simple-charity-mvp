#!/usr/bin/env python3
"""
Ostateczna walidacja płatności Fiserv z dokładnym logowaniem
"""

import sys
import os
from datetime import datetime
from zoneinfo import ZoneInfo
import json

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from app.utils.fiserv_ipg_client import fiserv_ipg_client

def validate_payment():
    """Dokładna walidacja generowania danych płatności"""
    
    print("="*70)
    print("OSTATECZNA WALIDACJA INTEGRACJI FISERV")
    print("="*70)
    
    # Aktualne dane czasowe Warsaw
    warsaw_tz = ZoneInfo('Europe/Warsaw')
    now = datetime.now(warsaw_tz)
    
    print(f"\n1. WERYFIKACJA STREFY CZASOWEJ:")
    print(f"   Aktualna data/czas Warsaw: {now.strftime('%Y-%m-%d %H:%M:%S %Z')}")
    print(f"   Format dla Fiserv: {now.strftime('%Y:%m:%d-%H:%M:%S')}")
    
    # Generuj dane płatności
    print(f"\n2. GENEROWANIE DANYCH PŁATNOŚCI:")
    
    result = fiserv_ipg_client.create_payment_form_data(
        amount=50.00,
        order_id=f'FINAL-TEST-{datetime.now().strftime("%Y%m%d%H%M%S")}',
        description='Ostateczny test integracji',
        success_url='https://charity.ngrok.app/platnosc/final/success',
        failure_url='https://charity.ngrok.app/platnosc/final/failure',
        notification_url='https://charity-webhook.ngrok.app/api/webhooks/fiserv',
        customer_info={
            'name': 'Final Test User',
            'email': 'final@test.com'
        }
    )
    
    form_fields = result['form_fields']
    
    print(f"\n3. WYGENEROWANE POLA FORMULARZA:")
    critical_fields = [
        'storename', 'timezone', 'txndatetime', 'chargetotal', 
        'currency', 'checkoutoption', 'oid', 'hashExtended'
    ]
    
    for field in critical_fields:
        value = form_fields.get(field, 'BRAK')
        if field == 'hashExtended':
            value = value[:30] + '...' if value != 'BRAK' else 'BRAK'
        print(f"   {field:20s}: {value}")
    
    # Walidacja krytycznych pól
    print(f"\n4. WALIDACJA KRYTYCZNYCH WYMAGAŃ:")
    
    checks = []
    
    # Sprawdź timezone
    if form_fields.get('timezone') == 'Europe/Warsaw':
        print("   ✓ Timezone: Europe/Warsaw (POPRAWNE)")
        checks.append(True)
    else:
        print(f"   ✗ Timezone: {form_fields.get('timezone')} (BŁĄD - powinno być Europe/Warsaw)")
        checks.append(False)
    
    # Sprawdź format timestamp
    txndatetime = form_fields.get('txndatetime', '')
    if txndatetime and ':' in txndatetime and '-' in txndatetime:
        try:
            # Parsuj timestamp
            date_part, time_part = txndatetime.split('-')
            year, month, day = date_part.split(':')
            hour, minute, second = time_part.split(':')
            
            # Sprawdź czy jest aktualny
            dt = datetime(int(year), int(month), int(day), 
                         int(hour), int(minute), int(second))
            
            time_diff = abs((now.replace(tzinfo=None) - dt).total_seconds())
            
            if time_diff < 60:
                print(f"   ✓ Timestamp: {txndatetime} (aktualny, różnica {time_diff:.1f}s)")
                checks.append(True)
            else:
                print(f"   ✗ Timestamp: {txndatetime} (nieaktualny, różnica {time_diff:.1f}s)")
                checks.append(False)
        except:
            print(f"   ✗ Timestamp: {txndatetime} (nieprawidłowy format)")
            checks.append(False)
    else:
        print(f"   ✗ Timestamp: {txndatetime} (brak lub błędny)")
        checks.append(False)
    
    # Sprawdź store ID
    if form_fields.get('storename') == '760995999':
        print("   ✓ Store ID: 760995999 (POPRAWNE)")
        checks.append(True)
    else:
        print(f"   ✗ Store ID: {form_fields.get('storename')} (BŁĄD)")
        checks.append(False)
    
    # Sprawdź walutę
    if form_fields.get('currency') == '985':
        print("   ✓ Currency: 985 PLN (POPRAWNE)")
        checks.append(True)
    else:
        print(f"   ✗ Currency: {form_fields.get('currency')} (BŁĄD)")
        checks.append(False)
    
    # Sprawdź hash
    if form_fields.get('hashExtended'):
        print(f"   ✓ Hash: wygenerowany ({len(form_fields['hashExtended'])} znaków)")
        checks.append(True)
    else:
        print("   ✗ Hash: BRAK")
        checks.append(False)
    
    # Podsumowanie
    print(f"\n5. WYNIK WALIDACJI:")
    passed = sum(checks)
    total = len(checks)
    
    if passed == total:
        print(f"   ✅ WSZYSTKIE TESTY ZALICZONE ({passed}/{total})")
        print("\n   Integracja z Fiserv jest POPRAWNA!")
        print("   Możesz przystąpić do testów produkcyjnych.")
    else:
        print(f"   ⚠️  NIEKTÓRE TESTY NIE PRZESZŁY ({passed}/{total})")
        print("\n   Sprawdź błędy powyżej i popraw konfigurację.")
    
    # Zapisz pełne dane do pliku
    output_file = f"validation_result_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump({
            'timestamp': now.isoformat(),
            'form_fields': form_fields,
            'validation_passed': passed == total,
            'checks_passed': f"{passed}/{total}"
        }, f, indent=2, ensure_ascii=False)
    
    print(f"\n   Pełne wyniki zapisane do: {output_file}")
    
    return passed == total

if __name__ == "__main__":
    success = validate_payment()
    sys.exit(0 if success else 1)