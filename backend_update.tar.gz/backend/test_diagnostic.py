#!/usr/bin/env python3
"""
Test diagnostyczny - dlaczego przestało działać minimum?
"""

from datetime import datetime, timedelta
import hmac
import hashlib
import base64

def test_diagnostic():
    """Sprawdź co się zmieniło"""
    
    print("="*60)
    print("TEST DIAGNOSTYCZNY")
    print("="*60)
    
    # Test różnych kombinacji
    html = """<!DOCTYPE html>
<html>
<head>
    <title>Test Diagnostyczny</title>
    <meta charset="UTF-8">
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
        .test { background: white; padding: 20px; margin: 15px 0; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .warning { background: #fff3cd; border: 2px solid #ffc107; padding: 15px; margin: 20px 0; }
        button { background: #007bff; color: white; padding: 10px 20px; border: none; cursor: pointer; margin: 5px; }
        h3 { margin-top: 0; }
        .field { font-family: monospace; background: #f8f9fa; padding: 5px; margin: 2px 0; }
    </style>
</head>
<body>
    <h1>🔍 Test Diagnostyczny - Co się zmieniło?</h1>
    
    <div class="warning">
        <h3>⚠️ Problem: Minimum przestało działać!</h3>
        <p>Wcześniej działało, teraz nie. Sprawdźmy różne kombinacje.</p>
    </div>
"""
    
    # Test 1: Absolutne minimum
    html += """
    <div class="test">
        <h3>Test 1: Absolutne minimum (3 pola)</h3>
        <form method="POST" action="https://test.ipg-online.com/connect/gateway/processing" target="_blank">
            <input type="hidden" name="storename" value="760995999">
            <input type="hidden" name="chargetotal" value="10.00">
            <input type="hidden" name="currency" value="985">
            <button type="submit">TEST MINIMUM</button>
        </form>
        <div class="field">storename=760995999</div>
        <div class="field">chargetotal=10.00</div>
        <div class="field">currency=985</div>
    </div>
"""
    
    # Test 2: Z różnymi kwotami
    amounts = ["1.00", "5.00", "10.00", "25.00", "100.00"]
    
    html += """
    <div class="test">
        <h3>Test 2: Różne kwoty</h3>
"""
    
    for amount in amounts:
        html += f"""
        <form method="POST" action="https://test.ipg-online.com/connect/gateway/processing" target="_blank" style="display: inline;">
            <input type="hidden" name="storename" value="760995999">
            <input type="hidden" name="chargetotal" value="{amount}">
            <input type="hidden" name="currency" value="985">
            <button type="submit">{amount} PLN</button>
        </form>
"""
    
    html += """
    </div>
"""
    
    # Test 3: Z różnymi walutami
    html += """
    <div class="test">
        <h3>Test 3: Różne waluty</h3>
        
        <form method="POST" action="https://test.ipg-online.com/connect/gateway/processing" target="_blank" style="display: inline;">
            <input type="hidden" name="storename" value="760995999">
            <input type="hidden" name="chargetotal" value="10.00">
            <input type="hidden" name="currency" value="985">
            <button type="submit">PLN (985)</button>
        </form>
        
        <form method="POST" action="https://test.ipg-online.com/connect/gateway/processing" target="_blank" style="display: inline;">
            <input type="hidden" name="storename" value="760995999">
            <input type="hidden" name="chargetotal" value="10.00">
            <input type="hidden" name="currency" value="978">
            <button type="submit">EUR (978)</button>
        </form>
        
        <form method="POST" action="https://test.ipg-online.com/connect/gateway/processing" target="_blank" style="display: inline;">
            <input type="hidden" name="storename" value="760995999">
            <input type="hidden" name="chargetotal" value="10.00">
            <input type="hidden" name="currency" value="840">
            <button type="submit">USD (840)</button>
        </form>
    </div>
"""
    
    # Test 4: GET vs POST
    html += """
    <div class="test">
        <h3>Test 4: Metoda GET (zamiast POST)</h3>
        <a href="https://test.ipg-online.com/connect/gateway/processing?storename=760995999&chargetotal=10.00&currency=985" target="_blank">
            <button type="button">TEST GET</button>
        </a>
    </div>
"""
    
    # Test 5: Z txntype
    html += """
    <div class="test">
        <h3>Test 5: Minimum + txntype</h3>
        <form method="POST" action="https://test.ipg-online.com/connect/gateway/processing" target="_blank">
            <input type="hidden" name="storename" value="760995999">
            <input type="hidden" name="chargetotal" value="10.00">
            <input type="hidden" name="currency" value="985">
            <input type="hidden" name="txntype" value="sale">
            <button type="submit">TEST + TXNTYPE</button>
        </form>
    </div>
"""
    
    # Test 6: Czy problem z IP?
    html += """
    <div class="warning">
        <h3>🤔 Możliwe przyczyny:</h3>
        <ol>
            <li><strong>Sesja wygasła</strong> - może trzeba się zalogować do VT?</li>
            <li><strong>Limit requestów</strong> - za dużo testów?</li>
            <li><strong>IP zablokowane</strong> - 188.33.42.130</li>
            <li><strong>Godziny pracy</strong> - może są ograniczenia czasowe?</li>
            <li><strong>Zmiana po stronie Fiserv</strong> - coś wyłączyli?</li>
        </ol>
    </div>
    
    <div class="test">
        <h3>💡 Co zrobić:</h3>
        <ol>
            <li>Spróbuj z innej przeglądarki (czyste cookies)</li>
            <li>Spróbuj z VPN (inne IP)</li>
            <li>Zaloguj się do Virtual Terminal i spróbuj ponownie</li>
            <li>Poczekaj 15 minut (może limit requestów)</li>
        </ol>
    </div>
</body>
</html>"""
    
    with open('test_diagnostic.html', 'w', encoding='utf-8') as f:
        f.write(html)
    
    print("\n✅ Test zapisany jako: test_diagnostic.html")
    print("\n⚠️  MOŻLIWE PRZYCZYNY:")
    print("1. Sesja wygasła")
    print("2. Limit requestów") 
    print("3. IP zablokowane")
    print("4. Zmiana po stronie Fiserv")
    
    import webbrowser
    import os
    webbrowser.open(f"file://{os.path.abspath('test_diagnostic.html')}")

if __name__ == "__main__":
    test_diagnostic()