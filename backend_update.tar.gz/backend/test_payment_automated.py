#!/usr/bin/env python3
"""
Automated test script to create a payment and generate form for submission
"""

import httpx
import asyncio
import json
from datetime import datetime
import os
import webbrowser

async def create_test_payment():
    """Create a test payment and show form details"""
    
    print("\n" + "="*60)
    print("AUTOMATED FISERV PAYMENT TEST")
    print("="*60 + "\n")
    
    # Use default values
    amount = "50"
    name = "Test User"
    email = "test@example.com"
    method = "card"
    
    async with httpx.AsyncClient() as client:
        # Create payment
        print("1. Creating payment...")
        response = await client.post(
            "http://localhost:8001/api/payments/initiate",
            json={
                "goal_id": "church",
                "amount": float(amount),
                "donor_name": name,
                "donor_email": email,
                "payment_method": method,
                "message": "Automated test payment"
            },
            headers={"Content-Type": "application/json"}
        )
        
        if response.status_code != 200:
            print(f"❌ Error creating payment: {response.status_code}")
            print(response.text)
            return
            
        payment_data = response.json()
        payment_id = payment_data["payment_id"]
        
        print(f"✅ Payment created: {payment_id}")
        print(f"   Amount: {payment_data['amount']} PLN")
        print(f"   Goal: {payment_data['goal']}")
        
        # Get form data
        print("\n2. Getting form data...")
        form_response = await client.get(f"http://localhost:8001/api/payments/{payment_id}/form-data")
        
        if form_response.status_code != 200:
            print(f"❌ Error getting form data: {form_response.status_code}")
            return
            
        form_data = form_response.json()
        
        print("✅ Form data retrieved")
        print(f"   Action URL: {form_data['form_action']}")
        print(f"   Webhook URL: {form_data['form_fields'].get('transactionNotificationURL', 'None')}")
        hash_field = form_data['form_fields'].get('hashExtended', form_data['form_fields'].get('hash', ''))
        print(f"   Hash: {hash_field[:30]}...")
        
        # Print important form fields
        print("\n3. Key form fields:")
        fields = form_data['form_fields']
        print(f"   Store ID: {fields.get('storename')}")
        print(f"   Transaction Type: {fields.get('txntype')}")
        currency_map = {'978': 'EUR', '985': 'PLN', '840': 'USD'}
        currency_code = currency_map.get(fields.get('currency'), fields.get('currency'))
        print(f"   Amount: {fields.get('chargetotal')} {currency_code}")
        print(f"   Currency: {fields.get('currency')} ({currency_code})")
        print(f"   Order ID: {fields.get('oid')}")
        print(f"   DateTime: {fields.get('txndatetime')}")
        print(f"   Timezone: {fields.get('timezone')}")
        print(f"   Hash Algorithm: {fields.get('hash_algorithm')}")
        
        # Create HTML form
        print("\n4. Creating HTML form...")
        html_content = f"""
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Fiserv Payment Test - {payment_id}</title>
    <style>
        body {{ font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; }}
        .info {{ background: #e7f3ff; padding: 15px; border-radius: 5px; margin: 20px 0; }}
        .form-field {{ margin: 10px 0; padding: 10px; background: #f5f5f5; }}
        button {{ padding: 15px 30px; background: #4B6A9B; color: white; border: none; cursor: pointer; font-size: 18px; }}
        button:hover {{ background: #2C4770; }}
        .test-cards {{ background: #fff3cd; padding: 15px; border-radius: 5px; }}
    </style>
</head>
<body>
    <h1>Fiserv Payment Test</h1>
    
    <div class="info">
        <h3>Payment Details:</h3>
        <p><strong>Payment ID:</strong> {payment_id}</p>
        <p><strong>Amount:</strong> {amount} PLN</p>
        <p><strong>Method:</strong> {method}</p>
        <p><strong>Created:</strong> {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
    </div>
    
    <div class="test-cards">
        <h3>Test Cards:</h3>
        <ul>
            <li><strong>Visa:</strong> 4005550000000019 (CVV: 111, Exp: 12/25)</li>
            <li><strong>Mastercard:</strong> 5204740000001002 (CVV: 111, Exp: 12/25)</li>
            <li><strong>Visa Debit:</strong> 4410947715337430 (CVV: 287, Exp: 12/26)</li>
            <li><strong>Mastercard Debit:</strong> 5575233623260024 (CVV: 123, Exp: 12/26)</li>
            <li><strong>BLIK Code:</strong> 777123 (wstępny), Potwierdzenie: 777777</li>
        </ul>
    </div>
    
    <h2>Form Fields (for debugging):</h2>
    <div style="background: #f5f5f5; padding: 10px; overflow-x: auto;">
        <pre>{json.dumps(form_data['form_fields'], indent=2)}</pre>
    </div>
    
    <h2>Submit Payment to Fiserv:</h2>
    <form method="POST" action="{form_data['form_action']}">
"""
        
        # Add all form fields
        for key, value in form_data['form_fields'].items():
            html_content += f'        <input type="hidden" name="{key}" value="{value}">\n'
            
        html_content += f"""
        <button type="submit">Submit Payment to Fiserv Gateway</button>
    </form>
    
    <div class="info" style="margin-top: 30px;">
        <p><strong>Success URL:</strong> {form_data['form_fields'].get('responseSuccessURL', 'N/A')}</p>
        <p><strong>Failure URL:</strong> {form_data['form_fields'].get('responseFailURL', 'N/A')}</p>
        <p><strong>Webhook URL:</strong> {form_data['form_fields'].get('transactionNotificationURL', 'N/A')}</p>
    </div>
</body>
</html>
"""
        
        # Save HTML file
        filename = f"test_payment_{payment_id}.html"
        with open(filename, "w", encoding="utf-8") as f:
            f.write(html_content)
            
        print(f"✅ HTML form saved to: {filename}")
        
        # Open in browser
        print("\n5. Opening in browser...")
        webbrowser.open(f"file://{os.path.abspath(filename)}")
        
        print("\n" + "="*60)
        print("NEXT STEPS:")
        print("1. Click 'Submit Payment to Fiserv Gateway' in your browser")
        print("2. Enter test card details on Fiserv page")
        print("3. Complete the payment")
        print("4. Check if you're redirected back to your app")
        print("5. Monitor ngrok dashboard at: http://localhost:4040")
        print("="*60 + "\n")
        
        # Also save payment info for reference
        info_file = f"payment_info_{payment_id}.json"
        with open(info_file, "w") as f:
            json.dump({
                "payment_id": payment_id,
                "created_at": datetime.now().isoformat(),
                "amount": amount,
                "method": method,
                "form_data": form_data,
                "test_cards": {
                    "visa": "4005550000000019",
                    "mastercard": "5204740000001002",
                    "blik": "777123"
                }
            }, f, indent=2)
            
        print(f"Payment info saved to: {info_file}")

if __name__ == "__main__":
    asyncio.run(create_test_payment())