#!/usr/bin/env python3
"""
Test z absolutnie minimalnym zestawem pól dla Fiserv IPG
"""

import os
import hmac
import hashlib
import base64
from datetime import datetime, timedelta
import json
import webbrowser

# Konfiguracja
STORE_ID = "760995999"
SHARED_SECRET = "j}2W3P)Lwv"
GATEWAY_URL = "https://test.ipg-online.com/connect/gateway/processing"

def generate_absolute_minimal():
    """Generuj formularz z TYLKO obowiązkowymi polami"""
    
    # Timestamp w formacie Fiserv
    now = datetime.utcnow() + timedelta(seconds=30)
    txndatetime = now.strftime("%Y:%m:%d-%H:%M:%S")
    
    # ABSOLUTNE MINIMUM pól
    params = {
        'storename': STORE_ID,
        'txntype': 'sale',
        'timezone': 'Europe/Berlin',
        'txndatetime': txndatetime,
        'chargetotal': '10.00',
        'currency': '985',  # PLN
        'checkoutoption': 'combinedpage',
        'oid': f'MINIMAL-{datetime.now().strftime("%Y%m%d%H%M%S")}',
        'hash_algorithm': 'HMACSHA256'
    }
    
    # Generuj hash - sortuj alfabetycznie, pomiń hash_algorithm
    sorted_params = sorted([(k, v) for k, v in params.items() if k != 'hash_algorithm'])
    values_to_hash = '|'.join(str(v) for k, v in sorted_params)
    
    print("="*60)
    print("ABSOLUTNIE MINIMALNY TEST FISERV")
    print("="*60)
    print("\nParametry (tylko obowiązkowe):")
    for k, v in params.items():
        print(f"  {k}: {v}")
    
    print(f"\nHash input string:\n{values_to_hash}")
    
    # Oblicz HMAC SHA256
    hash_bytes = hmac.new(
        SHARED_SECRET.encode('utf-8'),
        values_to_hash.encode('utf-8'),
        hashlib.sha256
    ).digest()
    hash_base64 = base64.b64encode(hash_bytes).decode('utf-8')
    
    # Użyj hashExtended
    params['hashExtended'] = hash_base64
    
    print(f"\nhashExtended: {hash_base64}")
    print("="*60)
    
    # Generuj HTML
    html = f"""<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Minimalny Test Fiserv</title>
    <style>
        body {{ 
            font-family: Arial, sans-serif; 
            max-width: 800px; 
            margin: 50px auto; 
            padding: 20px;
            background: #f0f0f0;
        }}
        .container {{
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }}
        h1 {{ color: #333; }}
        .params {{
            background: #f8f8f8;
            padding: 20px;
            border-radius: 5px;
            margin: 20px 0;
            font-family: monospace;
        }}
        .param-line {{
            margin: 5px 0;
            padding: 5px;
            background: #fff;
            border-left: 3px solid #4CAF50;
        }}
        button {{
            background: #4CAF50;
            color: white;
            border: none;
            padding: 15px 30px;
            font-size: 18px;
            border-radius: 5px;
            cursor: pointer;
            margin: 20px 0;
        }}
        button:hover {{
            background: #45a049;
        }}
        .warning {{
            background: #fff3cd;
            padding: 15px;
            border-radius: 5px;
            margin: 20px 0;
            border-left: 4px solid #ffc107;
        }}
        .info {{
            background: #d1ecf1;
            padding: 15px;
            border-radius: 5px;
            margin: 20px 0;
            border-left: 4px solid #17a2b8;
        }}
    </style>
</head>
<body>
    <div class="container">
        <h1>🔬 Absolutnie Minimalny Test Fiserv</h1>
        
        <div class="warning">
            <strong>⚠️ UWAGA:</strong> Ten formularz zawiera TYLKO pola obowiązkowe.
            Żadnych dodatkowych parametrów!
        </div>
        
        <div class="info">
            <strong>Konfiguracja:</strong><br>
            • Store ID: {STORE_ID}<br>
            • Timezone: Europe/Berlin (dokumentowana)<br>
            • Waluta: PLN (985)<br>
            • Kwota: 10.00 PLN<br>
            • Order ID: {params['oid']}
        </div>
        
        <h2>Parametry formularza:</h2>
        <div class="params">
"""
    
    for key, value in params.items():
        html += f'            <div class="param-line"><strong>{key}:</strong> {value}</div>\n'
    
    html += f"""
        </div>
        
        <h2>Hash calculation:</h2>
        <div class="params">
            <div style="word-break: break-all;">
                <strong>Input:</strong> {values_to_hash}
            </div>
            <div style="margin-top: 10px;">
                <strong>Output:</strong> {hash_base64}
            </div>
        </div>
        
        <form method="POST" action="{GATEWAY_URL}">
"""
    
    # Dodaj wszystkie pola do formularza
    for key, value in params.items():
        html += f'            <input type="hidden" name="{key}" value="{value}">\n'
    
    html += """
            <button type="submit">🚀 Wyślij Minimalny Formularz</button>
        </form>
        
        <div class="info" style="margin-top: 30px;">
            <strong>Karty testowe:</strong><br>
            • Visa: 4005550000000019 (CVV: 111, Exp: 12/25)<br>
            • Mastercard: 5204740000001002 (CVV: 111, Exp: 12/25)
        </div>
    </div>
</body>
</html>"""
    
    # Zapisz plik
    filename = f"absolute_minimal_{params['oid']}.html"
    with open(filename, 'w', encoding='utf-8') as f:
        f.write(html)
    
    print(f"\n✅ Formularz zapisany jako: {filename}")
    print("\nJeśli ten minimalny formularz nie zadziała, problem jest w konfiguracji konta Fiserv.")
    
    # Zapisz też JSON dla debugowania
    debug_file = f"minimal_debug_{params['oid']}.json"
    with open(debug_file, 'w', encoding='utf-8') as f:
        json.dump({
            'params': params,
            'hash_input': values_to_hash,
            'hash_output': hash_base64,
            'timestamp': datetime.now().isoformat()
        }, f, indent=2, ensure_ascii=False)
    
    return filename

if __name__ == "__main__":
    filename = generate_absolute_minimal()
    webbrowser.open(f"file://{os.path.abspath(filename)}")