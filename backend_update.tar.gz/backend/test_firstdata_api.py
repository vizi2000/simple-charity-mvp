#!/usr/bin/env python3
"""
Test FirstData/Fiserv API - prawidłowy endpoint!
"""

import requests
import json
import base64
import hmac
import hashlib
from datetime import datetime
import time

# Klucze
API_KEY = "xWdewnCcYTy8G0s4oS1r5GAOmcdVRYQn"
API_SECRET = "aGOkU61VoIl5AWApLL7avcCpIVZxVGG6jYGVQib8xuG"

# FirstData Gateway endpoint
BASE_URL = "https://cert.api.firstdata.com/gateway/v2"

def test_firstdata_auth():
    """Test różnych metod autoryzacji dla FirstData"""
    
    print("="*60)
    print("TEST FIRSTDATA/FISERV API")
    print("="*60)
    
    # Przygotuj timestamp i nonce
    timestamp = str(int(time.time() * 1000))
    nonce = datetime.now().strftime('%Y%m%d%H%M%S')
    
    # Test 1: Basic Auth
    print("\n1. Test Basic Auth")
    credentials = f"{API_KEY}:{API_SECRET}"
    encoded_credentials = base64.b64encode(credentials.encode()).decode()
    
    headers = {
        "Authorization": f"Basic {encoded_credentials}",
        "Content-Type": "application/json",
        "Accept": "application/json"
    }
    
    try:
        response = requests.get(f"{BASE_URL}/payments", headers=headers, timeout=10)
        print(f"Status: {response.status_code}")
        print(f"Response: {response.text[:200]}")
    except Exception as e:
        print(f"Error: {e}")
    
    # Test 2: HMAC Authorization (FirstData style)
    print("\n2. Test HMAC Authorization")
    
    # FirstData używa specjalnego HMAC
    resource = "/gateway/v2/payments"
    method = "POST"
    
    # Payload
    payload = {
        "amount": {
            "total": "10.00",
            "currency": "PLN"
        },
        "paymentMethod": {
            "paymentCard": {
                "number": "4005550000000019",
                "expiryDate": {
                    "month": "12",
                    "year": "25"
                },
                "securityCode": "111"
            }
        },
        "transactionType": "SALE"
    }
    
    payload_json = json.dumps(payload)
    
    # Calculate HMAC signature (FirstData method)
    auth_string = f"{API_KEY}{timestamp}{nonce}{method}{resource}{payload_json}"
    signature = hmac.new(
        API_SECRET.encode('utf-8'),
        auth_string.encode('utf-8'),
        hashlib.sha256
    ).hexdigest()
    
    headers = {
        "Api-Key": API_KEY,
        "Timestamp": timestamp,
        "Nonce": nonce,
        "Authorization": f"HMAC {signature}",
        "Content-Type": "application/json",
        "Accept": "application/json"
    }
    
    try:
        response = requests.post(
            f"{BASE_URL}/payments",
            headers=headers,
            json=payload,
            timeout=10
        )
        print(f"Status: {response.status_code}")
        print(f"Headers: {dict(response.headers)}")
        print(f"Response: {response.text[:500]}")
    except Exception as e:
        print(f"Error: {e}")
    
    # Test 3: API Key w headerze
    print("\n3. Test API Key Header")
    headers = {
        "Api-Key": API_KEY,
        "Api-Secret": API_SECRET,
        "Content-Type": "application/json",
        "Accept": "application/json"
    }
    
    try:
        response = requests.post(
            f"{BASE_URL}/payments",
            headers=headers,
            json=payload,
            timeout=10
        )
        print(f"Status: {response.status_code}")
        print(f"Response: {response.text[:200]}")
    except Exception as e:
        print(f"Error: {e}")
    
    # Test 4: OAuth style
    print("\n4. Test OAuth-style Bearer Token")
    # Spróbuj użyć API key jako bearer token
    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json",
        "Accept": "application/json"
    }
    
    try:
        response = requests.get(f"{BASE_URL}/payments", headers=headers, timeout=10)
        print(f"Status: {response.status_code}")
        print(f"Response: {response.text[:200]}")
    except Exception as e:
        print(f"Error: {e}")
    
    # Test 5: Test info endpoint
    print("\n5. Test Info/Health Endpoints")
    test_endpoints = [
        "/",
        "/info",
        "/health",
        "/status",
        "/version"
    ]
    
    for endpoint in test_endpoints:
        try:
            print(f"\nTrying: {BASE_URL}{endpoint}")
            response = requests.get(
                f"{BASE_URL}{endpoint}",
                headers={"Api-Key": API_KEY},
                timeout=5
            )
            print(f"Status: {response.status_code}")
            if response.status_code != 404:
                print(f"Response: {response.text[:100]}")
        except Exception as e:
            print(f"Error: {type(e).__name__}")

def test_token_endpoint():
    """Test token endpoint dla OAuth flow"""
    
    print("\n" + "="*60)
    print("TEST TOKEN ENDPOINT")
    print("="*60)
    
    # FirstData może używać OAuth
    token_url = "https://cert.api.firstdata.com/gateway/v2/token"
    
    # Client credentials flow
    data = {
        "grant_type": "client_credentials",
        "client_id": API_KEY,
        "client_secret": API_SECRET
    }
    
    try:
        response = requests.post(
            token_url,
            data=data,
            timeout=10
        )
        print(f"Status: {response.status_code}")
        print(f"Response: {response.text}")
        
        if response.status_code == 200:
            token_data = response.json()
            print("\n✅ Got access token!")
            return token_data.get("access_token")
    except Exception as e:
        print(f"Error: {e}")
    
    return None

if __name__ == "__main__":
    test_firstdata_auth()
    access_token = test_token_endpoint()
    
    if access_token:
        print("\n" + "="*60)
        print("TEST WITH ACCESS TOKEN")
        print("="*60)
        
        headers = {
            "Authorization": f"Bearer {access_token}",
            "Content-Type": "application/json"
        }
        
        try:
            response = requests.get(
                f"{BASE_URL}/payments",
                headers=headers,
                timeout=10
            )
            print(f"Status: {response.status_code}")
            print(f"Response: {response.text[:200]}")
        except Exception as e:
            print(f"Error: {e}")