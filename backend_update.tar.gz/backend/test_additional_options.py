#!/usr/bin/env python3
"""
Test dodatkowych opcji sugerowanych w analizie
"""

import os
import hmac
import hashlib
import base64
from datetime import datetime, timedelta
import webbrowser

# Konfiguracja
STORE_ID = "760995999"
SHARED_SECRET = "j}2W3P)Lwv"  # Original
ALT_SECRET = "c7dP/$5PBx"     # Alternative
GATEWAY_URL = "https://test.ipg-online.com/connect/gateway/processing"

def generate_hash(secret, values_string):
    """Generuj hash dla danego secretu"""
    hash_bytes = hmac.new(
        secret.encode('utf-8'),
        values_string.encode('utf-8'),
        hashlib.sha256
    ).digest()
    return base64.b64encode(hash_bytes).decode('utf-8')

def test_additional_options():
    """Test dodatkowych opcji z analizy"""
    
    # Timestamp
    now = datetime.utcnow() + timedelta(seconds=30)
    txndatetime = now.strftime("%Y:%m:%d-%H:%M:%S")
    
    print("="*60)
    print("TEST DODATKOWYCH OPCJI")
    print("="*60)
    print(f"\nTimestamp: {txndatetime}\n")
    
    # Generuj HTML
    html = f"""<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Test Additional Options</title>
    <style>
        body {{ font-family: Arial, sans-serif; max-width: 1200px; margin: 0 auto; padding: 20px; }}
        .test-form {{ 
            background: #f8f9fa; 
            padding: 20px; 
            margin: 20px 0; 
            border-radius: 5px;
            border: 2px solid #dee2e6;
        }}
        .highlight {{ background: #e8f5e9; border-color: #4caf50; }}
        h3 {{ margin-top: 0; color: #495057; }}
        button {{ 
            background: #28a745; 
            color: white; 
            border: none; 
            padding: 12px 24px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            font-weight: bold;
        }}
        button:hover {{ background: #218838; }}
        .info {{ 
            font-family: monospace; 
            background: #e9ecef; 
            padding: 10px;
            margin: 10px 0;
            border-radius: 3px;
        }}
        .warning {{
            background: #fff3cd;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            border: 1px solid #ffc107;
        }}
    </style>
</head>
<body>
    <h1>🔧 Test Dodatkowych Opcji</h1>
    
    <div class="warning">
        <strong>📋 Testy na podstawie analizy dokumentacji:</strong><br>
        1. Zmiana checkoutoption z 'combinedpage' na 'classic'<br>
        2. Test z różnymi walutami (EUR, USD)<br>
        3. Wyłączenie 3D Secure<br>
        4. Jawne określenie paymentMethod<br>
        5. Uproszczone order ID (tylko alfanumeryczne)
    </div>
"""
    
    tests = []
    
    # Test 1: checkoutoption = classic
    test1 = {
        'storename': STORE_ID,
        'txntype': 'sale',
        'timezone': 'Europe/Berlin',
        'txndatetime': txndatetime,
        'chargetotal': '10.00',
        'currency': '985',  # PLN
        'checkoutoption': 'classic',  # ZMIANA!
        'oid': f'CLASSIC{datetime.now().strftime("%Y%m%d%H%M%S")}'
    }
    tests.append(("Checkout Option: Classic", test1, SHARED_SECRET, True))
    
    # Test 2: Waluta EUR
    test2 = {
        'storename': STORE_ID,
        'txntype': 'sale',
        'timezone': 'Europe/Berlin',
        'txndatetime': txndatetime,
        'chargetotal': '10.00',
        'currency': '978',  # EUR
        'checkoutoption': 'combinedpage',
        'oid': f'EUR{datetime.now().strftime("%Y%m%d%H%M%S")}'
    }
    tests.append(("Waluta: EUR (978)", test2, SHARED_SECRET, True))
    
    # Test 3: Waluta USD
    test3 = {
        'storename': STORE_ID,
        'txntype': 'sale',
        'timezone': 'Europe/Berlin',
        'txndatetime': txndatetime,
        'chargetotal': '10.00',
        'currency': '840',  # USD
        'checkoutoption': 'combinedpage',
        'oid': f'USD{datetime.now().strftime("%Y%m%d%H%M%S")}'
    }
    tests.append(("Waluta: USD (840)", test3, SHARED_SECRET, True))
    
    # Test 4: Wyłączone 3D Secure
    test4 = {
        'storename': STORE_ID,
        'txntype': 'sale',
        'timezone': 'Europe/Berlin',
        'txndatetime': txndatetime,
        'chargetotal': '10.00',
        'currency': '985',
        'checkoutoption': 'combinedpage',
        'authenticateTransaction': 'false',  # Wyłącz 3D Secure
        'oid': f'NO3DS{datetime.now().strftime("%Y%m%d%H%M%S")}'
    }
    tests.append(("Wyłączone 3D Secure", test4, SHARED_SECRET, True))
    
    # Test 5: Jawne określenie paymentMethod
    test5 = {
        'storename': STORE_ID,
        'txntype': 'sale',
        'timezone': 'Europe/Berlin',
        'txndatetime': txndatetime,
        'chargetotal': '10.00',
        'currency': '985',
        'checkoutoption': 'combinedpage',
        'paymentMethod': 'V',  # Visa
        'oid': f'VISA{datetime.now().strftime("%Y%m%d%H%M%S")}'
    }
    tests.append(("Payment Method: V (Visa)", test5, SHARED_SECRET, False))
    
    # Test 6: Absolutnie minimalne pola
    test6 = {
        'storename': STORE_ID,
        'txntype': 'sale',
        'chargetotal': '10.00',
        'currency': '985'
    }
    tests.append(("Absolutne minimum pól", test6, SHARED_SECRET, True))
    
    # Test 7: Classic + EUR + no 3DS
    test7 = {
        'storename': STORE_ID,
        'txntype': 'sale',
        'timezone': 'Europe/Berlin',
        'txndatetime': txndatetime,
        'chargetotal': '10.00',
        'currency': '978',  # EUR
        'checkoutoption': 'classic',
        'authenticateTransaction': 'false',
        'oid': f'COMBO{datetime.now().strftime("%Y%m%d%H%M%S")}'
    }
    tests.append(("Kombinacja: Classic + EUR + No 3DS", test7, SHARED_SECRET, True))
    
    # Test 8: Z alternatywnym secretem + classic
    test8 = {
        'storename': STORE_ID,
        'txntype': 'sale',
        'timezone': 'Europe/Berlin',
        'txndatetime': txndatetime,
        'chargetotal': '10.00',
        'currency': '985',
        'checkoutoption': 'classic',
        'oid': f'ALTCLASSIC{datetime.now().strftime("%Y%m%d%H%M%S")}'
    }
    tests.append(("Alt Secret + Classic", test8, ALT_SECRET, True))
    
    # Generuj formularze
    for i, (name, params, secret, highlight) in enumerate(tests, 1):
        # Sortuj i generuj hash
        sorted_params = sorted(params.items())
        values_to_hash = '|'.join(str(v) for k, v in sorted_params)
        hash_value = generate_hash(secret, values_to_hash)
        
        print(f"{i}. {name}:")
        print(f"   Fields: {', '.join(params.keys())}")
        print(f"   Hash input: {values_to_hash[:60]}...")
        print()
        
        # Dodaj hash do parametrów
        form_params = params.copy()
        form_params['hash_algorithm'] = 'HMACSHA256'
        form_params['hashExtended'] = hash_value
        
        highlight_class = "highlight" if highlight else ""
        
        html += f"""
    <div class="test-form {highlight_class}">
        <h3>Test {i}: {name}</h3>
        <div class="info">
"""
        for k, v in params.items():
            html += f"            {k}: {v}<br>\n"
        html += f"""            Secret: {secret}
        </div>
        <form method="POST" action="{GATEWAY_URL}" target="_blank">
"""
        for k, v in form_params.items():
            html += f'            <input type="hidden" name="{k}" value="{v}">\n'
        
        html += f"""            <button type="submit">🚀 Testuj: {name}</button>
        </form>
    </div>
"""
    
    # Sekcja URL overwrite
    html += """
    <hr style="margin: 40px 0;">
    <h2>⚠️ Ważne: Ustawienia Virtual Terminal</h2>
    <div style="background: #e3f2fd; padding: 20px; border-radius: 5px;">
        <p><strong>Sprawdź w Virtual Terminal:</strong></p>
        <ol>
            <li>Zaloguj się do Virtual Terminal</li>
            <li>Przejdź do Settings → Store Settings</li>
            <li>Znajdź sekcję "URL Configuration" lub "Response URLs"</li>
            <li>Zaznacz opcję: <strong>"Allow URLs to be overwritten by those in the transaction request"</strong></li>
            <li>Zapisz zmiany</li>
        </ol>
        <p>Bez tej opcji, gateway może ignorować URL-e z formularza!</p>
    </div>
"""
    
    html += """
    <div style="margin-top: 30px; padding: 15px; background: #d1ecf1; border-radius: 5px;">
        <strong>🎯 Najbardziej obiecujące testy:</strong><br>
        1. <strong>Checkout Option: Classic</strong> - niektóre konta testowe nie obsługują 'combinedpage'<br>
        2. <strong>Waluta EUR/USD</strong> - konto może nie mieć włączonego PLN<br>
        3. <strong>Wyłączone 3D Secure</strong> - upraszcza proces w testach<br>
        4. <strong>Kombinacja opcji</strong> - classic + EUR + no 3DS<br><br>
        
        <strong>💡 Jeśli któryś test przejdzie dalej:</strong><br>
        Zapisz dokładnie które ustawienia zadziałały i użyj ich w docelowej integracji!
    </div>
</body>
</html>"""
    
    filename = "test_additional_options.html"
    with open(filename, 'w', encoding='utf-8') as f:
        f.write(html)
    
    print(f"✅ Test zapisany jako: {filename}")
    print("\n🎯 Szczególnie przetestuj:")
    print("   1. Checkout Option = 'classic'")
    print("   2. Różne waluty (EUR, USD)")
    print("   3. Wyłączone 3D Secure")
    
    return filename

if __name__ == "__main__":
    filename = test_additional_options()
    webbrowser.open(f"file://{os.path.abspath(filename)}")