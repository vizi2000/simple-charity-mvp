#!/usr/bin/env python3
"""
Test minimal required fields for Fiserv payment
"""

import hashlib
import hmac
import base64
from datetime import datetime
from zoneinfo import ZoneInfo

def generate_hash(params: dict, shared_secret: str) -> str:
    """Generate HMAC-SHA256 hash for Fiserv payment"""
    # Sort parameters alphabetically by key
    sorted_keys = sorted(params.keys())
    
    # Create string to sign by joining values with pipe separator
    values = [str(params[key]) for key in sorted_keys]
    string_to_sign = '|'.join(values)
    
    print(f"String to sign: {string_to_sign}")
    
    # Generate HMAC-SHA256
    signature = hmac.new(
        shared_secret.encode('utf-8'),
        string_to_sign.encode('utf-8'),
        hashlib.sha256
    ).digest()
    
    # Encode in Base64
    hash_value = base64.b64encode(signature).decode('utf-8')
    return hash_value

def test_minimal():
    """Test with absolute minimum fields"""
    
    shared_secret = 'j}2W3P)Lwv'
    store_id = '760995999'
    
    # Get current Warsaw time
    warsaw_tz = ZoneInfo('Europe/Warsaw')
    now = datetime.now(warsaw_tz)
    txn_datetime = now.strftime('%Y:%m:%d-%H:%M:%S')
    
    order_id = f"MIN-TEST-{now.strftime('%Y%m%d%H%M%S')}"
    
    print("=" * 50)
    print("TEST 1: ABSOLUTE MINIMUM FIELDS")
    print("=" * 50)
    
    # Try with only the most essential fields
    params = {
        'chargetotal': '10.00',
        'currency': '985',
        'storename': store_id,
        'txndatetime': txn_datetime,
        'txntype': 'sale',
        'hash_algorithm': 'HMACSHA256'
    }
    
    hash_value = generate_hash(params, shared_secret)
    
    # Create form HTML
    html = f'''<!DOCTYPE html>
<html>
<head>
    <title>Minimal Fiserv Test</title>
    <meta charset="UTF-8">
</head>
<body>
    <h1>Minimal Payment Test</h1>
    <form method="POST" action="https://test.ipg-online.com/connect/gateway/processing">
        <input type="hidden" name="chargetotal" value="{params['chargetotal']}"/>
        <input type="hidden" name="currency" value="{params['currency']}"/>
        <input type="hidden" name="storename" value="{params['storename']}"/>
        <input type="hidden" name="txndatetime" value="{params['txndatetime']}"/>
        <input type="hidden" name="txntype" value="{params['txntype']}"/>
        <input type="hidden" name="hash_algorithm" value="{params['hash_algorithm']}"/>
        <input type="hidden" name="hashExtended" value="{hash_value}"/>
        <button type="submit">Test Minimal Payment</button>
    </form>
    <hr>
    <pre>
Parameters:
{chr(10).join(f'{k}: {v}' for k, v in params.items())}
hashExtended: {hash_value}
    </pre>
</body>
</html>'''
    
    with open('test_minimal_fiserv.html', 'w') as f:
        f.write(html)
    
    print(f"\nForm data:")
    for k, v in params.items():
        print(f"  {k}: {v}")
    print(f"  hashExtended: {hash_value}")
    print("\nHTML saved to: test_minimal_fiserv.html")
    
    # Test 2: Add order ID
    print("\n" + "=" * 50)
    print("TEST 2: WITH ORDER ID")
    print("=" * 50)
    
    params2 = params.copy()
    params2['oid'] = order_id
    
    hash_value2 = generate_hash(params2, shared_secret)
    
    print(f"\nForm data:")
    for k, v in params2.items():
        print(f"  {k}: {v}")
    print(f"  hashExtended: {hash_value2}")
    
    # Test 3: With response URLs
    print("\n" + "=" * 50)
    print("TEST 3: WITH RESPONSE URLS")
    print("=" * 50)
    
    params3 = {
        'chargetotal': '10.00',
        'currency': '985',
        'hash_algorithm': 'HMACSHA256',
        'oid': order_id,
        'responseFailURL': 'https://borgtools.ddns.net/bramkamvp/payment/failure',
        'responseSuccessURL': 'https://borgtools.ddns.net/bramkamvp/payment/success',
        'storename': store_id,
        'timezone': 'Europe/Warsaw',
        'txndatetime': txn_datetime,
        'txntype': 'sale'
    }
    
    hash_value3 = generate_hash(params3, shared_secret)
    
    print(f"\nForm data:")
    for k, v in params3.items():
        print(f"  {k}: {v}")
    print(f"  hashExtended: {hash_value3}")

if __name__ == "__main__":
    test_minimal()