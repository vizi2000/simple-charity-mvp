#!/usr/bin/env python3
"""
Finalny test integracji Fiserv z poprawną implementacją hash
Używa sprawdzonej metody z fiserv_connect.py
"""

import requests
import hmac
import hashlib
import base64
from datetime import datetime
from zoneinfo import ZoneInfo
import json
import time

# Konfiguracja - POPRAWNY SECRET!
SECRET = 'j}2W3P)Lwv'  # Ten secret działa!
STORE_ID = '760995999'
TEST_URL = 'https://test.ipg-online.com/connect/gateway/processing'

# Kolejność pól do hash (alfabetyczna)
REQUIRED_FIELDS_ORDER = [
    "chargetotal",
    "checkoutoption",
    "currency",
    "oid",
    "storename",
    "timezone",
    "txndatetime",
    "txntype",
]

def compose_hash_string(payload):
    """Tworzy string do hash - tylko wartości w określonej kolejności"""
    values = []
    for key in REQUIRED_FIELDS_ORDER:
        if key not in payload:
            raise ValueError(f"Missing required field for hash: {key}")
        values.append(str(payload[key]))
    return "|".join(values)

def compute_hash_extended(payload, shared_secret):
    """Oblicza Base64-encoded HMAC-SHA256"""
    to_sign = compose_hash_string(payload)
    mac = hmac.new(shared_secret.encode("utf-8"), to_sign.encode("utf-8"), hashlib.sha256).digest()
    return base64.b64encode(mac).decode("utf-8")

def test_payment():
    """Test płatności z poprawną implementacją"""
    
    # Warsaw timezone
    warsaw_tz = ZoneInfo('Europe/Warsaw')
    timestamp = datetime.now(warsaw_tz).strftime('%Y:%m:%d-%H:%M:%S')
    order_id = f'VISION-TEST-{datetime.now().strftime("%Y%m%d%H%M%S")}'
    
    print('\n' + '='*70)
    print('🔍 VISION TEST - FINALNA WERYFIKACJA INTEGRACJI FISERV')
    print('='*70)
    
    # Dane formularza (tylko wymagane pola)
    form_data = {
        'storename': STORE_ID,
        'txntype': 'sale',
        'timezone': 'Europe/Warsaw',
        'txndatetime': timestamp,
        'hash_algorithm': 'HMACSHA256',
        'chargetotal': '10.00',
        'currency': '985',
        'checkoutoption': 'combinedpage',
        'oid': order_id,
        'responseSuccessURL': 'https://webhook.site/a1b2c3d4-success',
        'responseFailURL': 'https://webhook.site/a1b2c3d4-failure',
        'transactionNotificationURL': 'https://webhook.site/a1b2c3d4-webhook',
        'bname': 'Vision Test',
        'bemail': 'vision@test.pl'
    }
    
    print(f'\n📤 Dane wysyłane:')
    print(f'   Order ID: {order_id}')
    print(f'   Kwota: {form_data["chargetotal"]} PLN')
    print(f'   Timezone: {form_data["timezone"]}')
    print(f'   Timestamp: {timestamp}')
    print(f'   Store ID: {STORE_ID}')
    
    # Generuj hash używając TYLKO pól wymaganych
    hash_payload = {k: form_data[k] for k in REQUIRED_FIELDS_ORDER if k in form_data}
    
    print(f'\n🔐 Generowanie hash:')
    hash_string = compose_hash_string(hash_payload)
    print(f'   String do hash: {hash_string[:80]}...')
    print(f'   Secret: {SECRET}')
    
    hash_value = compute_hash_extended(hash_payload, SECRET)
    form_data['hashExtended'] = hash_value
    print(f'   Hash (Base64): {hash_value[:30]}...')
    
    # Wyślij request
    print(f'\n📨 Wysyłanie do Fiserv...')
    try:
        response = requests.post(TEST_URL, data=form_data, timeout=30, allow_redirects=False)
        
        print(f'\n📊 Odpowiedź Fiserv:')
        print(f'   Status Code: {response.status_code}')
        
        success = False
        if 'Location' in response.headers:
            location = response.headers['Location']
            print(f'   Redirect URL: {location[:100]}...')
            
            if 'validationError' in location:
                print(f'\n   ❌ BŁĄD WALIDACJI')
                print(f'   Fiserv odrzucił request z powodu błędu walidacji.')
                
                # Sprawdź typ błędu
                if response.status_code == 302:
                    print(f'   ⚠️  Możliwe przyczyny:')
                    print(f'      - Nieprawidłowy hash (sprawdź secret)')
                    print(f'      - Przeterminowany timestamp (max 15 min)')
                    print(f'      - Brakujące wymagane pola')
                    print(f'      - Store ID nie ma aktywnego IPG Connect')
                    
            elif 'payment' in location.lower() or '/connect/gateway/' in location:
                print(f'\n   ✅ SUKCES!')
                print(f'   Bramka zaakceptowała dane i przekierowała do strony płatności.')
                success = True
            else:
                print(f'\n   ❓ Nieznany typ odpowiedzi')
        else:
            print(f'   No redirect - sprawdź content:')
            print(f'   {response.text[:500]}')
        
        # Zapisz wyniki
        result = {
            'test_type': 'VISION_TEST',
            'timestamp': datetime.now().isoformat(),
            'order_id': order_id,
            'request': {
                'url': TEST_URL,
                'data': form_data,
                'hash_string': hash_string,
                'hash_value': hash_value
            },
            'response': {
                'status_code': response.status_code,
                'headers': dict(response.headers),
                'redirect_url': response.headers.get('Location', None)
            },
            'success': success
        }
        
        filename = f'vision_test_result_{order_id}.json'
        with open(filename, 'w') as f:
            json.dump(result, f, indent=2)
        print(f'\n💾 Wyniki zapisane: {filename}')
        
        # Generuj formularz HTML do ręcznego testu
        if not success:
            print(f'\n📝 Generuję formularz HTML do ręcznego testu...')
            generate_test_form(form_data, order_id)
        
        return success
        
    except Exception as e:
        print(f'   ❌ Błąd komunikacji: {e}')
        return False

def generate_test_form(form_data, order_id):
    """Generuje formularz HTML do ręcznego testu"""
    html = f'''<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Vision Test - {order_id}</title>
    <style>
        body {{ font-family: Arial; max-width: 800px; margin: 50px auto; padding: 20px; }}
        .container {{ background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }}
        h1 {{ color: #333; border-bottom: 2px solid #4CAF50; padding-bottom: 10px; }}
        .info {{ background: #e8f5e9; padding: 15px; border-radius: 5px; margin: 20px 0; }}
        .field {{ margin: 10px 0; padding: 8px; background: #f9f9f9; }}
        button {{ background: #4CAF50; color: white; border: none; padding: 15px 40px; font-size: 18px; cursor: pointer; }}
        button:hover {{ background: #45a049; }}
    </style>
</head>
<body>
    <div class="container">
        <h1>🔍 Vision Test - Formularz Płatności</h1>
        
        <div class="info">
            <h3>Test Information</h3>
            <div class="field"><strong>Order ID:</strong> {order_id}</div>
            <div class="field"><strong>Amount:</strong> {form_data["chargetotal"]} PLN</div>
            <div class="field"><strong>Timestamp:</strong> {form_data["txndatetime"]}</div>
            <div class="field"><strong>Hash:</strong> {form_data["hashExtended"][:30]}...</div>
        </div>
        
        <form id="paymentForm" action="{TEST_URL}" method="POST">
'''
    
    # Dodaj wszystkie pola formularza
    for key, value in form_data.items():
        html += f'            <input type="hidden" name="{key}" value="{value}">\n'
    
    html += '''        </form>
        
        <button onclick="document.getElementById('paymentForm').submit()">
            💳 Wyślij do Fiserv
        </button>
        
        <div style="margin-top: 20px; color: #666; font-size: 12px;">
            Generated: ''' + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + '''
        </div>
    </div>
</body>
</html>'''
    
    filename = f'vision_test_form_{order_id}.html'
    with open(filename, 'w') as f:
        f.write(html)
    print(f'   ✅ Formularz HTML: {filename}')
    print(f'   Otwórz go w przeglądarce i kliknij przycisk aby przetestować.')

def main():
    print('\n' + '='*70)
    print('🚀 URUCHAMIAM VISION TEST INTEGRACJI FISERV')
    print('='*70)
    print('\nUżywam sprawdzonej implementacji hash z test_hash_unit.py')
    print(f'Secret: {SECRET}')
    print(f'Store ID: {STORE_ID}')
    
    # Test znany przykład najpierw
    print('\n' + '-'*70)
    print('📋 TEST 1: Weryfikacja znanego przykładu')
    print('-'*70)
    
    test_payload = {
        "chargetotal": "10.00",
        "checkoutoption": "combinedpage",
        "currency": "985",
        "oid": "DEBUG-20250729113356",
        "storename": "760995999",
        "timezone": "Europe/Warsaw",
        "txndatetime": "2025:07:29-09:33:56",
        "txntype": "sale",
    }
    
    expected_hash = "aDMsqleb5UDagk6UQ5PMtl5DPSwYh7yxYFT50wLj+dA="
    computed_hash = compute_hash_extended(test_payload, SECRET)
    
    print(f'Expected hash: {expected_hash}')
    print(f'Computed hash: {computed_hash}')
    
    if computed_hash == expected_hash:
        print('✅ Hash calculation verified!')
    else:
        print('❌ Hash mismatch - implementation error!')
        return
    
    # Test rzeczywisty
    print('\n' + '-'*70)
    print('📋 TEST 2: Rzeczywista płatność testowa')
    print('-'*70)
    
    success = test_payment()
    
    print('\n' + '='*70)
    if success:
        print('✅ VISION TEST ZAKOŃCZONY SUKCESEM!')
        print('Integracja z Fiserv działa poprawnie.')
    else:
        print('❌ VISION TEST NIEUDANY')
        print('Sprawdź logi Fiserv lub skontaktuj się z supportem.')
    print('='*70)

if __name__ == '__main__':
    main()