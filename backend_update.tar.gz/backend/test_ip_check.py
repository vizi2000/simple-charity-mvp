#!/usr/bin/env python3
"""
Sprawdź informacje o IP i możliwe problemy
"""

import requests
import json
import socket

def check_ip_info():
    """Sprawdź informacje o aktualnym IP"""
    
    print("="*60)
    print("ANALIZA IP KLIENTA")
    print("="*60)
    
    # Sprawdź aktualne IP
    try:
        print("\n1. Twoje aktualne IP:")
        response = requests.get('https://ipinfo.io/json', timeout=5)
        ip_info = response.json()
        
        print(f"   IP: {ip_info.get('ip')}")
        print(f"   Miasto: {ip_info.get('city')}")
        print(f"   Region: {ip_info.get('region')}")
        print(f"   Kraj: {ip_info.get('country')}")
        print(f"   Organizacja: {ip_info.get('org')}")
        print(f"   Lokalizacja: {ip_info.get('loc')}")
        
        current_ip = ip_info.get('ip')
        
    except Exception as e:
        print(f"   Błąd: {e}")
        current_ip = None
    
    # Sprawdź czy IP jest mobilne
    if current_ip:
        print(f"\n2. Analiza IP {current_ip}:")
        try:
            response = requests.get(f'http://ip-api.com/json/{current_ip}', timeout=5)
            detail_info = response.json()
            
            print(f"   ISP: {detail_info.get('isp')}")
            print(f"   Typ: {'Mobile' if 'mobile' in detail_info.get('isp', '').lower() else 'Fixed'}")
            print(f"   AS: {detail_info.get('as')}")
            
            # Sprawdź czy to IP mobilne
            mobile_keywords = ['mobile', 'cellular', 't-mobile', 'orange', 'plus', 'play']
            is_mobile = any(keyword in detail_info.get('isp', '').lower() for keyword in mobile_keywords)
            
            if is_mobile:
                print(f"\n   ⚠️  UWAGA: Wykryto IP mobilne!")
                print(f"   To może być przyczyną błędów w Fiserv!")
                
        except Exception as e:
            print(f"   Błąd: {e}")
    
    # Sprawdź hostname lokalny
    print("\n3. Informacje o serwerze lokalnym:")
    try:
        hostname = socket.gethostname()
        local_ip = socket.gethostbyname(hostname)
        print(f"   Hostname: {hostname}")
        print(f"   Lokalne IP: {local_ip}")
    except Exception as e:
        print(f"   Błąd: {e}")
    
    # Sprawdź ngrok
    print("\n4. Status ngrok:")
    try:
        response = requests.get('http://127.0.0.1:4040/api/tunnels', timeout=2)
        tunnels = response.json()
        for tunnel in tunnels.get('tunnels', []):
            print(f"   Tunel: {tunnel.get('name')}")
            print(f"   URL: {tunnel.get('public_url')}")
            print(f"   Proto: {tunnel.get('proto')}")
    except:
        print("   Ngrok nie działa lub brak dostępu do API")
    
    # Rekomendacje
    print("\n" + "="*60)
    print("REKOMENDACJE")
    print("="*60)
    
    if current_ip and is_mobile:
        print("\n🚨 PROBLEM: Używasz internetu mobilnego!")
        print("\nRozwiązania:")
        print("1. Zmień na stałe łącze internetowe")
        print("2. Użyj VPN z serwerem w Polsce")
        print("3. Zadeploy aplikację na serwer publiczny:")
        print("   - Heroku: heroku create && git push heroku main")
        print("   - Railway: railway up")
        print("   - Render.com (przez web UI)")
        print("\n4. Testuj z innej lokalizacji (biuro, kawiarnia)")
    else:
        print("\n✅ IP wygląda OK (nie mobilne)")
        print("Problem może być gdzie indziej")
    
    # Test IP z błędu
    print("\n" + "="*60)
    print("ANALIZA IP Z BŁĘDU FISERV")
    print("="*60)
    
    error_ip = "188.33.46.187"
    try:
        response = requests.get(f'http://ip-api.com/json/{error_ip}', timeout=5)
        error_info = response.json()
        
        print(f"\nIP z błędu: {error_ip}")
        print(f"ISP: {error_info.get('isp')}")
        print(f"Organizacja: {error_info.get('org')}")
        print(f"Kraj: {error_info.get('country')}")
        print(f"Miasto: {error_info.get('city')}")
        
        if 'mobile' in error_info.get('isp', '').lower():
            print("\n⚠️  To jest IP mobilne - prawdopodobna przyczyna problemu!")
            
    except Exception as e:
        print(f"Błąd: {e}")

if __name__ == "__main__":
    check_ip_info()