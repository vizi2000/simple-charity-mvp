#!/usr/bin/env python3
"""
Test z aktualnym czasem warszawskim
"""

from datetime import datetime, timedelta
import hmac
import hashlib
import base64

def test_current_warsaw_time():
    """Test z aktualnym czasem warszawskim"""
    
    print("="*60)
    print("TEST Z AKTUALNYM CZASEM WARSZAWSKIM")
    print("="*60)
    
    shared_secret = "j}2W3P)Lwv"
    
    # Aktualny czas UTC + 2 godziny dla Warsaw (czas letni)
    now_utc = datetime.utcnow()
    warsaw_time = now_utc + timedelta(hours=2)
    warsaw_time_str = warsaw_time.strftime("%Y:%m:%d-%H:%M:%S")
    
    order_id = f"WARSAW-{warsaw_time.strftime('%Y%m%d%H%M%S')}"
    
    fields = {
        'storename': '760995999',
        'txntype': 'sale',
        'timezone': 'Europe/Warsaw',
        'txndatetime': warsaw_time_str,
        'chargetotal': '10.00',
        'currency': '985',
        'checkoutoption': 'combinedpage',
        'oid': order_id,
        'hash_algorithm': 'HMACSHA256'
    }
    
    print(f"\nCZAS:")
    print(f"  UTC:    {now_utc.strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"  Warsaw: {warsaw_time.strftime('%Y-%m-%d %H:%M:%S')} (UTC+2)")
    
    print("\nPOLA DO WYSŁANIA:")
    for k, v in sorted(fields.items()):
        print(f"  {k}: {v}")
    
    # Oblicz hash
    hash_fields = {k: v for k, v in fields.items() if k not in ['hash_algorithm', 'hashExtended']}
    sorted_fields = sorted(hash_fields.items())
    hash_string = '|'.join(str(v) for k, v in sorted_fields)
    
    print(f"\nSTRING DO HASHA:")
    print(f"  {hash_string}")
    
    # HMAC-SHA256
    hash_bytes = hmac.new(
        shared_secret.encode('utf-8'),
        hash_string.encode('utf-8'),
        hashlib.sha256
    ).digest()
    hash_value = base64.b64encode(hash_bytes).decode('utf-8')
    
    print(f"\nHASH:")
    print(f"  Secret: {shared_secret}")
    print(f"  Hash (Base64): {hash_value}")
    
    fields['hashExtended'] = hash_value
    
    # Pokaż dokładny request
    print("\n" + "="*60)
    print("DOKŁADNY REQUEST:")
    print("="*60)
    print("POST https://test.ipg-online.com/connect/gateway/processing")
    print("Content-Type: application/x-www-form-urlencoded")
    print("\nBody:")
    request_body = '&'.join([f"{k}={v}" for k, v in fields.items()])
    print(request_body)
    print("="*60)
    
    # Generuj HTML
    html = f"""<!DOCTYPE html>
<html>
<head>
    <title>Test - Aktualny czas warszawski</title>
    <meta charset="UTF-8">
    <style>
        body {{ 
            font-family: 'Courier New', monospace; 
            max-width: 1000px; 
            margin: 20px auto; 
            padding: 20px;
            background: #1e1e1e;
            color: #d4d4d4;
        }}
        .container {{
            background: #252526;
            padding: 20px;
            border-radius: 8px;
            border: 1px solid #464647;
        }}
        h1 {{ color: #569cd6; }}
        h2 {{ color: #4ec9b0; }}
        .time-info {{
            background: #1e1e1e;
            padding: 15px;
            margin: 20px 0;
            border-left: 4px solid #569cd6;
            font-size: 14px;
        }}
        .request {{
            background: #1e1e1e;
            padding: 20px;
            margin: 20px 0;
            border: 1px solid #464647;
            overflow-x: auto;
        }}
        .field {{
            color: #9cdcfe;
            margin: 3px 0;
        }}
        .value {{
            color: #ce9178;
        }}
        button {{
            background: #569cd6;
            color: white;
            border: none;
            padding: 12px 30px;
            font-size: 16px;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 20px;
        }}
        button:hover {{
            background: #4b8bbf;
        }}
        .hash-string {{
            color: #d7ba7d;
            word-break: break-all;
        }}
    </style>
</head>
<body>
    <div class="container">
        <h1>🕐 Test z aktualnym czasem warszawskim</h1>
        
        <div class="time-info">
            <div>UTC Time: <span class="value">{now_utc.strftime('%Y-%m-%d %H:%M:%S')}</span></div>
            <div>Warsaw Time: <span class="value">{warsaw_time.strftime('%Y-%m-%d %H:%M:%S')}</span> (UTC+2)</div>
        </div>
        
        <h2>📤 Co dokładnie wysyłamy:</h2>
        
        <div class="request">
            <div style="color: #b5cea8;">POST https://test.ipg-online.com/connect/gateway/processing</div>
            <div style="color: #b5cea8;">Content-Type: application/x-www-form-urlencoded</div>
            <div style="margin-top: 15px; color: #d4d4d4;">Body:</div>
            <div class="hash-string" style="margin-top: 10px;">{request_body}</div>
        </div>
        
        <h2>📝 Pola (czytelnie):</h2>
        <div class="request">
"""
    
    for k, v in sorted(fields.items()):
        if k == 'hashExtended':
            html += f'            <div class="field">{k} = <span class="value">{v[:40]}...</span></div>\n'
        else:
            html += f'            <div class="field">{k} = <span class="value">{v}</span></div>\n'
    
    html += f"""        </div>
        
        <h2>🔐 Obliczanie hash:</h2>
        <div class="request">
            <div>String do hasha:</div>
            <div class="hash-string" style="margin: 10px 0;">{hash_string}</div>
            <div style="margin-top: 10px;">Secret: <span class="value">{shared_secret}</span></div>
            <div>Hash (Base64): <span class="value">{hash_value}</span></div>
        </div>
        
        <form method="POST" action="https://test.ipg-online.com/connect/gateway/processing" target="_blank">
"""
    
    for k, v in fields.items():
        html += f'            <input type="hidden" name="{k}" value="{v}">\n'
    
    html += """            <button type="submit">🚀 WYŚLIJ REQUEST</button>
        </form>
    </div>
</body>
</html>"""
    
    with open('test_current_warsaw_time.html', 'w', encoding='utf-8') as f:
        f.write(html)
    
    print(f"\n✅ Test zapisany jako: test_current_warsaw_time.html")
    
    import webbrowser
    import os
    webbrowser.open(f"file://{os.path.abspath('test_current_warsaw_time.html')}")

if __name__ == "__main__":
    test_current_warsaw_time()