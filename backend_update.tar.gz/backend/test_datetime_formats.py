#!/usr/bin/env python3
"""
Test różnych formatów daty i czasu - może to jest problem
"""

import os
from datetime import datetime, timezone, timedelta
from zoneinfo import ZoneInfo
from app.utils.fiserv_ipg_client import FiservIPGClient
import webbrowser
import hmac
import hashlib
import base64

def test_datetime_formats():
    """Test różnych formatów txndatetime"""
    
    print("="*60)
    print("TEST FORMATÓW DATY I CZASU")
    print("="*60)
    
    client = FiservIPGClient()
    
    # Różne formaty daty/czasu
    now = datetime.now(timezone.utc)
    berlin_tz = ZoneInfo('Europe/Berlin')
    dublin_tz = ZoneInfo('Europe/Dublin')
    
    datetime_formats = [
        # Format podstawowy
        ("UTC now", now.strftime("%Y:%m:%d-%H:%M:%S")),
        ("UTC +30s", (now + timedelta(seconds=30)).strftime("%Y:%m:%d-%H:%M:%S")),
        ("UTC +5min", (now + timedelta(minutes=5)).strftime("%Y:%m:%d-%H:%M:%S")),
        
        # Berlin timezone
        ("Berlin now", datetime.now(berlin_tz).strftime("%Y:%m:%d-%H:%M:%S")),
        ("Berlin +30s", (datetime.now(berlin_tz) + timedelta(seconds=30)).strftime("%Y:%m:%d-%H:%M:%S")),
        
        # Bez sekund
        ("No seconds", now.strftime("%Y:%m:%d-%H:%M:00")),
        
        # Różne separatory (może to problem?)
        ("Space separator", now.strftime("%Y:%m:%d %H:%M:%S")),
        
        # Format ISO-like
        ("ISO-like", now.strftime("%Y-%m-%d-%H:%M:%S")),
    ]
    
    # HTML
    html = f"""<!DOCTYPE html>
<html>
<head>
    <title>Test DateTime Formats</title>
    <style>
        body {{ 
            font-family: Arial, sans-serif; 
            max-width: 1200px; 
            margin: 20px auto; 
            padding: 20px;
            background: #f5f5f5;
        }}
        .test-section {{
            background: white;
            padding: 20px;
            margin: 15px 0;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }}
        .datetime-value {{
            background: #e3f2fd;
            padding: 8px;
            border-radius: 4px;
            font-family: monospace;
            margin: 5px 0;
        }}
        button {{
            background: #4CAF50;
            color: white;
            border: none;
            padding: 10px 20px;
            margin: 5px;
            border-radius: 5px;
            cursor: pointer;
        }}
        button:hover {{ background: #45a049; }}
        .warning {{
            background: #fff3cd;
            border: 1px solid #ffc107;
            padding: 15px;
            border-radius: 5px;
            margin: 20px 0;
        }}
    </style>
</head>
<body>
    <h1>🕐 Test Formatów DateTime</h1>
    
    <div class="warning">
        <h3>⚠️ Podejrzenie:</h3>
        <p>Format daty/czasu może być przyczyną błędu. Dokumentacja mówi o formacie YYYY:MM:DD-HH:MM:SS, ale może są niuanse.</p>
    </div>
"""
    
    # Test każdego formatu
    for name, dt_value in datetime_formats:
        # Podstawowe pola
        fields = {
            'storename': client.store_id,
            'txntype': 'sale',
            'timezone': 'Europe/Berlin',
            'txndatetime': dt_value,
            'chargetotal': '10.00',
            'currency': '978',  # EUR - większa szansa na sukces
            'checkoutoption': 'classic',
            'oid': f'DT-{name.replace(" ", "-")}-{datetime.now().strftime("%H%M%S")}',
            'hash_algorithm': 'HMACSHA256'
        }
        
        # Oblicz hash
        hash_fields = {k: v for k, v in fields.items() if k not in ['hash_algorithm', 'hashExtended']}
        sorted_hash_fields = sorted(hash_fields.items())
        hash_string = '|'.join(str(v) for k, v in sorted_hash_fields)
        
        hash_bytes = hmac.new(
            client.shared_secret.encode('utf-8'),
            hash_string.encode('utf-8'),
            hashlib.sha256
        ).digest()
        hash_value = base64.b64encode(hash_bytes).decode('utf-8')
        
        fields['hashExtended'] = hash_value
        
        html += f"""
    <div class="test-section">
        <h3>Format: {name}</h3>
        <div class="datetime-value">txndatetime: {dt_value}</div>
        <p>Timezone: {fields['timezone']}, Currency: EUR</p>
        
        <form method="POST" action="{client.gateway_url}" target="_blank">
"""
        for k, v in fields.items():
            html += f'            <input type="hidden" name="{k}" value="{v}">\n'
        
        html += f"""            <button type="submit">Test: {name}</button>
        </form>
    </div>
"""
    
    # Dodaj też test z minimalnym zestawem pól
    html += """
    <div class="test-section" style="background: #e8f5e9;">
        <h3>🎯 Test Minimalny (bez txndatetime)</h3>
        <p>Może txndatetime nie jest wymagane?</p>
"""
    
    min_fields = {
        'storename': client.store_id,
        'txntype': 'sale',
        'chargetotal': '10.00',
        'currency': '978',  # EUR
        'hash_algorithm': 'HMACSHA256'
    }
    
    # Hash dla minimalnego
    hash_fields = {k: v for k, v in min_fields.items() if k not in ['hash_algorithm', 'hashExtended']}
    sorted_hash_fields = sorted(hash_fields.items())
    hash_string = '|'.join(str(v) for k, v in sorted_hash_fields)
    
    hash_bytes = hmac.new(
        client.shared_secret.encode('utf-8'),
        hash_string.encode('utf-8'),
        hashlib.sha256
    ).digest()
    min_fields['hashExtended'] = base64.b64encode(hash_bytes).decode('utf-8')
    
    html += f"""        <form method="POST" action="{client.gateway_url}" target="_blank">
"""
    for k, v in min_fields.items():
        html += f'            <input type="hidden" name="{k}" value="{v}">\n'
    
    html += """            <button type="submit" style="background: #2196F3;">Test Minimalny</button>
        </form>
    </div>
"""
    
    # Informacje dodatkowe
    html += """
    <div class="test-section">
        <h3>📝 Co sprawdzić:</h3>
        <ul>
            <li>Czy któryś format przechodzi dalej?</li>
            <li>Czy błąd jest inny dla różnych formatów?</li>
            <li>Czy test minimalny (bez daty) działa?</li>
        </ul>
        
        <h3>🔍 Możliwe problemy z datą:</h3>
        <ul>
            <li>Format separatorów (: vs - vs spacja)</li>
            <li>Strefa czasowa vs faktyczny czas</li>
            <li>Czas musi być w przyszłości</li>
            <li>Może pole nie jest wymagane</li>
        </ul>
    </div>
</body>
</html>"""
    
    filename = "test_datetime_formats.html"
    with open(filename, 'w') as f:
        f.write(html)
    
    print(f"\n✅ Test zapisany jako: {filename}")
    print("\n🎯 Sprawdź szczególnie:")
    print("1. Test minimalny (bez txndatetime)")
    print("2. Różne formaty czasu")
    print("3. Wszystkie testy używają EUR dla większej szansy")
    
    # Otwórz w przeglądarce
    webbrowser.open(f"file://{os.path.abspath(filename)}")

if __name__ == "__main__":
    test_datetime_formats()