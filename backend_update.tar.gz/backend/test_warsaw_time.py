#!/usr/bin/env python3
"""
Test z aktualnym czasem warszawskim
"""

import hmac
import hashlib
import base64

def test_warsaw_time():
    """Test z czasem warszawskim 11:44"""
    
    print("="*60)
    print("TEST Z CZASEM WARSZAWSKIM")
    print("="*60)
    
    shared_secret = "j}2W3P)Lwv"
    
    # Użyj aktualnego czasu warszawskiego podanego przez użytkownika
    warsaw_time = "2025:07:29-11:44:00"
    
    order_id = "WARSAW-TIME-TEST-001"
    
    fields = {
        'storename': '760995999',
        'txntype': 'sale',
        'timezone': 'Europe/Warsaw',
        'txndatetime': warsaw_time,
        'chargetotal': '10.00',
        'currency': '985',
        'checkoutoption': 'combinedpage',
        'oid': order_id,
        'hash_algorithm': 'HMACSHA256'
    }
    
    print("\nPola do wysłania:")
    for k, v in sorted(fields.items()):
        print(f"  {k}: {v}")
    
    # Oblicz hash
    hash_fields = {k: v for k, v in fields.items() if k not in ['hash_algorithm', 'hashExtended']}
    sorted_fields = sorted(hash_fields.items())
    hash_string = '|'.join(str(v) for k, v in sorted_fields)
    
    print(f"\nString do hasha:\n  {hash_string}")
    
    # HMAC-SHA256
    hash_bytes = hmac.new(
        shared_secret.encode('utf-8'),
        hash_string.encode('utf-8'),
        hashlib.sha256
    ).digest()
    hash_value = base64.b64encode(hash_bytes).decode('utf-8')
    
    print(f"\nHash (Base64):\n  {hash_value}")
    
    fields['hashExtended'] = hash_value
    
    # Generuj HTML
    html = f"""<!DOCTYPE html>
<html>
<head>
    <title>Test - Czas Warszawski 11:44</title>
    <meta charset="UTF-8">
    <style>
        body {{ 
            font-family: Arial, sans-serif; 
            max-width: 800px; 
            margin: 50px auto; 
            padding: 20px;
            background: #f5f5f5;
        }}
        .container {{
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }}
        h1 {{ color: #333; }}
        .info {{
            background: #e3f2fd;
            padding: 15px;
            margin: 20px 0;
            border-radius: 5px;
        }}
        .field {{
            background: #f5f5f5;
            padding: 8px 12px;
            margin: 5px 0;
            font-family: monospace;
            border-left: 3px solid #2196F3;
        }}
        button {{
            background: #4CAF50;
            color: white;
            border: none;
            padding: 15px 40px;
            font-size: 16px;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 20px;
        }}
        button:hover {{
            background: #45a049;
        }}
    </style>
</head>
<body>
    <div class="container">
        <h1>🕐 Test z czasem warszawskim: 11:44</h1>
        
        <div class="info">
            <strong>Używamy czasu lokalnego Warsaw (11:44) zamiast UTC</strong>
        </div>
        
        <h3>Wysyłane dane:</h3>
"""
    
    for k, v in sorted(fields.items()):
        if k != 'hashExtended':
            html += f'        <div class="field">{k} = {v}</div>\n'
        else:
            html += f'        <div class="field">{k} = {v[:40]}...</div>\n'
    
    html += f"""
        <form method="POST" action="https://test.ipg-online.com/connect/gateway/processing" target="_blank">
"""
    
    for k, v in fields.items():
        html += f'            <input type="hidden" name="{k}" value="{v}">\n'
    
    html += """            <button type="submit">WYŚLIJ TEST</button>
        </form>
    </div>
</body>
</html>"""
    
    with open('test_warsaw_time.html', 'w', encoding='utf-8') as f:
        f.write(html)
    
    print(f"\n✅ Test zapisany jako: test_warsaw_time.html")
    print(f"\n📌 Używam czasu warszawskiego: {warsaw_time}")
    
    import webbrowser
    import os
    webbrowser.open(f"file://{os.path.abspath('test_warsaw_time.html')}")

if __name__ == "__main__":
    test_warsaw_time()